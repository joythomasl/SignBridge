(() => {
  // src/recognizer.js
  var HAND_VECTOR_SIZE = 21 * 3;
  function normalizeHand(landmarks, mirrorX = false) {
    if (!landmarks || landmarks.length !== 21) return new Array(HAND_VECTOR_SIZE).fill(0);
    const wrist = landmarks[0];
    const middleMcp = landmarks[9];
    const direction = mirrorX ? -1 : 1;
    const rawDx = middleMcp.x - wrist.x;
    const rawDy = middleMcp.y - wrist.y;
    const scale = Math.max(Math.hypot(rawDx, rawDy, middleMcp.z - wrist.z), 1e-5);
    const vector = [];
    for (const point of landmarks) {
      const x = (point.x - wrist.x) / scale * direction;
      const y = (point.y - wrist.y) / scale;
      const z = (point.z - wrist.z) / scale;
      vector.push(x, y, z);
    }
    return vector;
  }
  function landmarksToVector(result) {
    const slots = {
      Left: new Array(HAND_VECTOR_SIZE).fill(0),
      Right: new Array(HAND_VECTOR_SIZE).fill(0)
    };
    if (result?.landmarks?.length === 1) {
      const handedness = result?.handedness?.[0]?.[0]?.categoryName || "Right";
      slots.Right = normalizeHand(result.landmarks[0], handedness === "Left");
      return [...slots.Left, ...slots.Right, 0, 1, 0, 0, 0, 0, 0, 0];
    }
    const rawHands = {};
    (result?.landmarks || []).forEach((landmarks, index) => {
      const handedness = result?.handedness?.[index]?.[0]?.categoryName || (index === 0 ? "Right" : "Left");
      slots[handedness] = normalizeHand(landmarks, handedness === "Left");
      rawHands[handedness] = landmarks;
    });
    const left = rawHands.Left;
    const right = rawHands.Right;
    let relation = [Number(Boolean(left)), Number(Boolean(right)), 0, 0, 0, 0, 0, 0];
    if (left && right) {
      const leftScale = Math.max(Math.hypot(left[9].x - left[0].x, left[9].y - left[0].y, left[9].z - left[0].z), 1e-5);
      const rightScale = Math.max(Math.hypot(right[9].x - right[0].x, right[9].y - right[0].y, right[9].z - right[0].z), 1e-5);
      const scale = (leftScale + rightScale) / 2;
      const dx = (right[0].x - left[0].x) / scale;
      const dy = (right[0].y - left[0].y) / scale;
      const dz = (right[0].z - left[0].z) / scale;
      relation = [1, 1, dx, dy, dz, Math.hypot(dx, dy, dz), (left[0].x + right[0].x) / 2, (left[0].y + right[0].y) / 2];
    }
    return [...slots.Left, ...slots.Right, ...relation];
  }
  function classifyLandmarkVector(vector, model) {
    if (!model?.classes?.length || vector.length !== model.featureCount) {
      return { gloss: null, score: 0, margin: 0, source: "trained-alphabet-model" };
    }
    const standardized = vector.map((value, index) => (value - model.mean[index]) / (model.scale[index] || 1));
    let logits;
    if (model.type === "mlp-landmark-classifier" && model.weights?.length && model.biases?.length) {
      let activation = standardized;
      model.weights.forEach((weights, layerIndex) => {
        const outputSize = model.biases[layerIndex].length;
        const output = new Array(outputSize).fill(0);
        for (let outputIndex = 0; outputIndex < outputSize; outputIndex += 1) {
          let value = model.biases[layerIndex][outputIndex] || 0;
          for (let inputIndex = 0; inputIndex < activation.length; inputIndex += 1) {
            value += activation[inputIndex] * weights[inputIndex][outputIndex];
          }
          output[outputIndex] = layerIndex < model.weights.length - 1 ? Math.max(0, value) : value;
        }
        activation = output;
      });
      logits = activation;
    } else if (model.coef?.length) {
      logits = model.coef.map((weights, classIndex) => {
        let value = model.intercept[classIndex] || 0;
        for (let index = 0; index < standardized.length; index += 1) value += weights[index] * standardized[index];
        return value;
      });
    } else {
      return { gloss: null, score: 0, margin: 0, source: "trained-alphabet-model" };
    }
    const maximum = Math.max(...logits);
    const probabilities = logits.map((value) => Math.exp(value - maximum));
    const total = probabilities.reduce((sum, value) => sum + value, 0) || 1;
    const ranked = probabilities.map((value, index) => ({ index, probability: value / total })).sort((a, b) => b.probability - a.probability);
    const best = ranked[0];
    const margin = best.probability - (ranked[1]?.probability || 0);
    const centroid = model.centroids?.[best.index];
    const distance = centroid?.length === standardized.length ? Math.sqrt(standardized.reduce((sum, value, index) => sum + (value - centroid[index]) ** 2, 0) / standardized.length) : 0;
    const distanceThreshold = model.distanceThresholds?.[best.index] ?? Number.POSITIVE_INFINITY;
    const accepted = best.probability >= (model.confidenceThreshold || 0.58) && margin >= (model.marginThreshold || 0.12) && distance <= distanceThreshold;
    return {
      gloss: accepted ? model.classes[best.index] : null,
      score: best.probability,
      margin,
      distance,
      distanceThreshold,
      threshold: model.confidenceThreshold || 0.58,
      source: "trained-alphabet-model"
    };
  }
  function averageVectors(vectors) {
    if (!vectors.length) return [];
    const length = vectors[0].length;
    const average = new Array(length).fill(0);
    for (const vector of vectors) {
      for (let i = 0; i < length; i += 1) average[i] += vector[i] || 0;
    }
    return average.map((value) => value / vectors.length);
  }
  function rootMeanSquareDistance(a, b) {
    if (!a?.length || a.length !== b?.length) return Number.POSITIVE_INFINITY;
    let squared = 0;
    for (let index = 0; index < a.length; index += 1) squared += (a[index] - b[index]) ** 2;
    return Math.sqrt(squared / a.length);
  }
  var PoseStabilityGate = class {
    constructor({ windowMs = 450, minFrames = 6, maxAverageMotion = 0.04, maxPeakMotion = 0.11 } = {}) {
      this.windowMs = windowMs;
      this.minFrames = minFrames;
      this.maxAverageMotion = maxAverageMotion;
      this.maxPeakMotion = maxPeakMotion;
      this.reset();
    }
    reset() {
      this.samples = [];
    }
    update(vector, now = performance.now()) {
      if (!vector) {
        this.reset();
        return null;
      }
      this.samples.push({ vector, now });
      const cutoff = now - this.windowMs;
      while (this.samples.length > 1 && this.samples[0].now < cutoff) this.samples.shift();
      if (this.samples.length < this.minFrames || now - this.samples[0].now < this.windowMs * 0.8) return null;
      const motions = [];
      for (let index = 1; index < this.samples.length; index += 1) {
        motions.push(rootMeanSquareDistance(this.samples[index - 1].vector, this.samples[index].vector));
      }
      const averageMotion = motions.reduce((sum, motion) => sum + motion, 0) / motions.length;
      const peakMotion = Math.max(...motions);
      if (averageMotion > this.maxAverageMotion || peakMotion > this.maxPeakMotion) return null;
      return averageVectors(this.samples.map((sample) => sample.vector));
    }
  };
  function cosineSimilarity(a, b) {
    if (!a?.length || a.length !== b?.length) return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < a.length; i += 1) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    if (!normA || !normB) return 0;
    return dot / Math.sqrt(normA * normB);
  }
  function findBestMatch(vector, templates) {
    let best = { gloss: null, score: 0 };
    for (const [gloss, template] of Object.entries(templates || {})) {
      const score = cosineSimilarity(vector, template.vector);
      if (score > best.score) {
        best = {
          gloss,
          score,
          threshold: template.source === "bundled-fingerspelling-dataset" ? 0.78 : void 0,
          source: template.source || "calibrated"
        };
      }
    }
    return best;
  }
  function resampleSequence(sequence, targetLength) {
    if (!sequence?.length || targetLength < 1) return [];
    if (sequence.length === targetLength) return sequence;
    if (targetLength === 1) return [sequence.at(-1)];
    return Array.from({ length: targetLength }, (_, index) => {
      const sourceIndex = Math.round(index * (sequence.length - 1) / (targetLength - 1));
      return sequence[sourceIndex];
    });
  }
  function dynamicTimeWarpingSimilarity(sequence, template) {
    if (!sequence?.length || !template?.length) return 0;
    const rows = sequence.length + 1;
    const columns = template.length + 1;
    const costs = Array.from({ length: rows }, () => new Float64Array(columns).fill(Number.POSITIVE_INFINITY));
    const steps = Array.from({ length: rows }, () => new Uint16Array(columns));
    costs[0][0] = 0;
    for (let row = 1; row < rows; row += 1) {
      for (let column = 1; column < columns; column += 1) {
        const predecessors = [
          [costs[row - 1][column], steps[row - 1][column]],
          [costs[row][column - 1], steps[row][column - 1]],
          [costs[row - 1][column - 1], steps[row - 1][column - 1]]
        ];
        predecessors.sort((a, b) => a[0] - b[0]);
        costs[row][column] = predecessors[0][0] + (1 - cosineSimilarity(sequence[row - 1], template[column - 1]));
        steps[row][column] = predecessors[0][1] + 1;
      }
    }
    return Math.max(0, 1 - costs.at(-1).at(-1) / Math.max(steps.at(-1).at(-1), 1));
  }
  function sequenceMotionEnergy(sequence) {
    if (!sequence?.length || sequence.length < 2) return 0;
    let total = 0;
    for (let index = 1; index < sequence.length; index += 1) {
      total += 1 - cosineSimilarity(sequence[index - 1], sequence[index]);
    }
    return total / (sequence.length - 1);
  }
  function findBestSequenceMatch(frames, templates) {
    if (!frames?.length || frames.length < 18) return { gloss: null, score: 0, margin: 0 };
    const lengths = [18, 24, 30, 40, 50, 60].filter((length) => length <= frames.length);
    const matches = [];
    for (const [gloss, template] of Object.entries(templates || {})) {
      if (!template?.sequence?.length) continue;
      let score = 0;
      for (const length of lengths) {
        const sampled = resampleSequence(frames.slice(-length), template.sequence.length);
        let candidateScore = dynamicTimeWarpingSimilarity(frames.slice(-length), template.sequence);
        if (Number.isFinite(template.motion)) {
          const observedMotion = sequenceMotionEnergy(sampled);
          const largerMotion = Math.max(observedMotion, template.motion, 1e-5);
          const motionRatio = Math.min(observedMotion, template.motion) / largerMotion;
          candidateScore *= 0.7 + 0.3 * motionRatio;
        }
        score = Math.max(score, candidateScore);
      }
      matches.push({ gloss, score, source: template.source || "temporal" });
    }
    matches.sort((a, b) => b.score - a.score);
    const best = matches[0] || { gloss: null, score: 0 };
    const second = matches[1]?.score || 0;
    return { ...best, margin: best.score - second };
  }
  var TemporalGestureDetector = class {
    constructor({ templates, threshold = 0.76, minMargin = 0.018, holdMs = 320, cooldownMs = 1200, onCandidate, onAccept }) {
      this.templates = templates || {};
      this.threshold = threshold;
      this.minMargin = minMargin;
      this.holdMs = holdMs;
      this.cooldownMs = cooldownMs;
      this.onCandidate = onCandidate;
      this.onAccept = onAccept;
      this.reset();
    }
    reset() {
      this.frames = [];
      this.candidate = null;
      this.since = 0;
      this.cooldownUntil = 0;
      this.lastEvaluation = 0;
      this.neutralSince = 0;
    }
    update(vector, now = performance.now()) {
      if (!vector) {
        if (!this.neutralSince) this.neutralSince = now;
        if (now - this.neutralSince > 700) this.frames = [];
        return false;
      }
      this.neutralSince = 0;
      this.frames.push(vector);
      if (this.frames.length > 60) this.frames.shift();
      if (now < this.cooldownUntil || now - this.lastEvaluation < 160 || this.frames.length < 18) return false;
      this.lastEvaluation = now;
      const match = findBestSequenceMatch(this.frames, this.templates);
      this.onCandidate?.(match);
      if (!match.gloss || match.score < this.threshold || match.margin < this.minMargin) {
        this.candidate = null;
        this.since = 0;
        return false;
      }
      if (this.candidate !== match.gloss) {
        this.candidate = match.gloss;
        this.since = now;
        return false;
      }
      if (now - this.since < this.holdMs) return false;
      this.onAccept?.(match);
      this.frames = [];
      this.candidate = null;
      this.since = 0;
      this.cooldownUntil = now + this.cooldownMs;
      return true;
    }
  };
  var StableGestureDetector = class {
    constructor({ threshold, holdMs, cooldownMs, onCandidate, onAccept }) {
      this.threshold = threshold;
      this.holdMs = holdMs;
      this.cooldownMs = cooldownMs;
      this.onCandidate = onCandidate;
      this.onAccept = onAccept;
      this.reset();
    }
    reset() {
      this.candidate = null;
      this.since = 0;
      this.cooldownUntil = 0;
      this.lockedGloss = null;
    }
    update(match, now = performance.now()) {
      const threshold = match.threshold ?? this.threshold;
      if (!match.gloss || match.score < threshold || now < this.cooldownUntil) {
        if (!match.gloss || match.score < threshold) this.lockedGloss = null;
        this.candidate = null;
        this.since = 0;
        this.onCandidate?.(match);
        return;
      }
      if (this.lockedGloss === match.gloss) {
        this.onCandidate?.(match);
        return;
      }
      if (this.candidate !== match.gloss) {
        this.candidate = match.gloss;
        this.since = now;
        this.onCandidate?.(match);
        return;
      }
      this.onCandidate?.(match);
      if (now - this.since >= this.holdMs) {
        this.onAccept?.(match);
        this.lockedGloss = match.gloss;
        this.cooldownUntil = now + this.cooldownMs;
        this.candidate = null;
        this.since = 0;
      }
    }
  };

  // src/vision.js
  var CONNECTIONS = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 4],
    [0, 5],
    [5, 6],
    [6, 7],
    [7, 8],
    [5, 9],
    [9, 10],
    [10, 11],
    [11, 12],
    [9, 13],
    [13, 14],
    [14, 15],
    [15, 16],
    [13, 17],
    [17, 18],
    [18, 19],
    [19, 20],
    [0, 17]
  ];
  var FINGER_COLORS = ["#ffb45f", "#55e6d5", "#78a9ff", "#d68cff", "#ff7ca8"];
  function colorForPoint(index) {
    if (index === 0) return "#ffffff";
    if (index <= 4) return FINGER_COLORS[0];
    if (index <= 8) return FINGER_COLORS[1];
    if (index <= 12) return FINGER_COLORS[2];
    if (index <= 16) return FINGER_COLORS[3];
    return FINGER_COLORS[4];
  }
  var VisionController = class {
    constructor({ video, canvas, fps = 15, onVector, onError }) {
      this.video = video;
      this.canvas = canvas;
      this.context = canvas.getContext("2d");
      this.fps = fps;
      this.onVector = onVector;
      this.onError = onError;
      this.frame = null;
      this.stream = null;
      this.running = false;
      this.frameRequest = null;
      this.lastInferenceAt = 0;
      this.inFlight = false;
      this.ready = false;
      this.initializePromise = null;
      this.messageHandler = (event) => this.handleMessage(event);
    }
    async initialize() {
      if (this.ready) return;
      if (this.initializePromise) return this.initializePromise;
      this.initializePromise = new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error("MediaPipe runtime timed out")), 2e4);
        this.resolveInitialize = () => {
          clearTimeout(timeout);
          this.ready = true;
          resolve();
        };
        this.rejectInitialize = (error) => {
          clearTimeout(timeout);
          reject(error);
        };
      });
      window.addEventListener("message", this.messageHandler);
      this.frame = document.createElement("iframe");
      this.frame.src = chrome.runtime.getURL("vision.html");
      this.frame.title = "SignBridge vision runtime";
      this.frame.hidden = true;
      this.frame.setAttribute("aria-hidden", "true");
      document.documentElement.appendChild(this.frame);
      return this.initializePromise;
    }
    async start() {
      if (this.running) return this.stream;
      await this.initialize();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 24, max: 30 },
          facingMode: "user"
        },
        audio: false
      });
      this.video.srcObject = this.stream;
      await this.video.play();
      this.running = true;
      this.loop();
      return this.stream;
    }
    stop() {
      this.running = false;
      this.inFlight = false;
      if (this.frameRequest) cancelAnimationFrame(this.frameRequest);
      this.stream?.getTracks().forEach((track) => track.stop());
      this.stream = null;
      this.video.srcObject = null;
      this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    getStream() {
      return this.stream;
    }
    loop = () => {
      if (!this.running) return;
      const now = performance.now();
      const interval = 1e3 / this.fps;
      if (!this.inFlight && this.video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && now - this.lastInferenceAt >= interval) {
        this.lastInferenceAt = now;
        this.sendFrame(now);
      }
      this.frameRequest = requestAnimationFrame(this.loop);
    };
    async sendFrame(timestamp) {
      this.inFlight = true;
      try {
        const bitmap = await createImageBitmap(this.video);
        this.frame.contentWindow.postMessage({ type: "SIGNBRIDGE_VISION_FRAME", timestamp, bitmap }, "*", [bitmap]);
      } catch (error) {
        this.inFlight = false;
        this.onError?.(error);
      }
    }
    handleMessage(event) {
      if (event.source !== this.frame?.contentWindow) return;
      const message = event.data || {};
      if (message.type === "SIGNBRIDGE_VISION_READY") {
        this.resolveInitialize?.();
        return;
      }
      if (message.type === "SIGNBRIDGE_VISION_ERROR") {
        this.inFlight = false;
        const error = new Error(message.message || "MediaPipe failed");
        if (!this.ready) this.rejectInitialize?.(error);
        else this.onError?.(error);
        return;
      }
      if (message.type !== "SIGNBRIDGE_VISION_RESULT") return;
      this.inFlight = false;
      const result = {
        landmarks: Array.isArray(message.landmarks) ? message.landmarks : [],
        handedness: Array.isArray(message.handedness) ? message.handedness : []
      };
      this.draw(result);
      if (result.landmarks.length) this.onVector?.(landmarksToVector(result), result);
      else this.onVector?.(null, result);
    }
    draw(result) {
      const width = this.video.videoWidth || 640;
      const height = this.video.videoHeight || 480;
      if (this.canvas.width !== width) this.canvas.width = width;
      if (this.canvas.height !== height) this.canvas.height = height;
      const context = this.context;
      context.clearRect(0, 0, width, height);
      context.save();
      context.translate(width, 0);
      context.scale(-1, 1);
      context.lineWidth = 3;
      for (const hand of result.landmarks) {
        for (const [start, end] of CONNECTIONS) {
          context.strokeStyle = colorForPoint(end);
          context.beginPath();
          context.moveTo(hand[start].x * width, hand[start].y * height);
          context.lineTo(hand[end].x * width, hand[end].y * height);
          context.stroke();
        }
        hand.forEach((point, index) => {
          context.fillStyle = colorForPoint(index);
          context.beginPath();
          context.arc(point.x * width, point.y * height, 4, 0, Math.PI * 2);
          context.fill();
          if ([0, 4, 8, 12, 16, 20].includes(index)) {
            context.save();
            context.scale(-1, 1);
            context.fillStyle = "#ffffff";
            context.font = "bold 11px system-ui";
            context.fillText(String(index), -point.x * width + 6, point.y * height - 6);
            context.restore();
          }
        });
      }
      context.restore();
    }
  };

  // src/constants.js
  var DEFAULT_SETTINGS = {
    endpoint: "http://localhost:11434",
    model: "gemma4:e2b-it-q4_K_M",
    apiKey: "",
    detectionThreshold: 0.92,
    detectionHoldMs: 750,
    detectionCooldownMs: 1100,
    inferenceFps: 15,
    speechRate: 0.95,
    livePauseMs: 2e3
  };
  var DEMO_GLOSSES = [
    "ME",
    "YES",
    "NO",
    "PYTHON",
    "AI",
    "PROJECT",
    "EXPERIENCE",
    "TEAM",
    "SOLVE",
    "THREE",
    "YEAR",
    "THANK-YOU"
  ];
  var INTENTS = [
    { id: "ASK_INTRODUCTION", label: "Please introduce yourself" },
    { id: "ASK_EXPERIENCE", label: "Tell me about your experience" },
    { id: "ASK_PROJECT", label: "Explain a project" },
    { id: "ASK_SKILLS", label: "What technical skills do you have" },
    { id: "ASK_TEAMWORK", label: "How do you work with a team" }
  ];

  // src/avatar-renderer.js
  var HAND_SIZE = 21 * 3;
  var CONNECTIONS2 = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 4],
    [0, 5],
    [5, 6],
    [6, 7],
    [7, 8],
    [5, 9],
    [9, 10],
    [10, 11],
    [11, 12],
    [9, 13],
    [13, 14],
    [14, 15],
    [15, 16],
    [13, 17],
    [17, 18],
    [18, 19],
    [19, 20],
    [0, 17]
  ];
  function decodeHand(values) {
    const points = Array.from({ length: 21 }, (_, index) => ({
      x: values[index * 3] || 0,
      y: values[index * 3 + 1] || 0,
      z: values[index * 3 + 2] || 0
    }));
    const present = points.slice(1).some((point) => Math.abs(point.x) + Math.abs(point.y) + Math.abs(point.z) > 1e-4);
    return present ? points : null;
  }
  function decodeLandmarkVector(vector) {
    if (!Array.isArray(vector) || vector.length < HAND_SIZE * 2) return { left: null, right: null, relation: [] };
    return {
      left: decodeHand(vector.slice(0, HAND_SIZE)),
      right: decodeHand(vector.slice(HAND_SIZE, HAND_SIZE * 2)),
      relation: vector.slice(HAND_SIZE * 2)
    };
  }
  function interpolateVectors(first, second, amount) {
    if (!first) return second || null;
    if (!second || first.length !== second.length) return first;
    return first.map((value, index) => value + (second[index] - value) * amount);
  }
  function drawHand(context, points, wrist, scale, color) {
    if (!points) return;
    const mapped = points.map((point) => ({
      x: wrist.x + point.x * scale,
      y: wrist.y + point.y * scale,
      z: point.z
    }));
    context.save();
    context.lineCap = "round";
    context.lineJoin = "round";
    context.strokeStyle = color;
    context.shadowColor = color;
    context.shadowBlur = 8;
    context.lineWidth = 4;
    for (const [start, end] of CONNECTIONS2) {
      context.beginPath();
      context.moveTo(mapped[start].x, mapped[start].y);
      context.lineTo(mapped[end].x, mapped[end].y);
      context.stroke();
    }
    mapped.forEach((point, index) => {
      const tip = [4, 8, 12, 16, 20].includes(index);
      context.beginPath();
      context.fillStyle = tip ? "#ffffff" : color;
      context.arc(point.x, point.y, Math.max(2.5, (tip ? 5 : 3.5) - point.z), 0, Math.PI * 2);
      context.fill();
    });
    context.restore();
  }
  function drawSigningAvatar(context, vector, width, height) {
    context.clearRect(0, 0, width, height);
    const gradient = context.createLinearGradient(0, 0, 0, height);
    gradient.addColorStop(0, "#061d22");
    gradient.addColorStop(1, "#020c10");
    context.fillStyle = gradient;
    context.fillRect(0, 0, width, height);
    const centerX = width / 2;
    const headY = height * 0.22;
    const headRadius = Math.min(width, height) * 0.085;
    context.fillStyle = "#153d43";
    context.beginPath();
    context.arc(centerX, headY, headRadius, 0, Math.PI * 2);
    context.fill();
    context.strokeStyle = "#56ddd0";
    context.lineWidth = 3;
    context.stroke();
    context.beginPath();
    context.moveTo(centerX - width * 0.18, height * 0.72);
    context.quadraticCurveTo(centerX - width * 0.17, height * 0.39, centerX, height * 0.38);
    context.quadraticCurveTo(centerX + width * 0.17, height * 0.39, centerX + width * 0.18, height * 0.72);
    context.closePath();
    context.fillStyle = "#0e3036";
    context.fill();
    context.stroke();
    const { left, right, relation } = decodeLandmarkVector(vector);
    const twoHands = Boolean(left && right);
    const separation = twoHands ? Math.min(width * 0.29, Math.max(width * 0.16, Math.abs(relation[2] || 2) * width * 0.055)) : 0;
    const leftWrist = { x: centerX - separation, y: height * 0.69 };
    const rightWrist = { x: centerX + separation, y: height * 0.69 };
    const scale = Math.min(width, height) * (twoHands ? 0.16 : 0.2);
    context.strokeStyle = "#267780";
    context.lineWidth = 12;
    context.lineCap = "round";
    if (left) {
      context.beginPath();
      context.moveTo(centerX - width * 0.12, height * 0.44);
      context.quadraticCurveTo(centerX - width * 0.23, height * 0.55, leftWrist.x, leftWrist.y);
      context.stroke();
    }
    if (right) {
      context.beginPath();
      context.moveTo(centerX + width * 0.12, height * 0.44);
      context.quadraticCurveTo(centerX + width * 0.23, height * 0.55, rightWrist.x, rightWrist.y);
      context.stroke();
    }
    drawHand(context, left, leftWrist, scale, "#ffb45f");
    drawHand(context, right, rightWrist, scale, "#51e4d3");
    if (!left && !right) {
      context.fillStyle = "#8bb6b9";
      context.font = `600 ${Math.round(height * 0.055)}px system-ui`;
      context.textAlign = "center";
      context.fillText("pause", centerX, height * 0.58);
    }
  }

  // src/hud.js
  var SignBridgeHud = class {
    constructor(handlers, vocabulary = DEMO_GLOSSES) {
      this.handlers = handlers;
      this.vocabulary = vocabulary;
      this.signVectors = [];
      this.signFrameIndex = 0;
      this.signAnimationRequest = null;
      this.signAnimationStartedAt = 0;
      this.signFrameRate = 10;
      this.signPlaybackRate = 1;
      this.host = document.createElement("div");
      this.host.id = "signbridge-root";
      this.host.dataset.signbridge = "true";
      this.shadow = this.host.attachShadow({ mode: "open" });
      this.shadow.innerHTML = this.template();
      document.documentElement.appendChild(this.host);
      this.bind();
    }
    template() {
      const glossOptions = this.vocabulary.map((item) => `<option value="${item}">${item}</option>`).join("");
      const intentOptions = INTENTS.map((item) => `<option value="${item.id}">${item.label}</option>`).join("");
      return `
      <link rel="stylesheet" href="${chrome.runtime.getURL("hud.css")}">
      <aside class="sb-shell" aria-label="SignBridge AI">
        <header class="sb-header">
          <div>
            <strong>SignBridge AI</strong>
            <small>Gemma 4 \xB7 ISL prototype</small>
          </div>
          <div class="sb-header-actions">
            <span id="sb-mode-badge" class="sb-badge">Checking\u2026</span>
            <button id="sb-collapse" class="sb-icon" title="Collapse">\u2212</button>
          </div>
        </header>
        <div id="sb-body" class="sb-body">
          <div id="sb-status" class="sb-status" data-kind="info">Ready to configure</div>

          <section class="sb-section">
            <div class="sb-section-title"><span>1</span> Interviewer question</div>
            <textarea id="sb-question" rows="2" placeholder="Meet captions are detected and translated automatically\u2026"></textarea>
            <small id="sb-caption-state" class="sb-muted">Live caption detection is active</small>
          </section>

          <section class="sb-section sb-sign-output">
            <div class="sb-section-title"><span>2</span> Interviewer \u2192 ISL</div>
            <div class="sb-sign-stage">
              <video id="sb-sign-video" playsinline controls hidden></video>
              <canvas id="sb-sign-avatar" width="640" height="400" aria-label="Generated landmark signing avatar" hidden></canvas>
              <div id="sb-sign-placeholder" class="sb-sign-placeholder">Translate a supported question to play its verified ISL clip.</div>
            </div>
            <div id="sb-sign-caption" class="sb-sign-caption"></div>
            <div id="sb-sign-glosses" class="sb-chips"></div>
            <div class="sb-row">
              <button id="sb-replay-sign">Replay</button>
              <button id="sb-slower-sign">Slower</button>
              <span id="sb-sign-quality" class="sb-quality"></span>
            </div>
            <details class="sb-details">
              <summary>ISL phrase clip studio</summary>
              <p class="sb-muted">Bundled dataset clips require ISL review. A knowledgeable signer can record verified replacements here.</p>
              <select id="sb-clip-intent">${intentOptions}</select>
              <div class="sb-row">
                <button id="sb-record-clip">Record phrase</button>
                <button id="sb-stop-record" disabled>Stop & save</button>
                <button id="sb-delete-clip" class="sb-danger-text">Delete</button>
              </div>
              <div id="sb-clip-status" class="sb-muted">No recording in progress</div>
            </details>
          </section>

          <section class="sb-section">
            <div class="sb-section-title"><span>3</span> Candidate signs</div>
            <div class="sb-camera-stage">
              <video id="sb-camera" muted playsinline></video>
              <canvas id="sb-canvas"></canvas>
              <div id="sb-detected" class="sb-detected">No gesture</div>
            </div>
            <div class="sb-row">
              <button id="sb-start-camera" class="sb-primary">Start camera</button>
              <button id="sb-stop-camera" disabled>Stop</button>
            </div>
            <div class="sb-live-banner"><strong>Live sign \u2192 audio always on</strong><small>Signs are spoken automatically after a short neutral pause.</small></div>
            <div id="sb-live-state" class="sb-muted" data-active="true">Waiting for camera and signs</div>
            <div id="sb-gloss-buffer" class="sb-chips sb-buffer"></div>
            <button id="sb-clear-glosses" class="sb-full-button">Clear current phrase</button>
            <details class="sb-details">
              <summary>Recognition setup and fallback</summary>
              <p class="sb-muted">For a letter, hold the pose. For a word, perform the complete motion once. Personal training stays on this laptop.</p>
              <div class="sb-calibration">
                <select id="sb-calibration-gloss">${glossOptions}</select>
                <button id="sb-calibrate">Calibrate sign</button>
              </div>
              <button id="sb-add-gloss" class="sb-full-button">Add selected gloss manually</button>
              <div id="sb-calibration-state" class="sb-muted">Train only signs that do not recognize reliably for you.</div>
            </details>
          </section>

          <section class="sb-section">
            <div class="sb-section-title"><span>4</span> Candidate review</div>
            <textarea id="sb-answer" rows="3" placeholder="Gemma 4 answer appears here for review\u2026"></textarea>
            <label class="sb-check"><input id="sb-approved" type="checkbox"> I reviewed and approve this wording</label>
            <div class="sb-row sb-wrap">
              <button id="sb-speak" disabled>Speak</button>
              <button id="sb-copy" disabled>Copy</button>
              <button id="sb-chat" disabled>Insert in Meet chat</button>
            </div>
            <div id="sb-metrics" class="sb-muted"></div>
          </section>

          <details class="sb-section sb-details" open>
            <summary>Gemma 4 settings</summary>
            <label>Endpoint<input id="sb-endpoint" type="url" placeholder="http://localhost:11434"></label>
            <label>Model<input id="sb-model" type="text" placeholder="gemma4:e2b-it-q4_K_M"></label>
            <label>API key (optional)<input id="sb-api-key" type="password" autocomplete="off"></label>
            <div class="sb-row">
              <button id="sb-save-settings">Save</button>
              <button id="sb-check-gemma" class="sb-primary">Check Gemma</button>
            </div>
          </details>
        </div>
      </aside>
      <div id="sb-caption-overlay" class="sb-caption-overlay" aria-live="polite" hidden>
        <span>Interviewer</span>
        <strong id="sb-caption-overlay-text"></strong>
      </div>`;
    }
    $(selector) {
      return this.shadow.querySelector(selector);
    }
    bind() {
      const actions = {
        "#sb-start-camera": "startCamera",
        "#sb-stop-camera": "stopCamera",
        "#sb-calibrate": "calibrate",
        "#sb-add-gloss": "addGloss",
        "#sb-clear-glosses": "clearGlosses",
        "#sb-speak": "speak",
        "#sb-copy": "copy",
        "#sb-chat": "insertChat",
        "#sb-save-settings": "saveSettings",
        "#sb-check-gemma": "checkGemma",
        "#sb-replay-sign": "replaySign",
        "#sb-slower-sign": "slowerSign",
        "#sb-record-clip": "recordClip",
        "#sb-stop-record": "stopRecording",
        "#sb-delete-clip": "deleteClip"
      };
      for (const [selector, handler] of Object.entries(actions)) {
        this.$(selector).addEventListener("click", () => this.handlers[handler]?.());
      }
      this.$("#sb-approved").addEventListener("change", (event) => this.setApproved(event.target.checked));
      this.$("#sb-question").addEventListener("input", (event) => this.handlers.questionChanged?.(event.target.value.trim()));
      this.$("#sb-answer").addEventListener("input", () => {
        this.$("#sb-approved").checked = false;
        this.setApproved(false);
      });
      this.$("#sb-collapse").addEventListener("click", () => {
        const body = this.$("#sb-body");
        body.hidden = !body.hidden;
        this.$("#sb-collapse").textContent = body.hidden ? "+" : "\u2212";
      });
    }
    get video() {
      return this.$("#sb-camera");
    }
    get canvas() {
      return this.$("#sb-canvas");
    }
    getQuestion() {
      return this.$("#sb-question").value.trim();
    }
    getAnswer() {
      return this.$("#sb-answer").value.trim();
    }
    getCalibrationGloss() {
      return this.$("#sb-calibration-gloss").value;
    }
    getClipIntent() {
      return this.$("#sb-clip-intent").value;
    }
    getSettingsForm() {
      return {
        endpoint: this.$("#sb-endpoint").value.trim(),
        model: this.$("#sb-model").value.trim(),
        apiKey: this.$("#sb-api-key").value
      };
    }
    setSettings(settings) {
      this.$("#sb-endpoint").value = settings.endpoint || "";
      this.$("#sb-model").value = settings.model || "";
      this.$("#sb-api-key").value = settings.apiKey || "";
      this.setLiveState("Always-live mode ready \u2014 pause briefly to speak", true);
      this.$("#sb-mode-badge").textContent = settings.endpoint?.includes("localhost") || settings.endpoint?.includes("127.0.0.1") ? "Gemma 4 local" : "Gemma 4 network";
    }
    setStatus(message, kind = "info") {
      const status = this.$("#sb-status");
      status.textContent = message;
      status.dataset.kind = kind;
    }
    setQuestion(question, source = "manual") {
      this.$("#sb-question").value = question;
      this.$("#sb-caption-state").textContent = source === "caption" ? "Latest Meet caption captured" : "Using manual question";
    }
    showLatestCaption(caption) {
      this.$("#sb-caption-state").textContent = `Caption ready: ${caption.slice(0, 70)}${caption.length > 70 ? "\u2026" : ""}`;
      this.$("#sb-caption-overlay-text").textContent = caption;
      this.$("#sb-caption-overlay").hidden = false;
    }
    setCameraRunning(running) {
      this.$("#sb-start-camera").disabled = running;
      this.$("#sb-stop-camera").disabled = !running;
    }
    setLiveState(message, active = true) {
      const state = this.$("#sb-live-state");
      state.textContent = message;
      state.dataset.active = String(Boolean(active));
    }
    setDetected(match) {
      const label = this.$("#sb-detected");
      if (match?.unstable) label.textContent = "Hand moving \xB7 hold the sign steady";
      else if (!match?.gloss) label.textContent = match?.handPresent ? "Hand tracked \xB7 unknown sign" : "No hand";
      else label.textContent = `${match.gloss} \xB7 ${Math.round(match.score * 100)}%`;
    }
    setCalibrationState(message, progress = 0) {
      this.$("#sb-calibration-state").textContent = progress ? `${message} ${Math.round(progress * 100)}%` : message;
    }
    renderGlosses(glosses, removeHandler) {
      const container = this.$("#sb-gloss-buffer");
      container.replaceChildren();
      if (!glosses.length) {
        const empty = document.createElement("span");
        empty.className = "sb-muted";
        empty.textContent = "Detected signs will appear here";
        container.appendChild(empty);
        return;
      }
      glosses.forEach((gloss, index) => {
        const chip = document.createElement("button");
        chip.className = "sb-chip";
        chip.textContent = `${gloss} \xD7`;
        chip.title = "Remove sign";
        chip.addEventListener("click", () => removeHandler(index));
        container.appendChild(chip);
      });
    }
    setAnswer(answer, needsClarification = false) {
      this.$("#sb-answer").value = answer;
      this.$("#sb-approved").checked = false;
      this.setApproved(false);
      if (needsClarification) this.setStatus("Gemma needs clarification. Review the literal answer before approving.", "warn");
    }
    setApproved(approved) {
      const enabled = approved && Boolean(this.getAnswer());
      ["#sb-speak", "#sb-copy", "#sb-chat"].forEach((selector) => {
        this.$(selector).disabled = !enabled;
      });
    }
    setMetrics(metrics) {
      if (!metrics?.totalDurationNs) {
        this.$("#sb-metrics").textContent = "";
        return;
      }
      this.$("#sb-metrics").textContent = `Gemma 4: ${(metrics.totalDurationNs / 1e9).toFixed(2)}s \xB7 ${metrics.outputTokens || 0} output tokens`;
    }
    showSignResult({ question, glosses, clipUrl, vectorSequences = [], exact, quality, message }) {
      const video = this.$("#sb-sign-video");
      const avatar = this.$("#sb-sign-avatar");
      const placeholder = this.$("#sb-sign-placeholder");
      this.stopFrameAnimation();
      this.signVectors = [];
      this.$("#sb-sign-caption").textContent = question;
      const chips = this.$("#sb-sign-glosses");
      chips.replaceChildren(...glosses.map((gloss) => {
        const span = document.createElement("span");
        span.className = "sb-chip sb-chip-static";
        span.textContent = gloss;
        return span;
      }));
      this.$("#sb-sign-quality").textContent = quality || (exact ? "Verified phrase clip" : "Approximate / unsupported");
      this.$("#sb-sign-quality").dataset.exact = String(Boolean(exact));
      if (clipUrl) {
        video.src = clipUrl;
        video.hidden = false;
        avatar.hidden = true;
        placeholder.hidden = true;
        video.playbackRate = 1;
        video.play().catch(() => {
        });
      } else if (vectorSequences.length) {
        video.removeAttribute("src");
        video.load();
        video.hidden = true;
        avatar.hidden = false;
        placeholder.hidden = true;
        this.signVectors = vectorSequences.flatMap((sequence) => [
          ...sequence.vectors,
          ...Array(4).fill(sequence.vectors.at(-1))
        ]);
        this.signFrameRate = vectorSequences[0]?.fps || 10;
        this.playFrameAnimation(true);
      } else {
        video.removeAttribute("src");
        video.load();
        video.hidden = true;
        avatar.hidden = true;
        placeholder.hidden = false;
        placeholder.textContent = message || "No verified ISL clip is recorded for this question.";
      }
    }
    replaySign() {
      const video = this.$("#sb-sign-video");
      if (!video.hidden && video.src) {
        video.currentTime = 0;
        video.play().catch(() => {
        });
      } else if (this.signVectors.length) {
        this.playFrameAnimation(true);
      }
    }
    slowerSign() {
      const video = this.$("#sb-sign-video");
      if (!video.hidden && video.src) {
        video.playbackRate = video.playbackRate === 0.65 ? 1 : 0.65;
        this.signPlaybackRate = video.playbackRate;
      } else if (this.signVectors.length) {
        this.signPlaybackRate = this.signPlaybackRate === 0.65 ? 1 : 0.65;
        this.playFrameAnimation(true);
      }
      this.$("#sb-slower-sign").textContent = this.signPlaybackRate === 0.65 ? "Normal speed" : "Slower";
    }
    playFrameAnimation(reset = false) {
      this.stopFrameAnimation();
      if (!this.signVectors.length) return;
      if (reset) this.signFrameIndex = 0;
      const avatar = this.$("#sb-sign-avatar");
      const context = avatar.getContext("2d");
      this.signAnimationStartedAt = performance.now() - this.signFrameIndex / (this.signFrameRate * this.signPlaybackRate) * 1e3;
      const step = (now) => {
        const position = (now - this.signAnimationStartedAt) / 1e3 * this.signFrameRate * this.signPlaybackRate;
        const index = Math.floor(position);
        if (index >= this.signVectors.length) {
          this.stopFrameAnimation();
          return;
        }
        this.signFrameIndex = index;
        const current = this.signVectors[index];
        const next = this.signVectors[Math.min(index + 1, this.signVectors.length - 1)];
        const vector = current ? interpolateVectors(current, next, position - index) : null;
        drawSigningAvatar(context, vector, avatar.width, avatar.height);
        this.signAnimationRequest = requestAnimationFrame(step);
      };
      this.signAnimationRequest = requestAnimationFrame(step);
    }
    stopFrameAnimation() {
      if (this.signAnimationRequest) cancelAnimationFrame(this.signAnimationRequest);
      this.signAnimationRequest = null;
    }
    setRecording(recording, message) {
      this.$("#sb-record-clip").disabled = recording;
      this.$("#sb-stop-record").disabled = !recording;
      this.$("#sb-clip-status").textContent = message;
    }
  };

  // src/meet-adapter.js
  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }
  function isVisible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  var MeetAdapter = class {
    constructor({ onCaption }) {
      this.onCaption = onCaption;
      this.lastCaption = "";
      this.pendingCaption = "";
      this.captionTimer = null;
      this.observer = null;
    }
    start() {
      this.observer = new MutationObserver((mutations) => this.handleMutations(mutations));
      this.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    stop() {
      this.observer?.disconnect();
      clearTimeout(this.captionTimer);
    }
    handleMutations(mutations) {
      const candidates = [];
      for (const mutation of mutations) {
        const target = mutation.target.nodeType === Node.TEXT_NODE ? mutation.target.parentElement : mutation.target;
        if (!target || target.closest?.("#signbridge-root")) continue;
        const liveRegion = target.closest?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]');
        if (liveRegion) candidates.push({ target, liveRegion });
        for (const node of mutation.addedNodes || []) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          if (node.matches?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]')) candidates.push({ target: node, liveRegion: node });
          node.querySelectorAll?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]').forEach((item) => candidates.push({ target: item, liveRegion: item }));
        }
      }
      const meetCaptions = document.querySelector('[role="region"][aria-label*="caption" i]');
      if (meetCaptions) candidates.push({ target: meetCaptions, liveRegion: meetCaptions });
      for (const { target, liveRegion } of candidates) {
        const text = this.extractCaptionText(target, liveRegion);
        if (this.looksLikeCaption(text)) this.queueCaption(text);
      }
    }
    extractCaptionText(target, liveRegion) {
      let current = target;
      let best = "";
      while (current && current !== liveRegion.parentElement) {
        const text = normalizeText(current.innerText || current.textContent);
        const wordCount = text.split(" ").filter(Boolean).length;
        if (wordCount >= 2 && text.length <= 320) best = text;
        if (current === liveRegion) break;
        current = current.parentElement;
      }
      const lines = String(best || liveRegion.innerText || liveRegion.textContent || "").split(/[\r\n]+/).map(normalizeText).filter(Boolean);
      if (lines.length > 1 && lines[0].length <= 48 && lines[0].split(" ").length <= 5) lines.shift();
      return normalizeText(lines.join(" "));
    }
    looksLikeCaption(text) {
      if (!text || text === this.lastCaption || text.length < 4 || text.length > 320) return false;
      if (/signbridge|you are presenting|microphone|camera|joined|left the call/i.test(text)) return false;
      const words = text.split(" ");
      return words.length >= 2;
    }
    queueCaption(text) {
      this.pendingCaption = text;
      clearTimeout(this.captionTimer);
      this.captionTimer = setTimeout(() => {
        if (!this.pendingCaption || this.pendingCaption === this.lastCaption) return;
        this.lastCaption = this.pendingCaption;
        this.onCaption?.(this.lastCaption);
      }, 900);
    }
    insertChatDraft(text) {
      const input = this.findChatInput();
      if (!input) {
        throw new Error("Open the Meet chat panel, then try Insert again.");
      }
      input.focus();
      if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
        const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), "value");
        descriptor?.set?.call(input, text);
      } else {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(input);
        selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand("insertText", false, text);
      }
      input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
    findChatInput() {
      const selectors = [
        'div[contenteditable="true"][role="textbox"]',
        'textarea[aria-label*="message" i]',
        'textarea[placeholder*="message" i]'
      ];
      const candidates = selectors.flatMap((selector) => [...document.querySelectorAll(selector)]);
      return candidates.find((element) => isVisible(element) && !element.closest("#signbridge-root")) || null;
    }
    async sendChatMessage(text) {
      if (!this.findChatInput()) {
        const chatButton = [...document.querySelectorAll('button[aria-label*="chat" i], button[data-tooltip*="chat" i]')].find((button) => isVisible(button) && !button.closest("#signbridge-root"));
        chatButton?.click();
        const startedAt = performance.now();
        while (!this.findChatInput() && performance.now() - startedAt < 2500) {
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
      }
      this.insertChatDraft(text);
      const input = this.findChatInput();
      if (!input) throw new Error("Meet chat input is not open.");
      const sendButton = [...document.querySelectorAll('button[aria-label*="send" i]')].find((button) => isVisible(button) && !button.closest("#signbridge-root"));
      if (sendButton) sendButton.click();
      else input.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", code: "Enter", bubbles: true, cancelable: true }));
      return true;
    }
  };

  // src/gemma.js
  function runtimeMessage(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, (response) => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else if (!response?.ok) reject(new Error(response?.error || "Gemma request failed"));
        else resolve(response.data);
      });
    });
  }
  function checkGemma(settings) {
    return runtimeMessage({ type: "GEMMA_HEALTH", settings });
  }
  function generateAnswer(settings, question, glosses) {
    const schema = {
      type: "object",
      properties: {
        answer: { type: "string" },
        used_glosses: { type: "array", items: { type: "string" } },
        needs_clarification: { type: "boolean" }
      },
      required: ["answer", "used_glosses", "needs_clarification"]
    };
    const system = [
      "You are the constrained language renderer in an accessibility prototype.",
      "Return JSON only and obey the supplied schema.",
      "Write one first-person English sentence of at most 20 words.",
      "Use only facts explicitly represented by the glosses. The question supplies context, not facts about the candidate.",
      "Never add companies, technologies, achievements, metrics, methods, durations, or examples absent from the glosses.",
      "Preserve numbers and negation exactly.",
      "If meaning is insufficient, set needs_clarification true and keep the answer literal."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify({ question, glosses }) }
      ]
    });
  }
  function mapQuestionToSign(settings, question, intents, availableClips) {
    const intentIds = intents.map((intent) => intent.id);
    const clipIds = availableClips.map((clip) => clip.id);
    const schema = {
      type: "object",
      properties: {
        intent: { type: "string", enum: [...intentIds, "UNSUPPORTED"] },
        exact_clip: { type: "string", enum: ["NONE", ...clipIds] },
        clips: { type: "array", items: { type: "string", enum: clipIds }, maxItems: 8 },
        confidence: { type: "number", minimum: 0, maximum: 1 }
      },
      required: ["intent", "exact_clip", "clips", "confidence"]
    };
    const system = [
      "Map an interview question to a constrained library of Indian Sign Language dataset clips.",
      "Return JSON only and obey the schema.",
      "Select exact_clip only when one available phrase label expresses the complete question; otherwise use NONE.",
      "For clips, select the smallest useful ordered sequence from the available labels and never invent a label.",
      "Use UNSUPPORTED when no interview intent is a clear match, but clips may still provide an approximate rendering.",
      "Do not treat ASL and ISL as interchangeable."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        {
          role: "user",
          content: JSON.stringify({
            question,
            supported_intents: intents,
            available_clips: availableClips
          })
        }
      ]
    });
  }
  function refineMeetCaption(settings, caption) {
    const schema = {
      type: "object",
      properties: {
        caption: { type: "string" },
        is_question: { type: "boolean" }
      },
      required: ["caption", "is_question"]
    };
    const system = [
      "You clean one finalized Google Meet caption for accessibility.",
      "Return JSON only and obey the schema.",
      "Preserve the exact meaning, names, technologies, numbers, and negation.",
      "Fix only obvious spacing, casing, punctuation, and unmistakable speech-recognition errors.",
      "Never add facts or rephrase the sentence. Mark whether it is a question."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify({ caption }) }
      ]
    });
  }

  // src/storage.js
  async function getSettings() {
    const result = await chrome.storage.local.get("settings");
    return { ...DEFAULT_SETTINGS, ...result.settings || {} };
  }
  async function saveSettings(settings) {
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    await chrome.storage.local.set({ settings: merged });
    return merged;
  }
  async function getTemplates() {
    const result = await chrome.storage.local.get("gestureTemplates");
    return result.gestureTemplates || {};
  }
  async function saveTemplate(gloss, vector) {
    const templates = await getTemplates();
    templates[gloss] = {
      vector,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await chrome.storage.local.set({ gestureTemplates: templates });
    return templates;
  }
  async function getSequenceTemplates() {
    const result = await chrome.storage.local.get("gestureSequenceTemplates");
    return result.gestureSequenceTemplates || {};
  }
  async function saveSequenceTemplate(gloss, sequence, motion) {
    const templates = await getSequenceTemplates();
    templates[gloss] = {
      sequence,
      motion,
      source: "personal-motion-training",
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await chrome.storage.local.set({ gestureSequenceTemplates: templates });
    return templates;
  }

  // src/clip-store.js
  var DB_NAME = "signbridge-media";
  var DB_VERSION = 1;
  var STORE_NAME = "isl-clips";
  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE_NAME)) {
          database.createObjectStore(STORE_NAME, { keyPath: "intent" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function transact(mode, operation) {
    const database = await openDatabase();
    try {
      return await new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, mode);
        const store = transaction.objectStore(STORE_NAME);
        const request = operation(store);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
    } finally {
      database.close();
    }
  }
  function saveClip(intent, blob) {
    return transact("readwrite", (store) => store.put({
      intent,
      blob,
      mimeType: blob.type,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }));
  }
  function getClip(intent) {
    return transact("readonly", (store) => store.get(intent));
  }
  function deleteClip(intent) {
    return transact("readwrite", (store) => store.delete(intent));
  }
  async function listClips() {
    const records = await transact("readonly", (store) => store.getAll());
    return records || [];
  }

  // src/content.js
  if (!document.getElementById("signbridge-root")) {
    boot().catch((error) => console.error("SignBridge failed to start", error));
  }
  async function boot() {
    let settings = await getSettings();
    const alphabetModel = await loadAlphabetModel();
    const builtInWordTemplates = await loadBuiltInWordTemplates();
    let wordTemplates = { ...builtInWordTemplates, ...await getSequenceTemplates() };
    let templates = await getTemplates();
    const signLibrary = await loadBundledSignLibrary();
    const signClipsById = new Map(signLibrary.clips.map((clip) => [clip.id, clip]));
    const alphabetPoseByLabel = createAlphabetPoseMap(alphabetModel);
    const candidateVocabulary = [.../* @__PURE__ */ new Set([
      ...DEMO_GLOSSES,
      ...signLibrary.clips.map((clip) => clip.label.toUpperCase()),
      ...alphabetModel.classes || []
    ])].sort();
    let glossBuffer = [];
    let latestCaption = "";
    let calibration = null;
    let mediaRecorder = null;
    let recordingChunks = [];
    let recordingIntent = null;
    let signClipUrl = null;
    let liveTimer = null;
    let liveGenerating = false;
    let autoQuestionTimer = null;
    let reverseGenerating = false;
    let queuedQuestion = "";
    let lastTranslatedQuestion = "";
    let lastSpokenText = "";
    let lastSpokenAt = 0;
    let handsPresent = false;
    let captionRevision = 0;
    const hud = new SignBridgeHud({
      startCamera,
      stopCamera,
      calibrate,
      addGloss,
      clearGlosses,
      questionChanged: scheduleAutoQuestion,
      speak,
      copy,
      insertChat,
      saveSettings: handleSaveSettings,
      checkGemma: handleCheckGemma,
      replaySign: () => hud.replaySign(),
      slowerSign: () => hud.slowerSign(),
      recordClip,
      stopRecording,
      deleteClip: handleDeleteClip
    }, candidateVocabulary);
    hud.setSettings(settings);
    hud.renderGlosses(glossBuffer, removeGloss);
    const detector = new StableGestureDetector({
      threshold: settings.detectionThreshold,
      holdMs: Math.max(settings.detectionHoldMs, 750),
      cooldownMs: Math.max(settings.detectionCooldownMs, 1100),
      onCandidate: (match) => {
        hud.setDetected(match);
      },
      onAccept: ({ gloss }) => {
        if (!gloss) return;
        glossBuffer.push(gloss);
        hud.renderGlosses(glossBuffer, removeGloss);
        hud.setStatus(`Sign accepted: ${gloss}`, "success");
        hud.setLiveState("Sign accepted \u2014 continue signing, then lower your hands to speak", true);
      }
    });
    const wordDetector = new TemporalGestureDetector({
      templates: wordTemplates,
      threshold: 0.88,
      minMargin: 0.015,
      holdMs: 650,
      cooldownMs: 1800,
      onCandidate: (match) => {
        if (match?.gloss && match.score >= 0.88 && match.margin >= 0.015) hud.setDetected({ ...match, handPresent: true });
      },
      onAccept: ({ gloss }) => {
        if (!gloss) return;
        detector.reset();
        glossBuffer.push(gloss);
        hud.renderGlosses(glossBuffer, removeGloss);
        hud.setStatus(`Word accepted: ${gloss}`, "success");
        hud.setLiveState("Word accepted \u2014 continue signing, then lower your hands to speak", true);
      }
    });
    const poseStabilityGate = new PoseStabilityGate();
    const vision = new VisionController({
      video: hud.video,
      canvas: hud.canvas,
      fps: settings.inferenceFps,
      onVector(vector) {
        if (!vector) {
          if (handsPresent) {
            handsPresent = false;
            scheduleLiveGeneration();
          }
          poseStabilityGate.reset();
          hud.setDetected(null);
          detector.update({ gloss: null, score: 0 });
          wordDetector.update(null);
          return;
        }
        handsPresent = true;
        cancelLiveTimer();
        if (glossBuffer.length) hud.setLiveState("Signing continues \u2014 audio waits until hands are lowered", true);
        if (calibration) {
          calibration.samples.push(vector);
          const progress = Math.min((performance.now() - calibration.startedAt) / calibration.durationMs, 1);
          hud.setCalibrationState(`Hold ${calibration.gloss} steady\u2026`, progress);
          return;
        }
        if (mediaRecorder?.state === "recording") return;
        const stableVector = poseStabilityGate.update(vector);
        if (!stableVector) {
          detector.update({ gloss: null, score: 0, handPresent: true, unstable: true });
          wordDetector.update(vector);
          return;
        }
        const calibratedMatch = findBestMatch(stableVector, templates);
        const trainedMatch = classifyLandmarkVector(stableVector, alphabetModel);
        const match = calibratedMatch.gloss && calibratedMatch.score >= settings.detectionThreshold ? calibratedMatch : trainedMatch;
        match.handPresent = true;
        detector.update(match);
        wordDetector.update(vector);
      },
      onError(error) {
        hud.setStatus(`Vision error: ${error.message}`, "error");
      }
    });
    const meet = new MeetAdapter({
      async onCaption(caption) {
        const revision = ++captionRevision;
        latestCaption = caption;
        hud.showLatestCaption(caption);
        if (!looksLikeQuestion(caption) || isRecentSpokenCaption(caption)) return;
        hud.setQuestion(caption, "caption");
        scheduleAutoQuestion(caption);
        let finalized = caption;
        try {
          const refined = await refineMeetCaption(settings, caption);
          if (revision !== captionRevision) return;
          const candidate = String(refined.result?.caption || "").trim();
          if (candidate && candidate.length <= 320 && refined.result?.is_question !== false) finalized = candidate;
        } catch {
        }
        if (revision !== captionRevision) return;
        latestCaption = finalized;
        hud.showLatestCaption(finalized);
        hud.setQuestion(finalized, "caption");
        if (finalized !== caption) scheduleAutoQuestion(finalized);
      }
    });
    meet.start();
    await updateClipInventory();
    hud.setLiveState("Always-live mode ready \u2014 start the camera to begin", true);
    hud.setStatus("Always-live mode ready. Meet questions and signed responses are processed automatically.", "success");
    async function startCamera() {
      try {
        hud.setStatus("Starting camera and MediaPipe\u2026", "info");
        await vision.start();
        hud.setCameraRunning(true);
        const calibratedCount = Object.keys(templates).length;
        const personalWordCount = Object.values(wordTemplates).filter((template) => template.source === "personal-motion-training").length;
        hud.setStatus(`Camera ready. ${Object.keys(builtInWordTemplates).length} words \xB7 ${alphabetModel.classes?.length || 0} trained letters/digits loaded${personalWordCount > 0 ? ` \xB7 ${personalWordCount} personal word motions` : ""}${calibratedCount > 0 ? ` \xB7 ${calibratedCount} custom poses` : ""}.`, "success");
      } catch (error) {
        hud.setCameraRunning(false);
        hud.setStatus(`Camera unavailable: ${error.message}`, "error");
      }
    }
    function stopCamera() {
      cancelLiveTimer();
      handsPresent = false;
      if (mediaRecorder?.state === "recording") mediaRecorder.stop();
      vision.stop();
      detector.reset();
      wordDetector.reset();
      poseStabilityGate.reset();
      hud.setCameraRunning(false);
      hud.setDetected(null);
      hud.setStatus("Camera stopped.", "info");
    }
    async function calibrate() {
      if (!vision.getStream()) {
        await startCamera();
        if (!vision.getStream()) return;
      }
      if (calibration) return;
      const gloss = hud.getCalibrationGloss();
      const staticPose = /^[A-Z1-9]$/.test(gloss);
      hud.setCalibrationState(staticPose ? `Get ready to hold ${gloss}\u2026` : `Get ready to perform ${gloss} once\u2026`);
      await delay(650);
      calibration = {
        gloss,
        samples: [],
        startedAt: performance.now(),
        durationMs: staticPose ? 1700 : 3e3
      };
      await delay(calibration.durationMs);
      const completed = calibration;
      calibration = null;
      const minimumSamples = staticPose ? 8 : 18;
      if (completed.samples.length < minimumSamples) {
        hud.setCalibrationState(`Training failed: only ${completed.samples.length}/${minimumSamples} usable frames. Keep both hands visible and try again.`);
        return;
      }
      if (staticPose) {
        const vector = averageVectors(completed.samples);
        templates = await saveTemplate(gloss, vector);
      } else {
        const sequence = resampleSequence(completed.samples, 12);
        wordTemplates = { ...builtInWordTemplates, ...await saveSequenceTemplate(gloss, sequence, sequenceMotionEnergy(sequence)) };
        wordDetector.templates = wordTemplates;
      }
      detector.reset();
      wordDetector.reset();
      poseStabilityGate.reset();
      hud.setCalibrationState(staticPose ? `${gloss} pose trained from ${completed.samples.length} frames.` : `${gloss} motion trained from ${completed.samples.length} frames.`);
      hud.setStatus(`${gloss} personal ${staticPose ? "pose" : "motion"} saved locally.`, "success");
    }
    function removeGloss(index) {
      glossBuffer.splice(index, 1);
      hud.renderGlosses(glossBuffer, removeGloss);
      scheduleLiveGeneration();
    }
    function addGloss() {
      const gloss = hud.getCalibrationGloss();
      glossBuffer.push(gloss);
      hud.renderGlosses(glossBuffer, removeGloss);
      hud.setStatus(`Added ${gloss} manually.`, "success");
      scheduleLiveGeneration();
    }
    function clearGlosses() {
      cancelLiveTimer();
      glossBuffer = [];
      detector.reset();
      wordDetector.reset();
      poseStabilityGate.reset();
      hud.renderGlosses(glossBuffer, removeGloss);
      hud.setStatus("Gloss buffer cleared.", "info");
    }
    async function handleGenerateAnswer() {
      const question = hud.getQuestion();
      if (!question) {
        hud.setStatus("Add the interviewer\u2019s question first.", "warn");
        return;
      }
      if (!glossBuffer.length) {
        hud.setStatus("Sign or add at least one calibrated gloss first.", "warn");
        return;
      }
      await generateFromGlosses(question, [...glossBuffer], false);
    }
    async function generateFromGlosses(question, glosses, live) {
      hud.setStatus(live ? "Live mode: translating the signed phrase\u2026" : "Gemma 4 is rendering the signed meaning\u2026", "info");
      try {
        const response = await generateAnswer(settings, question, collapseFingerspelling(glosses));
        const result = response.result || {};
        const answer = String(result.answer || "").trim();
        if (!answer) throw new Error("Gemma returned an empty answer");
        hud.setAnswer(answer, Boolean(result.needs_clarification));
        hud.setMetrics(response.metrics);
        if (live && !result.needs_clarification) {
          speakText(answer);
          let deliveredToMeet = false;
          try {
            await meet.sendChatMessage(`\u{1F91F} Candidate via SignBridge: ${answer}`);
            deliveredToMeet = true;
          } catch {
          }
          removeProcessedGlosses(glosses);
          hud.setLiveState("Spoken \u2014 listening for the next phrase", true);
          hud.setStatus(deliveredToMeet ? "Live response spoken locally and transmitted in Meet chat. Listening continues." : "Live response spoken locally. Open Meet chat for guaranteed remote text delivery.", deliveredToMeet ? "success" : "warn");
        } else if (live) {
          hud.setLiveState("Clarification needed \u2014 nothing was spoken", true);
        } else if (!result.needs_clarification) {
          hud.setStatus("Answer ready. Review and approve it before delivery.", "success");
        }
      } catch (error) {
        const literal = `My response is: ${glosses.join(" ").toLowerCase()}.`;
        hud.setAnswer(literal, true);
        hud.setMetrics(null);
        if (live) {
          hud.setLiveState("Live translation failed \u2014 nothing was spoken", true);
          hud.setStatus(`Live Gemma unavailable (${error.message}). Nothing was spoken automatically.`, "warn");
        } else {
          hud.setStatus(`Gemma unavailable (${error.message}). Showing a literal fallback.`, "warn");
        }
      }
    }
    function scheduleLiveGeneration() {
      if (!glossBuffer.length || handsPresent) return;
      cancelLiveTimer();
      hud.setLiveState("Hands lowered \u2014 translating the completed phrase", true);
      liveTimer = setTimeout(flushLivePhrase, Math.max(settings.livePauseMs || 0, 2e3));
    }
    async function flushLivePhrase() {
      liveTimer = null;
      if (!glossBuffer.length) return;
      if (handsPresent) return;
      if (liveGenerating) {
        scheduleLiveGeneration();
        return;
      }
      const question = hud.getQuestion();
      if (!question) {
        hud.setLiveState("Add or capture the interviewer question first", true);
        hud.setStatus("Live audio needs the interviewer\u2019s question for context.", "warn");
        return;
      }
      const phrase = [...glossBuffer];
      liveGenerating = true;
      try {
        await generateFromGlosses(question, phrase, true);
      } finally {
        liveGenerating = false;
        if (glossBuffer.length) scheduleLiveGeneration();
      }
    }
    function removeProcessedGlosses(processed) {
      const samePrefix = processed.every((gloss, index) => glossBuffer[index] === gloss);
      if (samePrefix) glossBuffer.splice(0, processed.length);
      hud.renderGlosses(glossBuffer, removeGloss);
    }
    function cancelLiveTimer() {
      if (liveTimer) clearTimeout(liveTimer);
      liveTimer = null;
    }
    function scheduleAutoQuestion(question) {
      const normalized = String(question || "").trim();
      if (!normalized || normalized === lastTranslatedQuestion) return;
      clearTimeout(autoQuestionTimer);
      hud.setStatus("Interviewer question detected \u2014 preparing ISL\u2026", "info");
      autoQuestionTimer = setTimeout(() => translateToSign(normalized), 450);
    }
    async function translateToSign(questionOverride = "") {
      const question = questionOverride || hud.getQuestion();
      if (!question) {
        return;
      }
      if (reverseGenerating) {
        queuedQuestion = question;
        return;
      }
      const localExact = signLibrary.clips.find((clip) => normalizePhrase(clip.label) === normalizePhrase(question));
      if (localExact) {
        hud.showSignResult({
          question,
          glosses: [localExact.label.toUpperCase()],
          clipUrl: null,
          vectorSequences: createWordVectorSequences([localExact], wordTemplates),
          exact: true,
          quality: "Generated avatar \xB7 dataset motion"
        });
        lastTranslatedQuestion = question;
        hud.setStatus("Interviewer question detected and exact dataset animation started.", "warn");
        return;
      }
      const spellingSequence = createFingerspellingSequence(question);
      if (spellingSequence.vectors.length) {
        hud.showSignResult({
          question,
          glosses: ["LIVE FINGERSPELLING"],
          clipUrl: null,
          vectorSequences: [spellingSequence],
          exact: false,
          quality: "Live fingerspelling \xB7 approximate"
        });
        hud.setStatus("Question detected \u2014 fingerspelling started while Gemma selects the best ISL clips.", "info");
      }
      reverseGenerating = true;
      hud.setStatus("Gemma 4 is mapping the question to verified ISL\u2026", "info");
      try {
        const availableClips = signLibrary.clips.map(({ id, label, kind }) => ({ id, label, kind }));
        const response = await mapQuestionToSign(settings, question, INTENTS, availableClips);
        const result = response.result || {};
        const validIntent = INTENTS.some((item) => item.id === result.intent) ? result.intent : "UNSUPPORTED";
        const mappedExactBuiltIn = result.exact_clip !== "NONE" ? signClipsById.get(result.exact_clip) : null;
        const selectedIds = mappedExactBuiltIn ? [mappedExactBuiltIn.id] : Array.isArray(result.clips) ? result.clips.filter((id) => signClipsById.has(id)).slice(0, 8) : [];
        const selectedClips = selectedIds.map((id) => signClipsById.get(id));
        const glosses = selectedClips.map((item) => item.label.toUpperCase());
        const clip = validIntent === "UNSUPPORTED" ? null : await getClip(validIntent);
        if (signClipUrl) URL.revokeObjectURL(signClipUrl);
        signClipUrl = clip?.blob ? URL.createObjectURL(clip.blob) : null;
        const datasetSequences = createWordVectorSequences(selectedClips, wordTemplates);
        const usingFingerspelling = !signClipUrl && !datasetSequences.length && spellingSequence.vectors.length;
        const vectorSequences = signClipUrl ? [] : datasetSequences.length ? datasetSequences : usingFingerspelling ? [spellingSequence] : [];
        const quality = signClipUrl ? "Verified signer recording" : mappedExactBuiltIn ? "Generated avatar \xB7 dataset motion" : datasetSequences.length ? "Generated avatar sequence \xB7 approximate" : usingFingerspelling ? "Live fingerspelling \xB7 approximate" : "Unsupported";
        hud.showSignResult({
          question,
          glosses,
          clipUrl: signClipUrl,
          vectorSequences,
          exact: Boolean(signClipUrl || mappedExactBuiltIn),
          quality,
          message: validIntent === "UNSUPPORTED" ? "This question is outside the supported interview intents. Read the caption; only available dataset concepts are shown." : `No custom recording or useful dataset sequence is available for ${validIntent}.`
        });
        hud.setMetrics(response.metrics);
        if (signClipUrl) hud.setStatus("Verified ISL signer recording is playing.", "success");
        else if (mappedExactBuiltIn) hud.setStatus("Exact dataset phrase is playing. Review its ISL accuracy before the demo.", "warn");
        else if (datasetSequences.length) hud.setStatus("Approximate dataset sequence is playing with the original caption retained.", "warn");
        else if (usingFingerspelling) hud.setStatus("No phrase match; the question is being fingerspelled with its caption retained.", "warn");
        else hud.setStatus("No matching dataset clip is available. Caption retained; no false signing shown.", "warn");
        lastTranslatedQuestion = question;
      } catch (error) {
        hud.showSignResult({
          question,
          glosses: spellingSequence.vectors.length ? ["LIVE FINGERSPELLING"] : [],
          clipUrl: null,
          vectorSequences: spellingSequence.vectors.length ? [spellingSequence] : [],
          exact: false,
          quality: spellingSequence.vectors.length ? "Generated fingerspelling avatar \xB7 approximate" : "Unsupported",
          message: `Could not map this question: ${error.message}`
        });
        hud.setStatus(spellingSequence.vectors.length ? "Gemma mapping failed; live fingerspelling continues." : `Question-to-ISL failed: ${error.message}`, "warn");
      } finally {
        reverseGenerating = false;
        if (queuedQuestion && queuedQuestion !== question) {
          const nextQuestion = queuedQuestion;
          queuedQuestion = "";
          scheduleAutoQuestion(nextQuestion);
        }
      }
    }
    function useLatestCaption() {
      if (!latestCaption) {
        hud.setStatus("No Meet caption detected. Turn captions on or type the question.", "warn");
        return;
      }
      hud.setQuestion(latestCaption, "caption");
      hud.setStatus("Latest Meet caption selected.", "success");
    }
    function speak() {
      const answer = hud.getAnswer();
      if (!answer) return;
      speakText(answer);
      hud.setStatus("Speaking approved answer locally.", "success");
    }
    function speakText(text) {
      lastSpokenText = text;
      lastSpokenAt = Date.now();
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "en-IN";
      utterance.rate = settings.speechRate;
      speechSynthesis.speak(utterance);
    }
    function isRecentSpokenCaption(caption) {
      if (!lastSpokenText || Date.now() - lastSpokenAt > 15e3) return false;
      const captionText = normalizePhrase(caption);
      const spokenText = normalizePhrase(lastSpokenText);
      return captionText.length > 10 && (captionText.includes(spokenText) || spokenText.includes(captionText));
    }
    function createFingerspellingSequence(text) {
      const vectors = [];
      for (const character of String(text || "").toUpperCase().slice(0, 80)) {
        const vector = alphabetPoseByLabel.get(character);
        if (vector) vectors.push(vector);
        else if (/\s/.test(character) && vectors.length) vectors.push(null, null);
      }
      return { fps: 3, vectors };
    }
    async function copy() {
      const answer = hud.getAnswer();
      if (!answer) return;
      await navigator.clipboard.writeText(answer);
      hud.setStatus("Approved answer copied.", "success");
    }
    function insertChat() {
      const answer = hud.getAnswer();
      if (!answer) return;
      try {
        meet.insertChatDraft(`\u{1F91F} Candidate via SignBridge: ${answer}`);
        hud.setStatus("Draft inserted. Review it in Meet and press Send yourself.", "success");
      } catch (error) {
        navigator.clipboard.writeText(answer).catch(() => {
        });
        hud.setStatus(`${error.message} The answer was copied instead.`, "warn");
      }
    }
    async function handleSaveSettings() {
      const form = hud.getSettingsForm();
      if (!form.endpoint || !form.model) {
        hud.setStatus("Endpoint and model are required.", "warn");
        return;
      }
      settings = await saveSettings({ ...settings, ...form });
      hud.setSettings(settings);
      hud.setStatus("Gemma settings saved locally.", "success");
    }
    async function handleCheckGemma() {
      await handleSaveSettings();
      hud.setStatus("Checking Gemma 4 endpoint\u2026", "info");
      try {
        const health = await checkGemma(settings);
        if (health.installed) hud.setStatus(`Gemma 4 ready: ${settings.model}`, "success");
        else hud.setStatus(`Endpoint is online, but ${settings.model} is not installed.`, "warn");
      } catch (error) {
        hud.setStatus(`Gemma endpoint unavailable: ${error.message}`, "error");
      }
    }
    async function recordClip() {
      if (!vision.getStream()) {
        await startCamera();
        if (!vision.getStream()) return;
      }
      if (mediaRecorder?.state === "recording") return;
      recordingIntent = hud.getClipIntent();
      recordingChunks = [];
      const mimeCandidates = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
      const mimeType = mimeCandidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || "";
      mediaRecorder = new MediaRecorder(vision.getStream(), mimeType ? { mimeType } : void 0);
      mediaRecorder.ondataavailable = (event) => {
        if (event.data?.size) recordingChunks.push(event.data);
      };
      mediaRecorder.onerror = (event) => {
        hud.setRecording(false, `Recording error: ${event.error?.message || "unknown error"}`);
      };
      mediaRecorder.onstop = async () => {
        const blob = new Blob(recordingChunks, { type: mediaRecorder.mimeType || "video/webm" });
        if (blob.size < 1e3) {
          hud.setRecording(false, "Recording was empty. Try again.");
          return;
        }
        await saveClip(recordingIntent, blob);
        hud.setRecording(false, `${recordingIntent} saved locally (${(blob.size / 1024).toFixed(0)} KB).`);
        hud.setStatus("Verified ISL phrase clip saved. Review it before the demo.", "success");
        await updateClipInventory();
      };
      mediaRecorder.start(250);
      hud.setRecording(true, `Recording ${recordingIntent}\u2026 perform the complete verified ISL phrase.`);
      hud.setStatus("Recording ISL phrase. Press Stop & save when complete.", "warn");
    }
    function stopRecording() {
      if (mediaRecorder?.state === "recording") mediaRecorder.stop();
    }
    async function handleDeleteClip() {
      const intent = hud.getClipIntent();
      await deleteClip(intent);
      hud.setRecording(false, `${intent} recording deleted.`);
      hud.setStatus("ISL phrase clip deleted.", "info");
      await updateClipInventory();
    }
    async function updateClipInventory() {
      const clips = await listClips();
      const recorded = new Set(clips.map((clip) => clip.intent));
      const count = INTENTS.filter((intent) => recorded.has(intent.id)).length;
      hud.setRecording(false, `${signLibrary.clips.length} bundled dataset clips \xB7 ${count}/${INTENTS.length} verified custom phrases.`);
    }
  }
  function delay(milliseconds) {
    return new Promise((resolve) => setTimeout(resolve, milliseconds));
  }
  function normalizePhrase(value) {
    return String(value || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  }
  function looksLikeQuestion(value) {
    const text = normalizePhrase(value);
    return /\b(what|why|how|when|where|who|which|can|could|would|will|do|does|did|have|has|tell|describe|explain|please|walk)\b/.test(text);
  }
  function collapseFingerspelling(glosses) {
    const collapsed = [];
    let letters = "";
    const flush = () => {
      if (letters) collapsed.push(`FINGERSPELL:${letters}`);
      letters = "";
    };
    for (const gloss of glosses) {
      if (/^[A-Z1-9]$/.test(gloss)) letters += gloss;
      else {
        flush();
        collapsed.push(gloss);
      }
    }
    flush();
    return collapsed;
  }
  function createAlphabetPoseMap(model) {
    const poses = /* @__PURE__ */ new Map();
    if (!Array.isArray(model?.classes) || !Array.isArray(model?.centroids)) return poses;
    model.classes.forEach((label, classIndex) => {
      const centroid = model.centroids[classIndex];
      if (!Array.isArray(centroid) || centroid.length !== model.featureCount) return;
      const vector = centroid.map((value, featureIndex) => value * (model.scale?.[featureIndex] || 1) + (model.mean?.[featureIndex] || 0));
      poses.set(label, vector);
    });
    return poses;
  }
  function createWordVectorSequences(clips, templates) {
    return clips.flatMap((clip) => {
      const template = templates[clip.label.toUpperCase()];
      if (!Array.isArray(template?.sequence) || !template.sequence.length) return [];
      return [{ fps: 10, vectors: template.sequence }];
    });
  }
  async function loadBundledSignLibrary() {
    try {
      const response = await fetch(chrome.runtime.getURL("assets/signs/library.json"));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const manifest = await response.json();
      return { ...manifest, clips: Array.isArray(manifest.clips) ? manifest.clips : [] };
    } catch (error) {
      console.warn("SignBridge bundled sign library unavailable", error);
      return { version: 1, clips: [] };
    }
  }
  async function loadAlphabetModel() {
    try {
      const response = await fetch(chrome.runtime.getURL("assets/signs/alphabet-model.json"));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const model = await response.json();
      return model.classes && Array.isArray(model.classes) ? model : { classes: [] };
    } catch (error) {
      console.warn("SignBridge trained alphabet model unavailable", error);
      return { classes: [] };
    }
  }
  async function loadBuiltInWordTemplates() {
    try {
      const response = await fetch(chrome.runtime.getURL("assets/signs/word-templates.json"));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const manifest = await response.json();
      return manifest.templates && typeof manifest.templates === "object" ? manifest.templates : {};
    } catch (error) {
      console.warn("SignBridge word recognition templates unavailable", error);
      return {};
    }
  }
})();
