(() => {
  var __require = /* @__PURE__ */ ((x3) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x3, {
    get: (a2, b2) => (typeof require !== "undefined" ? require : a2)[b2]
  }) : x3)(function(x3) {
    if (typeof require !== "undefined") return require.apply(this, arguments);
    throw Error('Dynamic require of "' + x3 + '" is not supported');
  });

  // node_modules/@mediapipe/tasks-vision/vision_bundle.mjs
  var t = "undefined" != typeof self ? self : {};
  function e(e2, r2) {
    t: {
      for (var n2 = ["CLOSURE_FLAGS"], i2 = t, s2 = 0; s2 < n2.length; s2++) if (null == (i2 = i2[n2[s2]])) {
        n2 = null;
        break t;
      }
      n2 = i2;
    }
    return null != (e2 = n2 && n2[e2]) ? e2 : r2;
  }
  function r(e2, r2) {
    e2 = e2.split(".");
    for (var n2, i2 = t; e2.length && (n2 = e2.shift()); ) e2.length || void 0 === r2 ? i2 = i2[n2] && i2[n2] !== Object.prototype[n2] ? i2[n2] : i2[n2] = {} : i2[n2] = r2;
  }
  function n() {
    throw Error("Invalid UTF8");
  }
  function i(t2, e2) {
    return e2 = String.fromCharCode.apply(null, e2), null == t2 ? e2 : t2 + e2;
  }
  var s;
  var o;
  var a = void 0;
  var h = "undefined" != typeof TextDecoder;
  var u = "undefined" != typeof TextEncoder;
  function c(t2) {
    if (u) t2 = (o ||= new TextEncoder()).encode(t2);
    else {
      let r2 = 0, n2 = new Uint8Array(3 * t2.length);
      for (let i2 = 0; i2 < t2.length; i2++) {
        var e2 = t2.charCodeAt(i2);
        if (e2 < 128) n2[r2++] = e2;
        else {
          if (e2 < 2048) n2[r2++] = e2 >> 6 | 192;
          else {
            if (e2 >= 55296 && e2 <= 57343) {
              if (e2 <= 56319 && i2 < t2.length) {
                let s2 = t2.charCodeAt(++i2);
                if (s2 >= 56320 && s2 <= 57343) {
                  e2 = 1024 * (e2 - 55296) + s2 - 56320 + 65536, n2[r2++] = e2 >> 18 | 240, n2[r2++] = e2 >> 12 & 63 | 128, n2[r2++] = e2 >> 6 & 63 | 128, n2[r2++] = 63 & e2 | 128;
                  continue;
                }
                i2--;
              }
              e2 = 65533;
            }
            n2[r2++] = e2 >> 12 | 224, n2[r2++] = e2 >> 6 & 63 | 128;
          }
          n2[r2++] = 63 & e2 | 128;
        }
      }
      t2 = r2 === n2.length ? n2 : n2.subarray(0, r2);
    }
    return t2;
  }
  function l(e2) {
    t.setTimeout(() => {
      throw e2;
    }, 0);
  }
  var d = e(610401301, false);
  var f = e(748402147, true);
  function p() {
    var e2 = t.navigator;
    return e2 && (e2 = e2.userAgent) ? e2 : "";
  }
  var m;
  var g = t.navigator;
  function v(t2) {
    return v[" "](t2), t2;
  }
  m = g && g.userAgentData || null, v[" "] = function() {
  };
  var _ = {};
  var y = null;
  function E(t2) {
    var e2 = t2.length, r2 = 3 * e2 / 4;
    r2 % 3 ? r2 = Math.floor(r2) : -1 != "=.".indexOf(t2[e2 - 1]) && (r2 = -1 != "=.".indexOf(t2[e2 - 2]) ? r2 - 2 : r2 - 1);
    var n2 = new Uint8Array(r2), i2 = 0;
    return (function(t3, e3) {
      function r3(e4) {
        for (; n3 < t3.length; ) {
          let e5 = t3.charAt(n3++), r4 = y[e5];
          if (null != r4) return r4;
          if (!/^[\s\xa0]*$/.test(e5)) throw Error("Unknown base64 encoding at char: " + e5);
        }
        return e4;
      }
      A();
      for (var n3 = 0; ; ) {
        let t4 = r3(-1), n4 = r3(0), i3 = r3(64), s2 = r3(64);
        if (64 === s2 && -1 === t4) break;
        e3(t4 << 2 | n4 >> 4), 64 != i3 && (e3(n4 << 4 & 240 | i3 >> 2), 64 != s2 && e3(i3 << 6 & 192 | s2));
      }
    })(t2, function(t3) {
      n2[i2++] = t3;
    }), i2 !== r2 ? n2.subarray(0, i2) : n2;
  }
  function A() {
    if (!y) {
      y = {};
      var t2 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), e2 = ["+/=", "+/", "-_=", "-_.", "-_"];
      for (let r2 = 0; r2 < 5; r2++) {
        let n2 = t2.concat(e2[r2].split(""));
        _[r2] = n2;
        for (let t3 = 0; t3 < n2.length; t3++) {
          let e3 = n2[t3];
          void 0 === y[e3] && (y[e3] = t3);
        }
      }
    }
  }
  var w = "undefined" != typeof Uint8Array;
  var T = !(!(!!d && (!!m && m.brands.length > 0)) && (-1 != p().indexOf("Trident") || -1 != p().indexOf("MSIE"))) && "function" == typeof btoa;
  var b = /[-_.]/g;
  var k = { "-": "+", _: "/", ".": "=" };
  function S(t2) {
    return k[t2] || "";
  }
  function L(t2) {
    if (!T) return E(t2);
    t2 = b.test(t2) ? t2.replace(b, S) : t2, t2 = atob(t2);
    var e2 = new Uint8Array(t2.length);
    for (let r2 = 0; r2 < t2.length; r2++) e2[r2] = t2.charCodeAt(r2);
    return e2;
  }
  function x(t2) {
    return w && null != t2 && t2 instanceof Uint8Array;
  }
  var R = {};
  function I() {
    return C ||= new N(null, R);
  }
  function F(t2) {
    M(R);
    var e2 = t2.h;
    return null == (e2 = null == e2 || x(e2) ? e2 : "string" == typeof e2 ? L(e2) : null) ? e2 : t2.h = e2;
  }
  var C;
  var N = class {
    i() {
      return new Uint8Array(F(this) || 0);
    }
    constructor(t2, e2) {
      if (M(e2), this.h = t2, null != t2 && 0 === t2.length) throw Error("ByteString should be constructed with non-empty values");
    }
  };
  function M(t2) {
    if (t2 !== R) throw Error("illegal external caller");
  }
  function O(t2, e2) {
    t2.__closure__error__context__984382 || (t2.__closure__error__context__984382 = {}), t2.__closure__error__context__984382.severity = e2;
  }
  var D = void 0;
  function P(t2) {
    return O(t2 = Error(t2), "warning"), t2;
  }
  function $(t2, e2) {
    if (null != t2) {
      var r2 = D ??= {}, n2 = r2[t2] || 0;
      n2 >= e2 || (r2[t2] = n2 + 1, O(t2 = Error(), "incident"), l(t2));
    }
  }
  function U() {
    return "function" == typeof BigInt;
  }
  var B = "function" == typeof Symbol && "symbol" == typeof Symbol();
  function j(t2, e2, r2 = false) {
    return "function" == typeof Symbol && "symbol" == typeof Symbol() ? r2 && Symbol.for && t2 ? Symbol.for(t2) : null != t2 ? Symbol(t2) : Symbol() : e2;
  }
  var G;
  var V = j("jas", void 0, true);
  var H = j(void 0, "0di");
  var K = j(void 0, "1oa");
  var X = j(void 0, Symbol());
  var W = j(void 0, "0ub");
  var z = j(void 0, "0ubs");
  var Y = j(void 0, "0ubsb");
  var q = j(void 0, "0actk");
  var J = j("m_m", "lb", true);
  var Z = j();
  var Q = { Wa: { value: 0, configurable: true, writable: true, enumerable: false } };
  var tt = Object.defineProperties;
  var et = B ? V : "Wa";
  var rt = [];
  function nt(t2, e2) {
    B || et in t2 || tt(t2, Q), t2[et] |= e2;
  }
  function it(t2, e2) {
    B || et in t2 || tt(t2, Q), t2[et] = e2;
  }
  function st(t2) {
    return nt(t2, 34), t2;
  }
  function ot(t2) {
    return nt(t2, 8192), t2;
  }
  it(rt, 7), G = Object.freeze(rt);
  var at = {};
  function ht(t2) {
    return null != t2 && t2[J] === at;
  }
  function ut(t2, e2) {
    return void 0 === e2 ? t2.i !== ct && !!(2 & t2.B[et]) : !!(2 & e2) && t2.i !== ct;
  }
  var ct = {};
  function lt(t2, e2) {
    if (null != t2) {
      if ("string" == typeof t2) t2 = t2 ? new N(t2, R) : I();
      else if (t2.constructor !== N) if (x(t2)) t2 = t2.length ? new N(new Uint8Array(t2), R) : I();
      else {
        if (!e2) throw Error();
        t2 = void 0;
      }
    }
    return t2;
  }
  var dt = class {
    constructor(t2, e2, r2) {
      this.h = t2, this.i = e2, this.l = r2;
    }
    next() {
      var t2 = this.h.next();
      return t2.done || (t2.value = this.i.call(this.l, t2.value)), t2;
    }
    [Symbol.iterator]() {
      return this;
    }
  };
  function ft(t2, e2, r2) {
    var n2, i2 = 128 & e2 ? 0 : -1, s2 = t2.length;
    (n2 = !!s2) && (n2 = null != (n2 = t2[s2 - 1]) && "object" == typeof n2 && n2.constructor === Object);
    var o2 = s2 + (n2 ? -1 : 0);
    for (e2 = 128 & e2 ? 1 : 0; e2 < o2; e2++) r2(e2 - i2, t2[e2]);
    if (n2) {
      t2 = t2[s2 - 1];
      for (let e3 in t2) !isNaN(e3) && r2(+e3, t2[e3]);
    }
  }
  Object.freeze({});
  var pt = {};
  function mt(t2) {
    return 128 & t2 ? pt : void 0;
  }
  function gt(t2) {
    return t2.jb = true, t2;
  }
  var vt = gt((t2) => "number" == typeof t2);
  var _t = gt((t2) => "string" == typeof t2);
  var yt = gt((t2) => "boolean" == typeof t2);
  var Et = "function" == typeof t.BigInt && "bigint" == typeof t.BigInt(0);
  function At(t2) {
    var e2 = t2;
    if (_t(e2)) {
      if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(e2)) throw Error(String(e2));
    } else if (vt(e2) && !Number.isSafeInteger(e2)) throw Error(String(e2));
    return Et ? BigInt(t2) : t2 = yt(t2) ? t2 ? "1" : "0" : _t(t2) ? t2.trim() || "0" : String(t2);
  }
  var wt = gt((t2) => Et ? t2 >= bt && t2 <= St : "-" === t2[0] ? Lt(t2, Tt) : Lt(t2, kt));
  var Tt = Number.MIN_SAFE_INTEGER.toString();
  var bt = Et ? BigInt(Number.MIN_SAFE_INTEGER) : void 0;
  var kt = Number.MAX_SAFE_INTEGER.toString();
  var St = Et ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
  function Lt(t2, e2) {
    if (t2.length > e2.length) return false;
    if (t2.length < e2.length || t2 === e2) return true;
    for (let r2 = 0; r2 < t2.length; r2++) {
      let n2 = t2[r2], i2 = e2[r2];
      if (n2 > i2) return false;
      if (n2 < i2) return true;
    }
  }
  var xt;
  var Rt = "function" == typeof Uint8Array.prototype.slice;
  var It = 0;
  var Ft = 0;
  function Ct(t2) {
    var e2 = t2 >>> 0;
    It = e2, Ft = (t2 - e2) / 4294967296 >>> 0;
  }
  function Nt(t2) {
    if (t2 < 0) {
      Ct(-t2);
      let [e2, r2] = Gt(It, Ft);
      It = e2 >>> 0, Ft = r2 >>> 0;
    } else Ct(t2);
  }
  function Mt(t2) {
    var e2 = xt ||= new DataView(new ArrayBuffer(8));
    e2.setFloat32(0, +t2, true), Ft = 0, It = e2.getUint32(0, true);
  }
  function Ot(t2, e2) {
    var r2 = 4294967296 * e2 + (t2 >>> 0);
    return Number.isSafeInteger(r2) ? r2 : $t(t2, e2);
  }
  function Dt(t2, e2) {
    return At(U() ? BigInt.asUintN(64, (BigInt(e2 >>> 0) << BigInt(32)) + BigInt(t2 >>> 0)) : $t(t2, e2));
  }
  function Pt(t2, e2) {
    return U() ? At(BigInt.asIntN(64, (BigInt.asUintN(32, BigInt(e2)) << BigInt(32)) + BigInt.asUintN(32, BigInt(t2)))) : At(Bt(t2, e2));
  }
  function $t(t2, e2) {
    if (t2 >>>= 0, (e2 >>>= 0) <= 2097151) var r2 = "" + (4294967296 * e2 + t2);
    else U() ? r2 = "" + (BigInt(e2) << BigInt(32) | BigInt(t2)) : (t2 = (16777215 & t2) + 6777216 * (r2 = 16777215 & (t2 >>> 24 | e2 << 8)) + 6710656 * (e2 = e2 >> 16 & 65535), r2 += 8147497 * e2, e2 *= 2, t2 >= 1e7 && (r2 += t2 / 1e7 >>> 0, t2 %= 1e7), r2 >= 1e7 && (e2 += r2 / 1e7 >>> 0, r2 %= 1e7), r2 = e2 + Ut(r2) + Ut(t2));
    return r2;
  }
  function Ut(t2) {
    return t2 = String(t2), "0000000".slice(t2.length) + t2;
  }
  function Bt(t2, e2) {
    if (2147483648 & e2) if (U()) t2 = "" + (BigInt(0 | e2) << BigInt(32) | BigInt(t2 >>> 0));
    else {
      let [r2, n2] = Gt(t2, e2);
      t2 = "-" + $t(r2, n2);
    }
    else t2 = $t(t2, e2);
    return t2;
  }
  function jt(t2) {
    if (t2.length < 16) Nt(Number(t2));
    else if (U()) t2 = BigInt(t2), It = Number(t2 & BigInt(4294967295)) >>> 0, Ft = Number(t2 >> BigInt(32) & BigInt(4294967295));
    else {
      let e2 = +("-" === t2[0]);
      Ft = It = 0;
      let r2 = t2.length;
      for (let n2 = e2, i2 = (r2 - e2) % 6 + e2; i2 <= r2; n2 = i2, i2 += 6) {
        let e3 = Number(t2.slice(n2, i2));
        Ft *= 1e6, (It = 1e6 * It + e3) >= 4294967296 && (Ft += Math.trunc(It / 4294967296), Ft >>>= 0, It >>>= 0);
      }
      if (e2) {
        let [t3, e3] = Gt(It, Ft);
        It = t3, Ft = e3;
      }
    }
  }
  function Gt(t2, e2) {
    return e2 = ~e2, t2 ? t2 = 1 + ~t2 : e2 += 1, [t2, e2];
  }
  function Vt(t2) {
    return Array.prototype.slice.call(t2);
  }
  var Ht = "function" == typeof BigInt ? BigInt.asIntN : void 0;
  var Kt = "function" == typeof BigInt ? BigInt.asUintN : void 0;
  var Xt = Number.isSafeInteger;
  var Wt = Number.isFinite;
  var zt = Math.trunc;
  var Yt = At(0);
  function qt(t2) {
    if ("number" != typeof t2) throw Error(`Value of float/double field must be a number, found ${typeof t2}: ${t2}`);
    return t2;
  }
  function Jt(t2) {
    return null == t2 || "number" == typeof t2 ? t2 : "NaN" === t2 || "Infinity" === t2 || "-Infinity" === t2 ? Number(t2) : void 0;
  }
  function Zt(t2) {
    if ("boolean" != typeof t2) {
      var e2 = typeof t2;
      throw Error(`Expected boolean but got ${"object" != e2 ? e2 : t2 ? Array.isArray(t2) ? "array" : e2 : "null"}: ${t2}`);
    }
    return t2;
  }
  var Qt = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
  function te(t2) {
    switch (typeof t2) {
      case "bigint":
        return true;
      case "number":
        return Wt(t2);
      case "string":
        return Qt.test(t2);
      default:
        return false;
    }
  }
  function ee(t2) {
    if (null != t2) {
      if (!Wt(t2)) throw P("enum");
      t2 |= 0;
    }
    return t2;
  }
  function re(t2) {
    if (null == t2) return t2;
    if ("string" == typeof t2 && t2) t2 = +t2;
    else if ("number" != typeof t2) return;
    return Wt(t2) ? 0 | t2 : void 0;
  }
  function ne(t2) {
    if (null == t2) return t2;
    if ("string" == typeof t2 && t2) t2 = +t2;
    else if ("number" != typeof t2) return;
    return Wt(t2) ? t2 >>> 0 : void 0;
  }
  function ie(t2, e2) {
    if (e2 ??= 1024, !te(t2)) throw P("int64");
    var r2 = typeof t2;
    switch (e2) {
      case 512:
        switch (r2) {
          case "string":
            return ce(t2);
          case "bigint":
            return String(Ht(64, t2));
          default:
            return ue(t2);
        }
      case 1024:
        switch (r2) {
          case "string":
            return le(t2);
          case "bigint":
            return At(Ht(64, t2));
          default:
            return de(t2);
        }
      case 0:
        switch (r2) {
          case "string":
            return ce(t2);
          case "bigint":
            return At(Ht(64, t2));
          default:
            return ae(t2);
        }
      default:
        return (function(t3, e3 = `unexpected value ${t3}!`) {
          throw Error(e3);
        })(e2, "Unknown format requested type for int64");
    }
  }
  function se(t2) {
    var e2 = t2.length;
    return ("-" === t2[0] ? e2 < 20 || 20 === e2 && t2 <= "-9223372036854775808" : e2 < 19 || 19 === e2 && t2 <= "9223372036854775807") ? t2 : (jt(t2), Bt(It, Ft));
  }
  function oe(t2) {
    if ("-" === t2[0]) var e2 = false;
    else e2 = (e2 = t2.length) < 20 || 20 === e2 && t2 <= "18446744073709551615";
    return e2 ? t2 : (jt(t2), $t(It, Ft));
  }
  function ae(t2) {
    if (t2 = zt(t2), !Xt(t2)) {
      Nt(t2);
      var e2 = It, r2 = Ft;
      (t2 = 2147483648 & r2) && (r2 = ~r2 >>> 0, 0 == (e2 = 1 + ~e2 >>> 0) && (r2 = r2 + 1 >>> 0)), t2 = "number" == typeof (e2 = Ot(e2, r2)) ? t2 ? -e2 : e2 : t2 ? "-" + e2 : e2;
    }
    return t2;
  }
  function he(t2) {
    return (t2 = zt(t2)) >= 0 && Xt(t2) || (Nt(t2), t2 = Ot(It, Ft)), t2;
  }
  function ue(t2) {
    return t2 = zt(t2), Xt(t2) ? t2 = String(t2) : (Nt(t2), t2 = Bt(It, Ft)), t2;
  }
  function ce(t2) {
    var e2 = zt(Number(t2));
    return Xt(e2) ? String(e2) : (-1 !== (e2 = t2.indexOf(".")) && (t2 = t2.substring(0, e2)), se(t2));
  }
  function le(t2) {
    var e2 = zt(Number(t2));
    return Xt(e2) ? At(e2) : (-1 !== (e2 = t2.indexOf(".")) && (t2 = t2.substring(0, e2)), U() ? At(Ht(64, BigInt(t2))) : At(se(t2)));
  }
  function de(t2) {
    return Xt(t2) ? At(ae(t2)) : At(ue(t2));
  }
  function fe(t2) {
    var e2 = typeof t2;
    return null == t2 ? t2 : "bigint" === e2 ? At(Ht(64, t2)) : te(t2) ? "string" === e2 ? le(t2) : de(t2) : void 0;
  }
  function pe(t2) {
    if (null == t2) return t2;
    var e2 = typeof t2;
    if ("bigint" === e2) return String(Ht(64, t2));
    if (te(t2)) {
      if ("string" === e2) return ce(t2);
      if ("number" === e2) return ae(t2);
    }
  }
  function me(t2) {
    if (null == t2 || "string" == typeof t2 || t2 instanceof N) return t2;
  }
  function ge(t2) {
    if ("string" != typeof t2) throw Error();
    return t2;
  }
  function ve(t2) {
    if (null != t2 && "string" != typeof t2) throw Error();
    return t2;
  }
  function _e(t2) {
    return null == t2 || "string" == typeof t2 ? t2 : void 0;
  }
  function ye(t2, e2, r2, n2) {
    return ht(t2) ? t2 : Array.isArray(t2) ? ((n2 = (r2 = 0 | t2[et]) | 32 & n2 | 2 & n2) !== r2 && it(t2, n2), new e2(t2)) : (r2 ? 2 & n2 ? ((t2 = e2[H]) || (st((t2 = new e2()).B), t2 = e2[H] = t2), e2 = t2) : e2 = new e2() : e2 = void 0, e2);
  }
  function Ee(t2, e2, r2) {
    return null == (t2 = e2 ? ie(t2, 1024) : fe(t2)) ? r2 ? Yt : void 0 : t2;
  }
  function Ae(t2) {
    return t2;
  }
  var we = {};
  var Te = (function() {
    try {
      return v(new class extends Map {
        constructor() {
          super();
        }
      }()), false;
    } catch {
      return true;
    }
  })();
  var be = class {
    constructor() {
      this.h = /* @__PURE__ */ new Map();
    }
    get(t2) {
      return this.h.get(t2);
    }
    set(t2, e2) {
      return this.h.set(t2, e2), this.size = this.h.size, this;
    }
    delete(t2) {
      return t2 = this.h.delete(t2), this.size = this.h.size, t2;
    }
    clear() {
      this.h.clear(), this.size = this.h.size;
    }
    has(t2) {
      return this.h.has(t2);
    }
    entries() {
      return this.h.entries();
    }
    keys() {
      return this.h.keys();
    }
    values() {
      return this.h.values();
    }
    forEach(t2, e2) {
      return this.h.forEach(t2, e2);
    }
    [Symbol.iterator]() {
      return this.entries();
    }
  };
  var ke = Te ? (Object.setPrototypeOf(be.prototype, Map.prototype), Object.defineProperties(be.prototype, { size: { value: 0, configurable: true, enumerable: true, writable: true } }), be) : class extends Map {
    constructor() {
      super();
    }
  };
  function Se(t2) {
    return t2;
  }
  function Le(t2) {
    if (2 & t2.N) throw Error("Cannot mutate an immutable Map");
  }
  var xe;
  var Re = class extends ke {
    constructor(t2, e2, r2 = Se, n2 = Se) {
      super(), this.N = 0 | t2[et], this.O = e2, this.ca = r2, this.oa = this.O ? Ie : n2;
      for (let i2 = 0; i2 < t2.length; i2++) {
        let s2 = t2[i2], o2 = r2(s2[0], false, true), a2 = s2[1];
        e2 ? void 0 === a2 && (a2 = null) : a2 = n2(s2[1], false, true, void 0, void 0, this.N), super.set(o2, a2);
      }
    }
    fa(t2) {
      return ot(Array.from(super.entries(), t2));
    }
    clear() {
      Le(this), super.clear();
    }
    delete(t2) {
      return Le(this), super.delete(this.ca(t2, true, false));
    }
    entries() {
      if (this.O) {
        var t2 = super.keys();
        t2 = new dt(t2, Fe, this);
      } else t2 = super.entries();
      return t2;
    }
    values() {
      if (this.O) {
        var t2 = super.keys();
        t2 = new dt(t2, Re.prototype.get, this);
      } else t2 = super.values();
      return t2;
    }
    forEach(t2, e2) {
      this.O ? super.forEach((r2, n2, i2) => {
        t2.call(e2, i2.get(n2), n2, i2);
      }) : super.forEach(t2, e2);
    }
    set(t2, e2) {
      return Le(this), null == (t2 = this.ca(t2, true, false)) ? this : null == e2 ? (super.delete(t2), this) : super.set(t2, this.oa(e2, true, true, this.O, false, this.N));
    }
    hb(t2) {
      var e2 = this.ca(t2[0], false, true);
      t2 = t2[1], t2 = this.O ? void 0 === t2 ? null : t2 : this.oa(t2, false, true, void 0, false, this.N), super.set(e2, t2);
    }
    has(t2) {
      return super.has(this.ca(t2, false, false));
    }
    get(t2) {
      t2 = this.ca(t2, false, false);
      var e2 = super.get(t2);
      if (void 0 !== e2) {
        var r2 = this.O;
        return r2 ? ((r2 = this.oa(e2, false, true, r2, this.Ga, this.N)) !== e2 && super.set(t2, r2), r2) : e2;
      }
    }
    [Symbol.iterator]() {
      return this.entries();
    }
  };
  function Ie(t2, e2, r2, n2, i2, s2) {
    return t2 = ye(t2, n2, r2, s2), i2 && (t2 = Ze(t2)), t2;
  }
  function Fe(t2) {
    return [t2, this.get(t2)];
  }
  function Ce() {
    return xe ||= new Re(st([]), void 0, void 0, void 0, we);
  }
  function Ne(t2) {
    return X ? t2[X] : void 0;
  }
  function Me(t2, e2) {
    for (let r2 in t2) !isNaN(r2) && e2(t2, +r2, t2[r2]);
  }
  Re.prototype.toJSON = void 0;
  var Oe;
  var De;
  var Pe;
  var $e = class {
  };
  var Ue = { eb: true };
  function Be(t2, e2) {
    e2 < 100 || $(z, 1);
  }
  function je(t2, e2, r2, n2) {
    var i2 = void 0 !== n2;
    n2 = !!n2;
    var s2, o2 = X;
    !i2 && B && o2 && (s2 = t2[o2]) && Me(s2, Be), o2 = [];
    var a2 = t2.length;
    s2 = 4294967295;
    var h2 = false, u2 = !!(64 & e2), c2 = u2 ? 128 & e2 ? 0 : -1 : void 0;
    if (!(1 & e2)) {
      var l2 = a2 && t2[a2 - 1];
      null != l2 && "object" == typeof l2 && l2.constructor === Object ? s2 = --a2 : l2 = void 0, !u2 || 128 & e2 || i2 || (h2 = true, s2 = (Oe ?? Ae)(s2 - c2, c2, t2, l2, void 0) + c2);
    }
    e2 = void 0;
    for (var d2 = 0; d2 < a2; d2++) {
      let i3 = t2[d2];
      if (null != i3 && null != (i3 = r2(i3, n2))) if (u2 && d2 >= s2) {
        let t3 = d2 - c2;
        (e2 ??= {})[t3] = i3;
      } else o2[d2] = i3;
    }
    if (l2) for (let t3 in l2) {
      if (null == (a2 = l2[t3]) || null == (a2 = r2(a2, n2))) continue;
      let i3;
      d2 = +t3, u2 && !Number.isNaN(d2) && (i3 = d2 + c2) < s2 ? o2[i3] = a2 : (e2 ??= {})[t3] = a2;
    }
    return e2 && (h2 ? o2.push(e2) : o2[s2] = e2), i2 && X && (t2 = Ne(t2)) && t2 instanceof $e && (o2[X] = (function(t3) {
      var e3 = new $e();
      return Me(t3, (t4, r3, n3) => {
        e3[r3] = Vt(n3);
      }), e3.la = t3.la, e3;
    })(t2)), o2;
  }
  function Ge(t2) {
    return t2[0] = Ve(t2[0]), t2[1] = Ve(t2[1]), t2;
  }
  function Ve(t2) {
    switch (typeof t2) {
      case "number":
        return Number.isFinite(t2) ? t2 : "" + t2;
      case "bigint":
        return wt(t2) ? Number(t2) : "" + t2;
      case "boolean":
        return t2 ? 1 : 0;
      case "object":
        if (Array.isArray(t2)) {
          var e2 = 0 | t2[et];
          return 0 === t2.length && 1 & e2 ? void 0 : je(t2, e2, Ve);
        }
        if (ht(t2)) return He(t2);
        if (t2 instanceof N) {
          if (null == (e2 = t2.h)) t2 = "";
          else if ("string" == typeof e2) t2 = e2;
          else {
            if (T) {
              for (var r2 = "", n2 = 0, i2 = e2.length - 10240; n2 < i2; ) r2 += String.fromCharCode.apply(null, e2.subarray(n2, n2 += 10240));
              r2 += String.fromCharCode.apply(null, n2 ? e2.subarray(n2) : e2), e2 = btoa(r2);
            } else {
              void 0 === r2 && (r2 = 0), A(), r2 = _[r2], n2 = Array(Math.floor(e2.length / 3)), i2 = r2[64] || "";
              let t3 = 0, u2 = 0;
              for (; t3 < e2.length - 2; t3 += 3) {
                var s2 = e2[t3], o2 = e2[t3 + 1], a2 = e2[t3 + 2], h2 = r2[s2 >> 2];
                s2 = r2[(3 & s2) << 4 | o2 >> 4], o2 = r2[(15 & o2) << 2 | a2 >> 6], a2 = r2[63 & a2], n2[u2++] = h2 + s2 + o2 + a2;
              }
              switch (h2 = 0, a2 = i2, e2.length - t3) {
                case 2:
                  a2 = r2[(15 & (h2 = e2[t3 + 1])) << 2] || i2;
                case 1:
                  e2 = e2[t3], n2[u2] = r2[e2 >> 2] + r2[(3 & e2) << 4 | h2 >> 4] + a2 + i2;
              }
              e2 = n2.join("");
            }
            t2 = t2.h = e2;
          }
          return t2;
        }
        return t2 instanceof Re ? t2 = 0 !== t2.size ? t2.fa(Ge) : void 0 : void 0;
    }
    return t2;
  }
  function He(t2) {
    return je(t2 = t2.B, 0 | t2[et], Ve);
  }
  function Ke(t2, e2) {
    return Xe(t2, e2[0], e2[1]);
  }
  function Xe(t2, e2, r2, n2 = 0) {
    if (null == t2) {
      var i2 = 32;
      r2 ? (t2 = [r2], i2 |= 128) : t2 = [], e2 && (i2 = -16760833 & i2 | (1023 & e2) << 14);
    } else {
      if (!Array.isArray(t2)) throw Error("narr");
      if (i2 = 0 | t2[et], f && 1 & i2) throw Error("rfarr");
      if (2048 & i2 && !(2 & i2) && (function() {
        if (f) throw Error("carr");
        $(q, 5);
      })(), 256 & i2) throw Error("farr");
      if (64 & i2) return (i2 | n2) !== i2 && it(t2, i2 | n2), t2;
      if (r2 && (i2 |= 128, r2 !== t2[0])) throw Error("mid");
      t: {
        i2 |= 64;
        var s2 = (r2 = t2).length;
        if (s2) {
          var o2 = s2 - 1;
          let t3 = r2[o2];
          if (null != t3 && "object" == typeof t3 && t3.constructor === Object) {
            if ((o2 -= e2 = 128 & i2 ? 0 : -1) >= 1024) throw Error("pvtlmt");
            for (var a2 in t3) (s2 = +a2) < o2 && (r2[s2 + e2] = t3[a2], delete t3[a2]);
            i2 = -16760833 & i2 | (1023 & o2) << 14;
            break t;
          }
        }
        if (e2) {
          if ((a2 = Math.max(e2, s2 - (128 & i2 ? 0 : -1))) > 1024) throw Error("spvt");
          i2 = -16760833 & i2 | (1023 & a2) << 14;
        }
      }
    }
    return it(t2, 64 | i2 | n2), t2;
  }
  function We(t2, e2) {
    if ("object" != typeof t2) return t2;
    if (Array.isArray(t2)) {
      var r2 = 0 | t2[et];
      return 0 === t2.length && 1 & r2 ? void 0 : ze(t2, r2, e2);
    }
    if (ht(t2)) return qe(t2);
    if (t2 instanceof Re) {
      if (2 & (e2 = t2.N)) return t2;
      if (!t2.size) return;
      if (r2 = st(t2.fa()), t2.O) for (t2 = 0; t2 < r2.length; t2++) {
        let n2 = r2[t2], i2 = n2[1];
        i2 = null == i2 || "object" != typeof i2 ? void 0 : ht(i2) ? qe(i2) : Array.isArray(i2) ? ze(i2, 0 | i2[et], !!(32 & e2)) : void 0, n2[1] = i2;
      }
      return r2;
    }
    return t2 instanceof N ? t2 : void 0;
  }
  function ze(t2, e2, r2) {
    return 2 & e2 || (!r2 || 4096 & e2 || 16 & e2 ? t2 = Je(t2, e2, false, r2 && !(16 & e2)) : (nt(t2, 34), 4 & e2 && Object.freeze(t2))), t2;
  }
  function Ye(t2, e2, r2) {
    return t2 = new t2.constructor(e2), r2 && (t2.i = ct), t2.o = ct, t2;
  }
  function qe(t2) {
    var e2 = t2.B, r2 = 0 | e2[et];
    return ut(t2, r2) ? t2 : rr(t2, e2, r2) ? Ye(t2, e2) : Je(e2, r2);
  }
  function Je(t2, e2, r2, n2) {
    return n2 ??= !!(34 & e2), t2 = je(t2, e2, We, n2), n2 = 32, r2 && (n2 |= 2), it(t2, e2 = 16769217 & e2 | n2), t2;
  }
  function Ze(t2) {
    var e2 = t2.B, r2 = 0 | e2[et];
    return ut(t2, r2) ? rr(t2, e2, r2) ? Ye(t2, e2, true) : new t2.constructor(Je(e2, r2, false)) : t2;
  }
  function Qe(t2) {
    if (t2.i !== ct) return false;
    var e2 = t2.B;
    return nt(e2 = Je(e2, 0 | e2[et]), 2048), t2.B = e2, t2.i = void 0, t2.o = void 0, true;
  }
  function tr(t2) {
    if (!Qe(t2) && ut(t2, 0 | t2.B[et])) throw Error();
  }
  function er(t2, e2) {
    void 0 === e2 && (e2 = 0 | t2[et]), 32 & e2 && !(4096 & e2) && it(t2, 4096 | e2);
  }
  function rr(t2, e2, r2) {
    return !!(2 & r2) || !(!(32 & r2) || 4096 & r2) && (it(e2, 2 | r2), t2.i = ct, true);
  }
  var nr = At(0);
  var ir = {};
  function sr(t2, e2, r2, n2) {
    if (null !== (e2 = or(t2.B, e2, void 0, n2)) || r2 && t2.o !== ct) return e2;
  }
  function or(t2, e2, r2, n2) {
    if (-1 === e2) return null;
    var i2 = e2 + (r2 ? 0 : -1), s2 = t2.length - 1;
    if (!(s2 < 1 + (r2 ? 0 : -1))) {
      if (i2 >= s2) {
        var o2 = t2[s2];
        if (null != o2 && "object" == typeof o2 && o2.constructor === Object) {
          r2 = o2[e2];
          var a2 = true;
        } else {
          if (i2 !== s2) return;
          r2 = o2;
        }
      } else r2 = t2[i2];
      if (n2 && null != r2) {
        if (null == (n2 = n2(r2))) return n2;
        if (!Object.is(n2, r2)) return a2 ? o2[e2] = n2 : t2[i2] = n2, n2;
      }
      return r2;
    }
  }
  function ar(t2, e2, r2, n2) {
    tr(t2);
    var i2 = t2.B;
    return hr(i2, 0 | i2[et], e2, r2, n2), t2;
  }
  function hr(t2, e2, r2, n2, i2) {
    var s2 = r2 + (i2 ? 0 : -1), o2 = t2.length - 1;
    if (o2 >= 1 + (i2 ? 0 : -1) && s2 >= o2) {
      let i3 = t2[o2];
      if (null != i3 && "object" == typeof i3 && i3.constructor === Object) return i3[r2] = n2, e2;
    }
    return s2 <= o2 ? (t2[s2] = n2, e2) : (void 0 !== n2 && (r2 >= (o2 = (e2 ??= 0 | t2[et]) >> 14 & 1023 || 536870912) ? null != n2 && (t2[o2 + (i2 ? 0 : -1)] = { [r2]: n2 }) : t2[s2] = n2), e2);
  }
  function ur(t2, e2) {
    return ht(t2 = or(t2.B, e2)) || Array.isArray(t2);
  }
  function cr(t2, e2, r2) {
    return ur(t2, e2 = Er(t2, r2) === e2 ? e2 : -1);
  }
  function lr(t2, e2, r2, n2, i2) {
    var s2 = t2.B, o2 = 0 | s2[et];
    n2 = ut(t2, o2) ? 1 : n2 || 4, i2 = !!i2 || 3 === n2, 2 === n2 && Qe(t2) && (o2 = 0 | (s2 = t2.B)[et]);
    var a2 = (t2 = fr(s2, e2)) === G ? 7 : 0 | t2[et], h2 = pr(a2, o2), u2 = !(4 & h2);
    if (u2) {
      4 & h2 && (t2 = Vt(t2), a2 = 0, h2 = Cr(h2, o2), o2 = hr(s2, o2, e2, t2));
      let n3 = 0, i3 = 0;
      for (; n3 < t2.length; n3++) {
        let e3 = r2(t2[n3]);
        null != e3 && (t2[i3++] = e3);
      }
      i3 < n3 && (t2.length = i3), r2 = -513 & h2 | 4, h2 = r2 &= -1025, h2 &= -4097;
    }
    return h2 !== a2 && (it(t2, h2), 2 & h2 && Object.freeze(t2)), dr(t2, h2, s2, o2, e2, n2, u2, i2);
  }
  function dr(t2, e2, r2, n2, i2, s2, o2, a2) {
    var h2 = e2;
    return 1 === s2 || 4 === s2 && (2 & e2 || !(16 & e2) && 32 & n2) ? mr(e2) || ((e2 |= !t2.length || o2 && !(4096 & e2) || 32 & n2 && !(4096 & e2 || 16 & e2) ? 2 : 256) !== h2 && it(t2, e2), Object.freeze(t2)) : (2 === s2 && mr(e2) && (t2 = Vt(t2), h2 = 0, e2 = Cr(e2, n2), n2 = hr(r2, n2, i2, t2)), mr(e2) || (a2 || (e2 |= 16), e2 !== h2 && it(t2, e2))), 2 & e2 || !(4096 & e2 || 16 & e2) || er(r2, n2), t2;
  }
  function fr(t2, e2, r2) {
    return t2 = or(t2, e2, r2), Array.isArray(t2) ? t2 : G;
  }
  function pr(t2, e2) {
    return 2 & e2 && (t2 |= 2), 1 | t2;
  }
  function mr(t2) {
    return !!(2 & t2) && !!(4 & t2) || !!(256 & t2);
  }
  function gr(t2) {
    return lt(t2, true);
  }
  function vr(t2) {
    t2 = Vt(t2);
    for (let e2 = 0; e2 < t2.length; e2++) {
      let r2 = t2[e2] = Vt(t2[e2]);
      Array.isArray(r2[1]) && (r2[1] = st(r2[1]));
    }
    return ot(t2);
  }
  function _r(t2, e2, r2, n2) {
    tr(t2), hr(t2 = t2.B, 0 | t2[et], e2, ("0" === n2 ? 0 === Number(r2) : r2 === n2) ? void 0 : r2);
  }
  function yr(t2, e2, r2) {
    if (2 & e2) throw Error();
    var n2 = mt(e2), i2 = fr(t2, r2, n2), s2 = i2 === G ? 7 : 0 | i2[et], o2 = pr(s2, e2);
    return (2 & o2 || mr(o2) || 16 & o2) && (o2 === s2 || mr(o2) || it(i2, o2), i2 = Vt(i2), s2 = 0, o2 = Cr(o2, e2), hr(t2, e2, r2, i2, n2)), (o2 &= -13) !== s2 && it(i2, o2), i2;
  }
  function Er(t2, e2) {
    return Tr(Ar(t2 = t2.B), t2, void 0, e2);
  }
  function Ar(t2) {
    if (B) return t2[K] ?? (t2[K] = /* @__PURE__ */ new Map());
    if (K in t2) return t2[K];
    var e2 = /* @__PURE__ */ new Map();
    return Object.defineProperty(t2, K, { value: e2 }), e2;
  }
  function wr(t2, e2, r2, n2, i2) {
    var s2 = Ar(t2), o2 = Tr(s2, t2, e2, r2, i2);
    return o2 !== n2 && (o2 && (e2 = hr(t2, e2, o2, void 0, i2)), s2.set(r2, n2)), e2;
  }
  function Tr(t2, e2, r2, n2, i2) {
    var s2 = t2.get(n2);
    if (null != s2) return s2;
    s2 = 0;
    for (let t3 = 0; t3 < n2.length; t3++) {
      let o2 = n2[t3];
      null != or(e2, o2, i2) && (0 !== s2 && (r2 = hr(e2, r2, s2, void 0, i2)), s2 = o2);
    }
    return t2.set(n2, s2), s2;
  }
  function br(t2, e2, r2) {
    var n2 = 0 | t2[et], i2 = mt(n2), s2 = or(t2, r2, i2);
    if (ht(s2)) {
      if (!ut(s2)) return Qe(s2), s2.B;
      var o2 = s2.B;
    } else Array.isArray(s2) && (o2 = s2);
    if (o2) {
      let t3 = 0 | o2[et];
      2 & t3 && (o2 = Je(o2, t3));
    }
    return (o2 = Ke(o2, e2)) !== s2 && hr(t2, n2, r2, o2, i2), o2;
  }
  function kr(t2, e2, r2, n2) {
    var i2 = t2.B, s2 = 0 | i2[et];
    if (e2 = (function(t3, e3, r3, n3, i3) {
      var s3 = false;
      if (null != (n3 = or(t3, n3, i3, (t4) => {
        var n4 = ye(t4, r3, false, e3);
        return s3 = n4 !== t4 && null != n4, n4;
      }))) return s3 && !ut(n3) && er(t3, e3), n3;
    })(i2, s2, e2, r2, n2), null == e2) return e2;
    if (!ut(t2, s2 = 0 | i2[et])) {
      let o2 = Ze(e2);
      o2 !== e2 && (Qe(t2) && (s2 = 0 | (i2 = t2.B)[et]), er(i2, s2 = hr(i2, s2, r2, e2 = o2, n2)));
    }
    return e2;
  }
  function Sr(t2, e2, r2, n2, i2, s2, o2, a2) {
    var h2 = ut(t2, r2);
    s2 = h2 ? 1 : s2 || 4, o2 = !!o2 || 3 === s2, h2 = a2 && !h2, (2 === s2 || h2) && Qe(t2) && (r2 = 0 | (e2 = t2.B)[et]);
    var u2 = (t2 = fr(e2, i2)) === G ? 7 : 0 | t2[et], c2 = pr(u2, r2);
    if (a2 = !(4 & c2)) {
      var l2 = t2, d2 = r2;
      let e3 = !!(2 & c2);
      e3 && (d2 |= 2);
      let i3 = !e3, s3 = true, o3 = 0, a3 = 0;
      for (; o3 < l2.length; o3++) {
        let t3 = ye(l2[o3], n2, false, d2);
        if (t3 instanceof n2) {
          if (!e3) {
            let e4 = ut(t3);
            i3 &&= !e4, s3 &&= e4;
          }
          l2[a3++] = t3;
        }
      }
      a3 < o3 && (l2.length = a3), c2 |= 4, c2 = s3 ? -4097 & c2 : 4096 | c2, c2 = i3 ? 8 | c2 : -9 & c2;
    }
    if (c2 !== u2 && (it(t2, c2), 2 & c2 && Object.freeze(t2)), h2 && !(8 & c2 || !t2.length && (1 === s2 || 4 === s2 && (2 & c2 || !(16 & c2) && 32 & r2)))) {
      for (mr(c2) && (t2 = Vt(t2), c2 = Cr(c2, r2), r2 = hr(e2, r2, i2, t2)), n2 = t2, h2 = c2, u2 = 0; u2 < n2.length; u2++) (l2 = n2[u2]) !== (c2 = Ze(l2)) && (n2[u2] = c2);
      h2 |= 8, it(t2, c2 = h2 = n2.length ? 4096 | h2 : -4097 & h2);
    }
    return dr(t2, c2, e2, r2, i2, s2, a2, o2);
  }
  function Lr(t2, e2, r2) {
    var n2 = t2.B;
    return Sr(t2, n2, 0 | n2[et], e2, r2, void 0, false, true);
  }
  function xr(t2) {
    return null == t2 && (t2 = void 0), t2;
  }
  function Rr(t2, e2, r2, n2, i2) {
    return ar(t2, r2, n2 = xr(n2), i2), n2 && !ut(n2) && er(t2.B), t2;
  }
  function Ir(t2, e2, r2, n2) {
    t: {
      var i2 = n2 = xr(n2);
      tr(t2);
      let s2 = t2.B, o2 = 0 | s2[et];
      if (null == i2) {
        let t3 = Ar(s2);
        if (Tr(t3, s2, o2, r2) !== e2) break t;
        t3.set(r2, 0);
      } else o2 = wr(s2, o2, r2, e2);
      hr(s2, o2, e2, i2);
    }
    return n2 && !ut(n2) && er(t2.B), t2;
  }
  function Fr(t2, e2, r2) {
    tr(t2);
    var n2 = t2.B, i2 = 0 | n2[et];
    if (null == r2) return hr(n2, i2, e2), t2;
    var s2 = r2 === G ? 7 : 0 | r2[et], o2 = s2, a2 = mr(s2), h2 = a2 || Object.isFrozen(r2), u2 = true, c2 = true;
    for (let t3 = 0; t3 < r2.length; t3++) {
      var l2 = r2[t3];
      a2 || (l2 = ut(l2), u2 &&= !l2, c2 &&= l2);
    }
    return a2 || (s2 = u2 ? 13 : 5, s2 = c2 ? -4097 & s2 : 4096 | s2), h2 && s2 === o2 || (r2 = Vt(r2), o2 = 0, s2 = Cr(s2, i2)), s2 !== o2 && it(r2, s2), i2 = hr(n2, i2, e2, r2), 2 & s2 || !(4096 & s2 || 16 & s2) || er(n2, i2), t2;
  }
  function Cr(t2, e2) {
    return -273 & (2 & e2 ? 2 | t2 : -3 & t2);
  }
  function Nr(t2, e2, r2, n2) {
    var i2 = n2;
    tr(t2), t2 = Sr(t2, n2 = t2.B, 0 | n2[et], r2, e2, 2, true), i2 = null != i2 ? i2 : new r2(), t2.push(i2), e2 = r2 = t2 === G ? 7 : 0 | t2[et], (i2 = ut(i2)) ? (r2 &= -9, 1 === t2.length && (r2 &= -4097)) : r2 |= 4096, r2 !== e2 && it(t2, r2), i2 || er(n2);
  }
  function Mr(t2, e2, r2) {
    return re(sr(t2, e2, r2));
  }
  function Or(t2, e2) {
    return sr(t2, e2, void 0, Jt) ?? 0;
  }
  function Dr(t2, e2, r2, n2) {
    return kr(t2, e2, r2 = Er(t2, n2) === r2 ? r2 : -1, void 0);
  }
  function Pr(t2, e2) {
    _r(t2, 3, null == e2 ? e2 : Zt(e2), false);
  }
  function $r(t2, e2, r2) {
    if (null != r2) {
      if ("number" != typeof r2) throw P("int32");
      if (!Wt(r2)) throw P("int32");
      r2 |= 0;
    }
    ar(t2, e2, r2);
  }
  function Ur(t2, e2, r2) {
    return ar(t2, e2, null == r2 ? r2 : ie(r2));
  }
  function Br(t2, e2, r2) {
    return ar(t2, e2, null == r2 ? r2 : (function(t3) {
      if (!te(t3)) throw P("uint64");
      switch (typeof t3) {
        case "string":
          var e3 = zt(Number(t3));
          return Xt(e3) && e3 >= 0 ? t3 = At(e3) : (-1 !== (e3 = t3.indexOf(".")) && (t3 = t3.substring(0, e3)), t3 = U() ? At(Kt(64, BigInt(t3))) : At(oe(t3))), t3;
        case "bigint":
          return At(Kt(64, t3));
        default:
          return Xt(t3) ? t3 = At(he(t3)) : ((t3 = zt(t3)) >= 0 && Xt(t3) ? t3 = String(t3) : (Nt(t3), t3 = $t(It, Ft)), t3 = At(t3)), t3;
      }
    })(r2));
  }
  function jr(t2, e2, r2) {
    ar(t2, e2, null == r2 ? r2 : qt(r2));
  }
  function Gr(t2, e2, r2) {
    _r(t2, e2, null == r2 ? r2 : qt(r2), 0);
  }
  function Vr(t2, e2, r2) {
    _r(t2, e2, ve(r2), "");
  }
  function Hr(t2, e2, r2) {
    {
      tr(t2);
      let o2 = t2.B, a2 = 0 | o2[et];
      if (null == r2) hr(o2, a2, e2);
      else {
        var n2 = t2 = r2 === G ? 7 : 0 | r2[et], i2 = mr(t2), s2 = i2 || Object.isFrozen(r2);
        for (i2 || (t2 = 0), s2 || (r2 = Vt(r2), n2 = 0, t2 = Cr(t2, a2), s2 = false), t2 |= 5, t2 |= (4 & t2 ? 512 & t2 ? 512 : 1024 & t2 ? 1024 : 0 : void 0) ?? 1024, i2 = 0; i2 < r2.length; i2++) {
          let e3 = r2[i2], o3 = ge(e3);
          Object.is(e3, o3) || (s2 && (r2 = Vt(r2), n2 = 0, t2 = Cr(t2, a2), s2 = false), r2[i2] = o3);
        }
        t2 !== n2 && (s2 && (r2 = Vt(r2), t2 = Cr(t2, a2)), it(r2, t2)), hr(o2, a2, e2, r2);
      }
    }
  }
  function Kr(t2, e2, r2) {
    tr(t2), lr(t2, e2, _e, 2, true).push(ge(r2));
  }
  var Xr = class {
    constructor(t2, e2, r2) {
      if (this.buffer = t2, r2 && !e2) throw Error();
      this.h = e2;
    }
  };
  function Wr(t2, e2) {
    if ("string" == typeof t2) return new Xr(L(t2), e2);
    if (Array.isArray(t2)) return new Xr(new Uint8Array(t2), e2);
    if (t2.constructor === Uint8Array) return new Xr(t2, false);
    if (t2.constructor === ArrayBuffer) return t2 = new Uint8Array(t2), new Xr(t2, false);
    if (t2.constructor === N) return e2 = F(t2) || new Uint8Array(0), new Xr(e2, true, t2);
    if (t2 instanceof Uint8Array) return t2 = t2.constructor === Uint8Array ? t2 : new Uint8Array(t2.buffer, t2.byteOffset, t2.byteLength), new Xr(t2, false);
    throw Error();
  }
  function zr(t2, e2) {
    var r2 = 0, n2 = 0, i2 = 0, s2 = t2.i, o2 = t2.h;
    do {
      var a2 = s2[o2++];
      r2 |= (127 & a2) << i2, i2 += 7;
    } while (i2 < 32 && 128 & a2);
    if (i2 > 32) for (n2 |= (127 & a2) >> 4, i2 = 3; i2 < 32 && 128 & a2; i2 += 7) n2 |= (127 & (a2 = s2[o2++])) << i2;
    if (rn(t2, o2), !(128 & a2)) return e2(r2 >>> 0, n2 >>> 0);
    throw Error();
  }
  function Yr(t2) {
    for (var e2 = 0, r2 = t2.h, n2 = r2 + 10, i2 = t2.i; r2 < n2; ) {
      let n3 = i2[r2++];
      if (e2 |= n3, !(128 & n3)) return rn(t2, r2), !!(127 & e2);
    }
    throw Error();
  }
  function qr(t2) {
    var e2 = t2.i, r2 = t2.h, n2 = e2[r2++], i2 = 127 & n2;
    if (128 & n2 && (i2 |= (127 & (n2 = e2[r2++])) << 7, 128 & n2 && (i2 |= (127 & (n2 = e2[r2++])) << 14, 128 & n2 && (i2 |= (127 & (n2 = e2[r2++])) << 21, 128 & n2 && (i2 |= (n2 = e2[r2++]) << 28, 128 & n2 && 128 & e2[r2++] && 128 & e2[r2++] && 128 & e2[r2++] && 128 & e2[r2++] && 128 & e2[r2++]))))) throw Error();
    return rn(t2, r2), i2;
  }
  function Jr(t2) {
    return qr(t2) >>> 0;
  }
  function Zr(t2) {
    return zr(t2, Pt);
  }
  function Qr(t2) {
    var e2 = t2.i, r2 = t2.h, n2 = e2[r2], i2 = e2[r2 + 1], s2 = e2[r2 + 2];
    return e2 = e2[r2 + 3], rn(t2, t2.h + 4), (n2 | i2 << 8 | s2 << 16 | e2 << 24) >>> 0;
  }
  function tn(t2) {
    var e2 = Qr(t2);
    t2 = 2 * (e2 >> 31) + 1;
    var r2 = e2 >>> 23 & 255;
    return e2 &= 8388607, 255 == r2 ? e2 ? NaN : t2 * (1 / 0) : 0 == r2 ? 1401298464324817e-60 * t2 * e2 : t2 * Math.pow(2, r2 - 150) * (e2 + 8388608);
  }
  function en(t2) {
    return qr(t2);
  }
  function rn(t2, e2) {
    if (t2.h = e2, e2 > t2.l) throw Error();
  }
  function nn(t2, e2) {
    if (e2 < 0) throw Error();
    var r2 = t2.h;
    if ((e2 = r2 + e2) > t2.l) throw Error();
    return t2.h = e2, r2;
  }
  function sn(t2, e2) {
    if (0 == e2) return I();
    var r2 = nn(t2, e2);
    return t2.ga && t2.u ? r2 = t2.i.subarray(r2, r2 + e2) : (t2 = t2.i, r2 = r2 === (e2 = r2 + e2) ? new Uint8Array(0) : Rt ? t2.slice(r2, e2) : new Uint8Array(t2.subarray(r2, e2))), 0 == r2.length ? I() : new N(r2, R);
  }
  var on = class {
    constructor(t2, e2, r2, n2) {
      this.i = null, this.u = false, this.h = this.l = this.o = 0, this.init(t2, e2, r2, n2);
    }
    init(t2, e2, r2, { ga: n2 = false, na: i2 = false } = {}) {
      this.ga = n2, this.na = i2, t2 && (t2 = Wr(t2, this.na), this.i = t2.buffer, this.u = t2.h, this.o = e2 || 0, this.l = void 0 !== r2 ? this.o + r2 : this.i.length, this.h = this.o);
    }
    clear() {
      this.i = null, this.u = false, this.h = this.l = this.o = 0, this.ga = false;
    }
  };
  var an = [];
  var hn = 0;
  function un(t2, e2, r2, n2) {
    if (yn.length) {
      let i2 = yn.pop();
      return i2.A(n2), i2.h.init(t2, e2, r2, n2), i2;
    }
    return new _n(t2, e2, r2, n2);
  }
  function cn(t2) {
    t2.h.clear(), t2.l = -1, t2.i = -1, yn.length < 100 && yn.push(t2);
  }
  function ln(t2) {
    var e2 = t2.h;
    if (e2.h == e2.l) return false;
    t2.o = t2.h.h;
    var r2 = Jr(t2.h);
    if (e2 = r2 >>> 3, !((r2 &= 7) >= 0 && r2 <= 5)) throw Error();
    if (e2 < 1) throw Error();
    return t2.l = e2, t2.i = r2, true;
  }
  function dn(t2) {
    try {
      switch (t2.i) {
        case 0:
          0 != t2.i ? dn(t2) : Yr(t2.h);
          break;
        case 1:
          var e2 = t2.h;
          rn(e2, e2.h + 8);
          break;
        case 2:
          if (2 != t2.i) dn(t2);
          else {
            var r2 = Jr(t2.h), n2 = t2.h;
            rn(n2, n2.h + r2);
          }
          break;
        case 5:
          var i2 = t2.h;
          rn(i2, i2.h + 4);
          break;
        case 3:
          fn();
          let s2 = t2.l;
          try {
            for (; ; ) {
              if (!ln(t2)) throw Error();
              if (4 == t2.i) {
                if (t2.l != s2) throw Error();
                break;
              }
              dn(t2);
            }
          } catch (t3) {
            if (t3 instanceof RangeError) throw new SyntaxError();
            throw t3;
          } finally {
            hn > 0 && hn--;
          }
          break;
        default:
          throw Error();
      }
    } catch (t3) {
      if (t3 instanceof RangeError) throw new SyntaxError();
      throw t3;
    }
  }
  function fn() {
    if (hn >= 100) throw new SyntaxError();
    hn++;
  }
  function pn(t2, e2, r2) {
    var n2 = t2.h.l, i2 = Jr(t2.h), s2 = (i2 = t2.h.h + i2) - n2;
    if (s2 <= 0 && (t2.h.l = i2, r2(e2, t2, void 0, void 0, void 0), s2 = i2 - t2.h.h), s2) throw Error();
    return t2.h.h = i2, t2.h.l = n2, e2;
  }
  function mn(t2) {
    var e2 = Jr(t2.h), r2 = nn(t2 = t2.h, e2);
    if (t2 = t2.i, h) {
      var o2, u2 = t2;
      (o2 = s) || (o2 = s = new TextDecoder("utf-8", { fatal: true })), e2 = r2 + e2, u2 = 0 === r2 && e2 === u2.length ? u2 : u2.subarray(r2, e2);
      try {
        var c2 = o2.decode(u2);
      } catch (t3) {
        if (void 0 === a) {
          try {
            o2.decode(new Uint8Array([128]));
          } catch (t4) {
          }
          try {
            o2.decode(new Uint8Array([97])), a = true;
          } catch (t4) {
            a = false;
          }
        }
        throw !a && (s = void 0), t3;
      }
    } else {
      e2 = (c2 = r2) + e2, r2 = [];
      let s2, a2 = null;
      for (; c2 < e2; ) {
        var l2 = t2[c2++];
        l2 < 128 ? r2.push(l2) : l2 < 224 ? c2 >= e2 ? n() : (s2 = t2[c2++], l2 < 194 || 128 != (192 & s2) ? (c2--, n()) : r2.push((31 & l2) << 6 | 63 & s2)) : l2 < 240 ? c2 >= e2 - 1 ? n() : (s2 = t2[c2++], 128 != (192 & s2) || 224 === l2 && s2 < 160 || 237 === l2 && s2 >= 160 || 128 != (192 & (o2 = t2[c2++])) ? (c2--, n()) : r2.push((15 & l2) << 12 | (63 & s2) << 6 | 63 & o2)) : l2 <= 244 ? c2 >= e2 - 2 ? n() : (s2 = t2[c2++], 128 != (192 & s2) || s2 - 144 + (l2 << 28) >> 30 || 128 != (192 & (o2 = t2[c2++])) || 128 != (192 & (u2 = t2[c2++])) ? (c2--, n()) : (l2 = (7 & l2) << 18 | (63 & s2) << 12 | (63 & o2) << 6 | 63 & u2, l2 -= 65536, r2.push(55296 + (l2 >> 10 & 1023), 56320 + (1023 & l2)))) : n(), r2.length >= 8192 && (a2 = i(a2, r2), r2.length = 0);
      }
      c2 = i(a2, r2);
    }
    return c2;
  }
  function gn(t2) {
    var e2 = Jr(t2.h);
    return sn(t2.h, e2);
  }
  function vn(t2, e2, r2) {
    var n2 = Jr(t2.h);
    for (n2 = t2.h.h + n2; t2.h.h < n2; ) r2.push(e2(t2.h));
  }
  var _n = class {
    constructor(t2, e2, r2, n2) {
      if (an.length) {
        let i2 = an.pop();
        i2.init(t2, e2, r2, n2), t2 = i2;
      } else t2 = new on(t2, e2, r2, n2);
      this.h = t2, this.o = this.h.h, this.i = this.l = -1, this.A(n2);
    }
    A({ sa: t2 = false } = {}) {
      this.sa = t2;
    }
  };
  var yn = [];
  function En(t2) {
    return new Tn(4294967295 & t2, Math.floor(t2 / 4294967296));
  }
  function An(t2) {
    return t2 ? /^\d+$/.test(t2) ? (jt(t2), new Tn(It, Ft)) : null : wn ||= new Tn(0, 0);
  }
  var wn;
  var Tn = class {
    constructor(t2, e2) {
      this.i = t2 >>> 0, this.h = e2 >>> 0;
    }
  };
  function bn(t2) {
    return new Mn(4294967295 & t2, Math.floor(t2 / 4294967296));
  }
  function kn(t2) {
    return t2 ? /^-?\d+$/.test(t2) ? (jt(t2), new Mn(It, Ft)) : null : Sn ||= new Mn(0, 0);
  }
  var Sn;
  var Ln;
  var xn;
  var Rn;
  var In;
  var Fn;
  var Cn;
  var Nn;
  var Mn = class {
    constructor(t2, e2) {
      this.i = t2 >>> 0, this.h = e2 >>> 0;
    }
  };
  function On(t2, e2, r2) {
    return "undefined" != typeof BigInt64Array ? (Cn || (Cn = new BigInt64Array(1), Nn = new Uint32Array(Cn.buffer), Cn[0] = BigInt(1), Fn = 1 === Nn[0]), Cn[0] = t2, new e2(Nn[t2 = Fn ? 0 : 1], Nn[1 - t2])) : (In || (Ln = BigInt(Number.MIN_SAFE_INTEGER), xn = BigInt(Number.MAX_SAFE_INTEGER), Rn = BigInt(4294967295), In = BigInt(32)), t2 >= Ln && t2 <= xn ? r2(Number(t2)) : (t2 = BigInt.asUintN(64, t2), new e2(Number(t2 & Rn), Number(t2 >> In))));
  }
  function Dn(t2, e2, r2) {
    for (; r2 > 0 || e2 > 127; ) t2.h.push(127 & e2 | 128), e2 = (e2 >>> 7 | r2 << 25) >>> 0, r2 >>>= 7;
    t2.h.push(e2);
  }
  function Pn(t2, e2) {
    for (; e2 > 127; ) t2.h.push(127 & e2 | 128), e2 >>>= 7;
    t2.h.push(e2);
  }
  function $n(t2, e2) {
    if (e2 >= 0) Pn(t2, e2);
    else {
      for (let r2 = 0; r2 < 9; r2++) t2.h.push(127 & e2 | 128), e2 >>= 7;
      t2.h.push(1);
    }
  }
  function Un(t2, e2) {
    jt(e2), (function(t3) {
      var e3 = Ft >> 31;
      t3(It << 1 ^ e3, (Ft << 1 | It >>> 31) ^ e3);
    })((e3, r2) => {
      Dn(t2, e3 >>> 0, r2 >>> 0);
    });
  }
  function Bn(t2, e2) {
    t2.h.push(e2 >>> 0 & 255), t2.h.push(e2 >>> 8 & 255), t2.h.push(e2 >>> 16 & 255), t2.h.push(e2 >>> 24 & 255);
  }
  var jn = class {
    constructor() {
      this.h = [];
    }
    length() {
      return this.h.length;
    }
    end() {
      var t2 = this.h;
      return this.h = [], t2;
    }
  };
  function Gn(t2, e2) {
    0 !== e2.length && (t2.l.push(e2), t2.i += e2.length);
  }
  function Vn(t2, e2, r2) {
    Pn(t2.h, 8 * e2 + r2);
  }
  function Hn(t2, e2) {
    return Vn(t2, e2, 2), e2 = t2.h.end(), Gn(t2, e2), e2.push(t2.i), e2;
  }
  function Kn(t2, e2) {
    var r2 = e2.pop();
    for (r2 = t2.i + t2.h.length() - r2; r2 > 127; ) e2.push(127 & r2 | 128), r2 >>>= 7, t2.i++;
    e2.push(r2), t2.i++;
  }
  function Xn(t2, e2, r2) {
    if (null != r2) switch (Vn(t2, e2, 0), typeof r2) {
      case "number":
        t2 = t2.h, Nt(r2), Dn(t2, It, Ft);
        break;
      case "bigint":
        r2 = On(r2, Mn, bn), Dn(t2.h, r2.i, r2.h);
        break;
      default:
        r2 = kn(r2), Dn(t2.h, r2.i, r2.h);
    }
  }
  function Wn(t2, e2, r2) {
    Vn(t2, e2, 2), Pn(t2.h, r2.length), Gn(t2, t2.h.end()), Gn(t2, r2);
  }
  function zn(t2, e2, r2, n2) {
    null != r2 && (e2 = Hn(t2, e2), n2(r2, t2), Kn(t2, e2));
  }
  var Yn = class {
    constructor() {
      this.l = [], this.i = 0, this.h = new jn();
    }
  };
  function qn(t2) {
    if ("string" == typeof t2) kn(t2);
  }
  function Jn() {
    var t2 = class {
      constructor() {
        throw Error();
      }
    };
    return Object.setPrototypeOf(t2, t2.prototype), t2;
  }
  var Zn = Jn();
  var Qn = Jn();
  var ti = Jn();
  var ei = Jn();
  var ri = Jn();
  var ni = Jn();
  var ii = Jn();
  var si = Jn();
  var oi = Jn();
  var ai = Jn();
  var hi = Jn();
  var ui = Jn();
  function ci(t2, e2, r2) {
    var n2 = t2.B;
    X && X in n2 && (n2 = n2[X]) && delete n2[e2.h], e2.i ? e2.u(t2, e2.i, e2.h, r2, e2.l) : e2.u(t2, e2.h, r2, e2.l);
  }
  var li = class {
    constructor(t2, e2) {
      this.B = Xe(t2, e2, void 0, 2048);
    }
    toJSON() {
      return He(this);
    }
    u() {
      var t2 = Ma, e2 = this.B, r2 = t2.h, n2 = X;
      if (B && n2 && null != e2[n2]?.[r2] && $(W, 3), e2 = t2.h, Z && X && void 0 === Z && (n2 = (r2 = this.B)[X]) && (n2 = n2.la)) try {
        n2(r2, e2, Ue);
      } catch (t3) {
        l(t3);
      }
      return t2.i ? t2.o(this, t2.i, t2.h, t2.l) : t2.o(this, t2.h, t2.defaultValue, t2.l);
    }
    clone() {
      var t2 = this.B, e2 = 0 | t2[et];
      return rr(this, t2, e2) ? Ye(this, t2, true) : new this.constructor(Je(t2, e2, false));
    }
  };
  li.prototype[J] = at, li.prototype.toString = function() {
    return this.B.toString();
  };
  var di = class {
    constructor(t2, e2, r2) {
      this.h = t2, this.i = e2, t2 = Zn, this.l = !!t2 && r2 === t2 || false;
    }
  };
  function fi(t2, e2) {
    return new di(t2, e2, Zn);
  }
  function pi(t2, e2, r2, n2, i2) {
    zn(t2, r2, Si(e2, n2), i2);
  }
  var mi;
  var gi;
  var vi = fi(function(t2, e2, r2, n2, i2) {
    return 2 === t2.i && (pn(t2, br(e2, n2, r2), i2), true);
  }, pi);
  var _i = fi(function(t2, e2, r2, n2, i2) {
    return 2 === t2.i && (pn(t2, br(e2, n2, r2), i2), true);
  }, pi);
  var yi = Symbol();
  var Ei = Symbol();
  var Ai = Symbol();
  var wi = Symbol();
  var Ti = Symbol();
  function bi(t2, e2, r2, n2) {
    var i2 = n2[t2];
    if (i2) return i2;
    (i2 = {}).Fa = n2, i2.da = (function(t3) {
      switch (typeof t3) {
        case "boolean":
          return De ||= [0, void 0, true];
        case "number":
          return t3 > 0 ? void 0 : 0 === t3 ? Pe ||= [0, void 0] : [-t3, void 0];
        case "string":
          return [0, t3];
        case "object":
          return t3;
      }
    })(n2[0]);
    var s2 = n2[1], o2 = 1;
    s2 && s2.constructor === Object && (i2.ja = s2, "function" == typeof (s2 = n2[++o2]) && (i2.xa = true, mi ??= s2, gi ??= n2[o2 + 1], s2 = n2[o2 += 2]));
    for (var a2 = {}; s2 && Array.isArray(s2) && s2.length && "number" == typeof s2[0] && s2[0] > 0; ) {
      for (var h2 = 0; h2 < s2.length; h2++) a2[s2[h2]] = s2;
      s2 = n2[++o2];
    }
    for (h2 = 1; void 0 !== s2; ) {
      let t3;
      "number" == typeof s2 && (h2 += s2, s2 = n2[++o2]);
      var u2 = void 0;
      if (s2 instanceof di ? t3 = s2 : (t3 = vi, o2--), t3?.l) {
        s2 = n2[++o2], u2 = n2;
        var c2 = o2;
        "function" == typeof s2 && (s2 = s2(), u2[c2] = s2), u2 = s2;
      }
      for (c2 = h2 + 1, "number" == typeof (s2 = n2[++o2]) && s2 < 0 && (c2 -= s2, s2 = n2[++o2]); h2 < c2; h2++) {
        let n3 = a2[h2];
        u2 ? r2(i2, h2, t3, u2, n3) : e2(i2, h2, t3, n3);
      }
    }
    return n2[t2] = i2;
  }
  function ki(t2) {
    return Array.isArray(t2) ? t2[0] instanceof di ? t2 : [_i, t2] : [t2, void 0];
  }
  function Si(t2, e2) {
    return t2 instanceof li ? t2.B : Array.isArray(t2) ? Ke(t2, e2) : void 0;
  }
  function Li(t2, e2, r2, n2) {
    var i2 = r2.h;
    t2[e2] = n2 ? (t3, e3, r3) => i2(t3, e3, r3, n2) : i2;
  }
  function xi(t2, e2, r2, n2, i2) {
    var s2, o2, a2 = r2.h;
    t2[e2] = (t3, e3, r3) => a2(t3, e3, r3, o2 ||= bi(Ei, Li, xi, n2).da, s2 ||= Ri(n2), i2);
  }
  function Ri(t2) {
    var e2 = t2[Ai];
    if (null != e2) return e2;
    var r2 = bi(Ei, Li, xi, t2);
    return e2 = r2.xa ? (t3, e3) => mi(t3, e3, r2) : (t3, e3) => {
      t: {
        fn();
        try {
          for (; ln(e3) && 4 != e3.i; ) {
            let h3 = e3.l, u3 = r2[h3];
            if (null == u3) {
              let t4 = r2.ja;
              if (t4) {
                let e4 = t4[h3];
                if (e4) {
                  let t5 = Fi(e4);
                  null != t5 && (u3 = r2[h3] = t5);
                }
              }
            }
            if (null == u3 || !u3(e3, t3, h3)) {
              var n2 = e3;
              let r3 = n2.o;
              if (dn(n2), n2.sa) var i2 = void 0;
              else {
                let t4 = n2.h.h - r3;
                n2.h.h = r3, i2 = sn(n2.h, t4);
              }
              n2 = void 0;
              var s2 = t3, o2 = h3, a2 = i2;
              a2 && ((n2 = s2[X] ?? (s2[X] = new $e()))[o2] ?? (n2[o2] = [])).push(a2);
            }
          }
          let u2 = Ne(t3);
          u2 && (u2.la = r2.Fa[Ti]);
          var h2 = true;
          break t;
        } catch (t4) {
          if (t4 instanceof RangeError) throw new SyntaxError();
          throw t4;
        } finally {
          hn > 0 && hn--;
        }
        h2 = void 0;
      }
      return h2;
    }, t2[Ai] = e2, t2[Ti] = Ii.bind(t2), e2;
  }
  function Ii(t2, e2, r2, n2) {
    var i2 = this[Ei], s2 = this[Ai], o2 = Ke(void 0, i2.da), a2 = Ne(t2);
    if (a2) {
      var h2 = false, u2 = i2.ja;
      if (u2) {
        if (i2 = (e3, r3, i3) => {
          if (0 !== i3.length) if (u2[r3]) for (let t3 of i3) {
            e3 = un(t3);
            try {
              h2 = true, s2(o2, e3);
            } finally {
              cn(e3);
            }
          }
          else n2?.(t2, r3, i3);
        }, null == e2) Me(a2, i2);
        else if (null != a2) {
          let t3 = a2[e2];
          t3 && i2(a2, e2, t3);
        }
        if (h2) {
          let n3 = 0 | t2[et];
          if (2 & n3 && 2048 & n3 && !r2?.eb) throw Error();
          let i3 = mt(n3), s3 = (e3, s4) => {
            if (null != or(t2, e3, i3)) {
              if (1 === r2?.mb) return;
              throw Error();
            }
            null != s4 && (n3 = hr(t2, n3, e3, s4, i3)), delete a2[e3];
          };
          null == e2 ? ft(o2, 0 | o2[et], (t3, e3) => {
            s3(t3, e3);
          }) : s3(e2, or(o2, e2, i3));
        }
      }
    }
  }
  function Fi(t2) {
    var e2 = (t2 = ki(t2))[0].h;
    if (t2 = t2[1]) {
      let r2 = Ri(t2), n2 = bi(Ei, Li, xi, t2).da;
      return (t3, i2, s2) => e2(t3, i2, s2, n2, r2);
    }
    return e2;
  }
  function Ci(t2, e2, r2) {
    t2[e2] = r2.i;
  }
  function Ni(t2, e2, r2, n2) {
    var i2, s2, o2 = r2.i;
    t2[e2] = (t3, e3, r3) => o2(t3, e3, r3, s2 ||= bi(yi, Ci, Ni, n2).da, i2 ||= Mi(n2));
  }
  function Mi(t2) {
    var e2 = t2[wi];
    if (!e2) {
      let r2 = bi(yi, Ci, Ni, t2);
      e2 = (t3, e3) => Oi(t3, e3, r2), t2[wi] = e2;
    }
    return e2;
  }
  function Oi(t2, e2, r2) {
    ft(t2, 0 | t2[et], (t3, n2) => {
      if (null != n2) {
        var i2 = (function(t4, e3) {
          var r3 = t4[e3];
          if (r3) return r3;
          if ((r3 = t4.ja) && (r3 = r3[e3])) {
            var n3 = (r3 = ki(r3))[0].i;
            if (r3 = r3[1]) {
              let e4 = Mi(r3), i3 = bi(yi, Ci, Ni, r3).da;
              r3 = t4.xa ? gi(i3, e4) : (t5, r4, s2) => n3(t5, r4, s2, i3, e4);
            } else r3 = n3;
            return t4[e3] = r3;
          }
        })(r2, t3);
        i2 ? i2(e2, n2, t3) : t3 < 500 || $(Y, 3);
      }
    }), (t2 = Ne(t2)) && Me(t2, (t3, r3, n2) => {
      for (Gn(e2, e2.h.end()), t3 = 0; t3 < n2.length; t3++) Gn(e2, F(n2[t3]) || new Uint8Array(0));
    });
  }
  var Di = At(0);
  function Pi(t2, e2, r2) {
    if (Array.isArray(e2)) {
      var n2 = 0 | e2[et];
      if (4 & n2) return e2;
      for (var i2 = 0, s2 = 0; i2 < e2.length; i2++) {
        let r3 = t2(e2[i2]);
        null != r3 && (e2[s2++] = r3);
      }
      return s2 < i2 && (e2.length = s2), t2 = 1 | n2, r2 && (t2 = -1537 & t2 | 4), t2 !== n2 && it(e2, t2), r2 && 2 & t2 && Object.freeze(e2), e2;
    }
  }
  var $i = (t2, e2) => {
    var r2 = new Yn();
    Oi(t2.B, r2, bi(yi, Ci, Ni, e2)), Gn(r2, r2.h.end()), t2 = new Uint8Array(r2.i);
    var n2 = (e2 = r2.l).length, i2 = 0;
    for (let r3 = 0; r3 < n2; r3++) {
      let n3 = e2[r3];
      t2.set(n3, i2), i2 += n3.length;
    }
    return r2.l = [t2], t2;
  };
  function Ui(t2, e2, r2) {
    return new di(t2, e2, r2);
  }
  function Bi(t2, e2, r2) {
    return new di(t2, e2, r2);
  }
  function ji(t2, e2, r2) {
    hr(t2, 0 | t2[et], e2, r2, mt(0 | t2[et]));
  }
  var Gi = fi(function(t2, e2, r2, n2, i2) {
    if (2 !== t2.i) return false;
    if (t2 = Vt(t2 = pn(t2, Ke([void 0, void 0], n2), i2)), i2 = mt(n2 = 0 | e2[et]), 2 & n2) throw Error();
    var s2 = or(e2, r2, i2);
    if (s2 instanceof Re) 2 & s2.N ? ((s2 = s2.fa()).push(t2), hr(e2, n2, r2, s2, i2)) : s2.hb(t2);
    else if (Array.isArray(s2)) {
      var o2 = 0 | s2[et];
      8192 & o2 || it(s2, o2 |= 8192), 2 & o2 && hr(e2, n2, r2, s2 = vr(s2), i2), s2.push(t2);
    } else hr(e2, n2, r2, ot([t2]), i2);
    return true;
  }, function(t2, e2, r2, n2, i2) {
    if (e2 instanceof Re) e2.forEach((e3, s2) => {
      zn(t2, r2, Ke([s2, e3], n2), i2);
    });
    else if (Array.isArray(e2)) {
      for (let s2 = 0; s2 < e2.length; s2++) {
        let o2 = e2[s2];
        Array.isArray(o2) && zn(t2, r2, Ke(o2, n2), i2);
      }
      ot(e2);
    }
  });
  function Vi(t2, e2, r2) {
    null != (e2 = Jt(e2)) && (Vn(t2, r2, 5), t2 = t2.h, Mt(e2), Bn(t2, It));
  }
  function Hi(t2, e2, r2) {
    null != (e2 = pe(e2)) && (qn(e2), Xn(t2, r2, e2));
  }
  function Ki(t2, e2, r2) {
    null != (e2 = re(e2)) && null != e2 && (Vn(t2, r2, 0), $n(t2.h, e2));
  }
  function Xi(t2, e2, r2) {
    null != (e2 = null == e2 || "boolean" == typeof e2 ? e2 : "number" == typeof e2 ? !!e2 : void 0) && (Vn(t2, r2, 0), t2.h.h.push(e2 ? 1 : 0));
  }
  function Wi(t2, e2, r2) {
    null != (e2 = _e(e2)) && Wn(t2, r2, c(e2));
  }
  function zi(t2, e2, r2, n2, i2) {
    zn(t2, r2, Si(e2, n2), i2);
  }
  function Yi(t2, e2, r2) {
    null != (e2 = me(e2)) && Wn(t2, r2, Wr(e2, true).buffer);
  }
  function qi(t2, e2, r2) {
    null != (e2 = ne(e2)) && null != e2 && (Vn(t2, r2, 0), Pn(t2.h, e2));
  }
  function Ji(t2, e2, r2) {
    null != (e2 = re(e2)) && (e2 = parseInt(e2, 10), Vn(t2, r2, 0), $n(t2.h, e2));
  }
  function Zi(t2, e2, r2) {
    return (5 === t2.i || 2 === t2.i) && (e2 = yr(e2, 0 | e2[et], r2), 2 == t2.i ? vn(t2, tn, e2) : e2.push(tn(t2.h)), true);
  }
  function Qi(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, Zr(t2.h)), true);
  }
  function ts(t2, e2, r2) {
    return (0 === t2.i || 2 === t2.i) && (e2 = yr(e2, 0 | e2[et], r2), 2 == t2.i ? vn(t2, qr, e2) : e2.push(qr(t2.h)), true);
  }
  function es(t2, e2, r2) {
    return 2 === t2.i && (ji(e2, r2, (t2 = gn(t2)) === I() ? void 0 : t2), true);
  }
  var rs = Ui(function(t2, e2, r2) {
    if (1 !== t2.i) return false;
    var n2 = t2.h;
    t2 = Qr(n2);
    var i2 = Qr(n2);
    n2 = 2 * (i2 >> 31) + 1;
    var s2 = i2 >>> 20 & 2047;
    return t2 = 4294967296 * (1048575 & i2) + t2, ji(e2, r2, 2047 == s2 ? t2 ? NaN : n2 * (1 / 0) : 0 == s2 ? 5e-324 * n2 * t2 : n2 * Math.pow(2, s2 - 1075) * (t2 + 4503599627370496)), true;
  }, function(t2, e2, r2) {
    null != (e2 = Jt(e2)) && (Vn(t2, r2, 1), t2 = t2.h, (r2 = xt ||= new DataView(new ArrayBuffer(8))).setFloat64(0, +e2, true), It = r2.getUint32(0, true), Ft = r2.getUint32(4, true), Bn(t2, It), Bn(t2, Ft));
  }, ai);
  var ns = Ui(function(t2, e2, r2) {
    return 5 === t2.i && (ji(e2, r2, tn(t2.h)), true);
  }, Vi, oi);
  var is = Bi(Zi, function(t2, e2, r2) {
    if (null != (e2 = Pi(Jt, e2, true))) for (let o2 = 0; o2 < e2.length; o2++) {
      var n2 = t2, i2 = r2, s2 = e2[o2];
      null != s2 && (Vn(n2, i2, 5), n2 = n2.h, Mt(s2), Bn(n2, It));
    }
  }, oi);
  var ss = Bi(Zi, function(t2, e2, r2) {
    if (null != (e2 = Pi(Jt, e2, true)) && e2.length) {
      Vn(t2, r2, 2), Pn(t2.h, 4 * e2.length);
      for (let n2 = 0; n2 < e2.length; n2++) r2 = t2.h, Mt(e2[n2]), Bn(r2, It);
    }
  }, oi);
  var os = Ui(function(t2, e2, r2) {
    return 5 === t2.i && (ji(e2, r2, 0 === (t2 = tn(t2.h)) ? void 0 : t2), true);
  }, Vi, oi);
  var as = Ui(function(t2, e2, r2) {
    return Qi(t2, e2, r2);
  }, Hi, ni);
  var hs = Ui(function(t2, e2, r2) {
    return Qi(t2, e2, r2);
  }, Hi, ni);
  var us = Bi(function(t2, e2, r2) {
    return 0 !== t2.i && 2 !== t2.i ? t2 = false : (e2 = yr(e2, 0 | e2[et], r2), 2 == t2.i ? vn(t2, Zr, e2) : e2.push(Zr(t2.h)), t2 = true), t2;
  }, function(t2, e2, r2) {
    if (null != (e2 = Pi(pe, e2, false))) for (let n2 = 0; n2 < e2.length; n2++) Xn(t2, r2, e2[n2]);
  }, ni);
  var cs = Ui(function(t2, e2, r2) {
    return 0 !== t2.i ? e2 = false : (ji(e2, r2, (t2 = Zr(t2.h)) === Di ? void 0 : t2), e2 = true), e2;
  }, Hi, ni);
  var ls = Ui(function(t2, e2, r2) {
    return 0 !== t2.i ? t2 = false : (ji(e2, r2, zr(t2.h, Dt)), t2 = true), t2;
  }, function(t2, e2, r2) {
    if (e2 = (function(t3) {
      if (null == t3) return t3;
      var e3 = typeof t3;
      if ("bigint" === e3) return String(Kt(64, t3));
      if (te(t3)) {
        if ("string" === e3) return e3 = zt(Number(t3)), Xt(e3) && e3 >= 0 ? t3 = String(e3) : (-1 !== (e3 = t3.indexOf(".")) && (t3 = t3.substring(0, e3)), t3 = oe(t3)), t3;
        if ("number" === e3) return he(t3);
      }
    })(e2), null != e2) {
      if ("string" == typeof e2) An(e2);
      if (null != e2) switch (Vn(t2, r2, 0), typeof e2) {
        case "number":
          t2 = t2.h, Nt(e2), Dn(t2, It, Ft);
          break;
        case "bigint":
          r2 = On(e2, Tn, En), Dn(t2.h, r2.i, r2.h);
          break;
        default:
          r2 = An(e2), Dn(t2.h, r2.i, r2.h);
      }
    }
  }, ii);
  var ds = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, qr(t2.h)), true);
  }, Ki, ei);
  var fs = Bi(ts, function(t2, e2, r2) {
    if (null != (e2 = Pi(re, e2, true))) for (let o2 = 0; o2 < e2.length; o2++) {
      var n2 = t2, i2 = r2, s2 = e2[o2];
      null != s2 && (Vn(n2, i2, 0), $n(n2.h, s2));
    }
  }, ei);
  var ps = Bi(ts, function(t2, e2, r2) {
    if (null != (e2 = Pi(re, e2, true)) && e2.length) {
      r2 = Hn(t2, r2);
      for (let r3 = 0; r3 < e2.length; r3++) $n(t2.h, e2[r3]);
      Kn(t2, r2);
    }
  }, ei);
  var ms = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, 0 === (t2 = qr(t2.h)) ? void 0 : t2), true);
  }, Ki, ei);
  var gs = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, Yr(t2.h)), true);
  }, Xi, Qn);
  var vs = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, false === (t2 = Yr(t2.h)) ? void 0 : t2), true);
  }, Xi, Qn);
  var _s = Bi(function(t2, e2, r2) {
    return 2 === t2.i && (t2 = mn(t2), yr(e2, 0 | e2[et], r2).push(t2), true);
  }, function(t2, e2, r2) {
    if (null != (e2 = Pi(_e, e2, true))) for (let o2 = 0; o2 < e2.length; o2++) {
      var n2 = t2, i2 = r2, s2 = e2[o2];
      null != s2 && Wn(n2, i2, c(s2));
    }
  }, ti);
  var ys = Ui(function(t2, e2, r2) {
    return 2 === t2.i && (ji(e2, r2, "" === (t2 = mn(t2)) ? void 0 : t2), true);
  }, Wi, ti);
  var Es = Ui(function(t2, e2, r2) {
    return 2 === t2.i && (ji(e2, r2, mn(t2)), true);
  }, Wi, ti);
  var As = (function(t2, e2, r2 = Zn) {
    return new di(t2, e2, r2);
  })(function(t2, e2, r2, n2, i2) {
    return 2 === t2.i && (n2 = Ke(void 0, n2), yr(e2, 0 | e2[et], r2).push(n2), pn(t2, n2, i2), true);
  }, function(t2, e2, r2, n2, i2) {
    if (Array.isArray(e2)) {
      for (let s2 = 0; s2 < e2.length; s2++) zi(t2, e2[s2], r2, n2, i2);
      1 & (t2 = 0 | e2[et]) || it(e2, 1 | t2);
    }
  });
  var ws = fi(function(t2, e2, r2, n2, i2, s2) {
    if (2 !== t2.i) return false;
    var o2 = 0 | e2[et];
    return wr(e2, o2, s2, r2, mt(o2)), pn(t2, e2 = br(e2, n2, r2), i2), true;
  }, zi);
  var Ts = Ui(function(t2, e2, r2) {
    return 2 === t2.i && (ji(e2, r2, gn(t2)), true);
  }, Yi, hi);
  var bs = Bi(function(t2, e2, r2) {
    return 2 === t2.i && (t2 = gn(t2), yr(e2, 0 | e2[et], r2).push(t2), true);
  }, function(t2, e2, r2) {
    if (null != (e2 = Pi(me, e2, false))) for (let o2 = 0; o2 < e2.length; o2++) {
      var n2 = t2, i2 = r2, s2 = e2[o2];
      null != s2 && Wn(n2, i2, Wr(s2, true).buffer);
    }
  }, hi);
  var ks = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, Jr(t2.h)), true);
  }, qi, ri);
  var Ss = Bi(function(t2, e2, r2) {
    return (0 === t2.i || 2 === t2.i) && (e2 = yr(e2, 0 | e2[et], r2), 2 == t2.i ? vn(t2, Jr, e2) : e2.push(Jr(t2.h)), true);
  }, function(t2, e2, r2) {
    if (null != (e2 = Pi(ne, e2, true))) for (let o2 = 0; o2 < e2.length; o2++) {
      var n2 = t2, i2 = r2, s2 = e2[o2];
      null != s2 && (Vn(n2, i2, 0), Pn(n2.h, s2));
    }
  }, ri);
  var Ls = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, 0 === (t2 = Jr(t2.h)) ? void 0 : t2), true);
  }, qi, ri);
  var xs = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, qr(t2.h)), true);
  }, Ji, ui);
  var Rs = Ui(function(t2, e2, r2) {
    return 0 === t2.i && (ji(e2, r2, 0 === (t2 = qr(t2.h)) ? void 0 : t2), true);
  }, Ji, ui);
  var Is = Ui(function(t2, e2, r2) {
    return 0 !== t2.i ? t2 = false : (ji(e2, r2, (function(t3) {
      return zr(t3, (t4, e3) => {
        var r3 = -(1 & t4);
        return Pt(t4 = (t4 >>> 1 | e3 << 31) ^ r3, e3 >>> 1 ^ r3);
      });
    })(t2.h)), t2 = true), t2;
  }, function(t2, e2, r2) {
    if (null != (e2 = pe(e2)) && (qn(e2), null != e2)) switch (Vn(t2, r2, 0), typeof e2) {
      case "number":
        t2 = t2.h, e2 = (r2 = e2) < 0, Ct(r2 = 2 * Math.abs(r2)), r2 = It;
        let n2 = Ft;
        e2 && (0 == r2 ? 0 == n2 ? n2 = r2 = 4294967295 : (n2--, r2 = 4294967295) : r2--), Dn(t2, It = r2, Ft = n2);
        break;
      case "bigint":
        t2 = t2.h, e2 = e2 << BigInt(1) ^ e2 >> BigInt(63), It = Number(BigInt.asUintN(32, e2)), Ft = Number(BigInt.asUintN(32, e2 >> BigInt(32))), Dn(t2, It, Ft);
        break;
      default:
        Un(t2.h, e2);
    }
  }, si);
  var Fs = class {
    constructor(t2, e2) {
      var r2 = so;
      this.h = t2, this.i = e2, this.o = kr, this.u = Rr, this.defaultValue = void 0, this.l = null != r2.kb ? pt : void 0;
    }
    register() {
      v(this);
    }
  };
  function Cs(t2, e2) {
    return new Fs(t2, e2);
  }
  function Ns(t2, e2) {
    return (r2, n2) => {
      t: {
        let s2 = { na: true };
        n2 && Object.assign(s2, n2), r2 = un(r2, void 0, void 0, s2);
        try {
          let n3 = new t2(), s3 = n3.B;
          Ri(e2)(s3, r2);
          var i2 = n3;
          break t;
        } catch (t3) {
          if (t3 instanceof RangeError) throw new SyntaxError();
          throw t3;
        } finally {
          cn(r2);
        }
        i2 = void 0;
      }
      return i2;
    };
  }
  function Ms(t2) {
    return (e2) => $i(e2, t2);
  }
  function Os(t2) {
    return function() {
      return $i(this, t2);
    };
  }
  var Ds = [0, Ts, bs, gs, Es];
  var Ps = [0, ys, [0, Rs, [0, cs, ms], Rs, -1, [0, xs], Rs, -1], Ui(es, Yi, hi)];
  var $s;
  var Us = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Bs = [0, ys, Ui(es, function(t2, e2, r2) {
    if (null != e2) {
      if (e2 instanceof li) {
        let n2 = e2.nb;
        return void (n2 ? (e2 = n2(e2), null != e2 && Wn(t2, r2, Wr(e2, true).buffer)) : $(Y, 3));
      }
      if (Array.isArray(e2)) return void $(Y, 3);
    }
    Yi(t2, e2, r2);
  }, hi)];
  var js = [0, 1, [0, 12, ds, 10, gs], [0, 7, [0, ds, -1]]];
  var Gs = globalThis.trustedTypes;
  var Vs = class {
    constructor(t2) {
      this.h = t2;
    }
    toString() {
      return this.h + "";
    }
  };
  function Hs(t2) {
    var e2;
    return void 0 === $s && ($s = (function() {
      var t3 = null;
      if (!Gs) return t3;
      try {
        let e3 = (t4) => t4;
        t3 = Gs.createPolicy("goog#html", { createHTML: e3, createScript: e3, createScriptURL: e3 });
      } catch (t4) {
      }
      return t3;
    })()), t2 = (e2 = $s) ? e2.createScriptURL(t2) : t2, new Vs(t2);
  }
  function Ks(t2, ...e2) {
    if (0 === e2.length) return Hs(t2[0]);
    var r2 = t2[0];
    for (let n2 = 0; n2 < e2.length; n2++) r2 += encodeURIComponent(e2[n2]) + t2[n2 + 1];
    return Hs(r2);
  }
  var Xs = [0, ds, xs, gs, -1, ps, xs, -1, gs, -1];
  var Ws = [0, xs, -1, gs];
  var zs = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ys = [0, gs, Es, gs, xs, -1, Bi(function(t2, e2, r2) {
    return (0 === t2.i || 2 === t2.i) && (e2 = yr(e2, 0 | e2[et], r2), 2 == t2.i ? vn(t2, en, e2) : e2.push(qr(t2.h)), true);
  }, function(t2, e2, r2) {
    if (null != (e2 = Pi(re, e2, true)) && e2.length) {
      r2 = Hn(t2, r2);
      for (let r3 = 0; r3 < e2.length; r3++) $n(t2.h, e2[r3]);
      Kn(t2, r2);
    }
  }, ui), Es, -1, [0, gs, -1], xs, gs, -1, Ws];
  var qs = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Js = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Zs = class extends li {
    constructor(t2) {
      super(t2);
    }
    h() {
      return ur(this, 9);
    }
  };
  var Qs = [0, 3, gs, -1, 2, [0, [2], ds, ws, [0, ks]], [0, xs, gs, xs, gs, xs, 4, [0, gs, Es, -1, gs], xs, gs, -1], [0, [3, 4], Es, -1, ws, [0, ds], ws, [0, xs, -1]], [0], Es, gs];
  var to = [0, Es, -2];
  var eo = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var ro = [0];
  var no = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var io = [0, ds, gs, 1, gs, -4];
  var so = class extends li {
    constructor(t2) {
      super(t2, 2);
    }
  };
  var oo = {};
  oo[336783863] = [0, Es, gs, -1, ds, [0, [1, 2, 3, 4, 5, 6, 7, 8, 9], ws, ro, ws, Ys, ws, to, ws, io, ws, Xs, ws, [0, Es, -2], ws, [0, Es, xs], ws, Qs, ws, Ws], [0, Es], gs, [0, [1, 3], [2, 4], ws, [0, ps], -1, ws, [0, _s], -1, As, [0, Es, -1]], Es];
  var ao = [0, cs, -1, vs, -3, cs, ps, ys, ms, cs, -1, vs, ms, vs, -2, ys];
  function ho(t2, e2) {
    Kr(t2, 3, e2);
  }
  function uo(t2, e2) {
    Kr(t2, 4, e2);
  }
  var co = class extends li {
    constructor(t2) {
      super(t2, 500);
    }
    A(t2) {
      return Rr(this, 0, 7, t2);
    }
  };
  var lo = [-1, {}];
  var fo = [0, Es, 1, lo];
  var po = [0, Es, _s, lo];
  function mo(t2, e2) {
    Nr(t2, 1, co, e2);
  }
  function go(t2, e2) {
    Kr(t2, 10, e2);
  }
  function vo(t2, e2) {
    Kr(t2, 15, e2);
  }
  var _o = class extends li {
    constructor(t2) {
      super(t2, 500);
    }
    A(t2) {
      return Rr(this, 0, 1001, t2);
    }
  };
  var yo = [-500, As, [-500, ys, -1, _s, -3, [-2, oo, gs], As, Bs, ms, -1, fo, po, As, [0, ys, vs], ys, ao, ms, _s, 987, _s], 4, As, [-500, Es, -1, [-1, {}], 998, Es], As, [-500, Es, _s, -1, [-2, {}, gs], 997, _s, -1], ms, As, [-500, Es, _s, lo, 998, _s], _s, ms, fo, po, As, [0, ys, -1, lo], _s, -2, ao, ys, -1, vs, [0, vs, Ls], 978, lo, As, Bs];
  _o.prototype.h = Os(yo);
  var Eo = Ns(_o, yo);
  var Ao = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var wo = class extends li {
    constructor(t2) {
      super(t2);
    }
    h() {
      return Lr(this, Ao, 1);
    }
  };
  var To = [0, As, [0, ds, ns, Es, -1]];
  var bo = Ns(wo, To);
  var ko = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var So = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Lo = class extends li {
    constructor(t2) {
      super(t2);
    }
    l() {
      return kr(this, ko, 2);
    }
    h() {
      return Lr(this, So, 5);
    }
  };
  var xo = Ns(class extends li {
    constructor(t2) {
      super(t2);
    }
  }, [0, _s, ps, ss, [0, xs, [0, ds, -3], [0, ns, -3], [0, ds, -1, [0, As, [0, ds, -2]]], As, [0, ns, -1, Es, ns]], Es, -1, hs, As, [0, ds, ns], _s, hs]);
  var Ro = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Io = Ns(class extends li {
    constructor(t2) {
      super(t2);
    }
  }, [0, As, [0, ns, -4]]);
  var Fo = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Co = Ns(class extends li {
    constructor(t2) {
      super(t2);
    }
  }, [0, As, [0, ns, -4]]);
  var No = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Mo = [0, ds, -1, ss, xs];
  var Oo = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  Oo.prototype.h = Os([0, ns, -4, hs]);
  var Do = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Po = Ns(class extends li {
    constructor(t2) {
      super(t2);
    }
  }, [0, As, [0, 1, ds, Es, To], hs]);
  var $o = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Uo = class extends li {
    constructor(t2) {
      super(t2);
    }
    h() {
      var t2 = sr(this, 1, void 0, gr);
      return null == t2 ? I() : t2;
    }
  };
  var Bo = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var jo = [1, 2];
  var Go = Ns(class extends li {
    constructor(t2) {
      super(t2);
    }
  }, [0, As, [0, jo, ws, [0, ss], ws, [0, Ts], ds, Es], hs]);
  var Vo = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ho = [0, Es, ds, ns, _s, -1];
  var Ko = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Xo = [0, gs, -1];
  var Wo = class extends li {
    constructor(t2) {
      super(t2);
    }
    h() {
      return cr(this, 2, zo);
    }
    l() {
      return Dr(this, Zs, 6, zo);
    }
  };
  var zo = [1, 2, 3, 4, 5, 6];
  var Yo = class extends li {
    constructor(t2) {
      super(t2);
    }
    h() {
      return null != sr(this, 1, void 0, gr);
    }
    l() {
      return null != _e(sr(this, 2));
    }
  };
  var qo = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Jo = [0, Ts, Es, [0, ds, hs, -1], [0, ls, hs]];
  var Zo = [0, Jo, gs, [0, zo, ws, io, ws, Ys, ws, Xs, ws, ro, ws, to, ws, Qs], xs];
  var Qo = Ms(Zo);
  var ta = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var ea = [0, Zo, ns, -1, ds];
  var ra = Cs(502141897, ta);
  oo[502141897] = ea;
  var na = Ns(class extends li {
    constructor(t2) {
      super(t2);
    }
  }, [0, [0, xs, -1, is, Ss], Mo]);
  var ia = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var sa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var oa = [0, Zo, ns, [0, Zo], gs];
  var aa = Cs(508968150, sa);
  oo[508968150] = [0, Zo, ea, oa, ns, [0, [0, Jo]]], oo[508968149] = oa;
  var ha = class extends li {
    constructor(t2) {
      super(t2);
    }
    l() {
      return kr(this, Vo, 2);
    }
    h() {
      ar(this, 2);
    }
  };
  var ua = [0, Zo, Ho];
  oo[478825465] = ua;
  var ca = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var la = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var da = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var fa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var pa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var ma = [0, Zo, [0, Zo], ua, -1];
  var ga = [0, Zo, ns, ds];
  var va = [0, Zo, ns];
  var _a = [0, Zo, ga, va, ns];
  var ya = Cs(479097054, pa);
  oo[479097054] = [0, Zo, _a, ma], oo[463370452] = ma, oo[464864288] = ga;
  var Ea = Cs(462713202, fa);
  oo[462713202] = _a, oo[474472470] = va;
  var Aa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var wa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ta = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var ba = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var ka = [0, Zo, ns, -1, ds];
  var Sa = [0, Zo, ns, gs];
  ba.prototype.h = Os([0, Zo, va, [0, Zo], ea, oa, ka, Sa]);
  var La = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var xa = Cs(456383383, La);
  oo[456383383] = [0, Zo, Ho];
  var Ra = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ia = Cs(476348187, Ra);
  oo[476348187] = [0, Zo, Xo];
  var Fa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ca = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Na = [0, xs, -1];
  var Ma = Cs(458105876, class extends li {
    constructor(t2) {
      super(t2);
    }
    h() {
      var t2 = this.B, e2 = 0 | t2[et], r2 = ut(this, e2);
      return t2 = (function(t3, e3, r3, n2) {
        var i2 = Ca;
        !n2 && Qe(t3) && (r3 = 0 | (e3 = t3.B)[et]);
        var s2 = or(e3, 2);
        if (t3 = false, null == s2) {
          if (n2) return Ce();
          s2 = [];
        } else if (s2.constructor === Re) {
          if (!(2 & s2.N) || n2) return s2;
          s2 = s2.fa();
        } else Array.isArray(s2) ? t3 = !!(2 & s2[et]) : s2 = [];
        if (n2) {
          if (!s2.length) return Ce();
          t3 || (t3 = true, st(s2));
        } else t3 && (t3 = false, ot(s2), s2 = vr(s2));
        return !t3 && 32 & r3 && nt(s2, 32), r3 = hr(e3, r3, 2, n2 = new Re(s2, i2, Ee, void 0)), t3 || er(e3, r3), n2;
      })(this, t2, e2, r2), !r2 && Ca && (t2.Ga = true), t2;
    }
  });
  oo[458105876] = [0, Na, Gi, [true, hs, [0, Es, -1, _s]], [0, ps, gs, xs], gs];
  var Oa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Da = Cs(458105758, Oa);
  oo[458105758] = [0, Zo, Es, Na];
  var Pa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var $a = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ua = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ba = Ms([0, As, [0, Rs, As, [0, os, -1], vs]]);
  var ja = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ga = [0, os, -1, vs];
  var Va = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ha = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ka = [1, 2];
  Ha.prototype.h = Os([0, Ka, ws, Ga, ws, [0, As, Ga]]);
  var Xa = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Wa = Cs(443442058, Xa);
  oo[443442058] = [0, Zo, Es, ds, ns, _s, -1, gs, ns], oo[514774813] = ka;
  var za = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ya = Cs(516587230, za);
  function qa(t2, e2) {
    return e2 = e2 ? e2.clone() : new Vo(), void 0 !== t2.displayNamesLocale ? ar(e2, 1, ve(t2.displayNamesLocale)) : void 0 === t2.displayNamesLocale && ar(e2, 1), void 0 !== t2.maxResults ? $r(e2, 2, t2.maxResults) : "maxResults" in t2 && ar(e2, 2), void 0 !== t2.scoreThreshold ? jr(e2, 3, t2.scoreThreshold) : "scoreThreshold" in t2 && ar(e2, 3), void 0 !== t2.categoryAllowlist ? Hr(e2, 4, t2.categoryAllowlist) : "categoryAllowlist" in t2 && ar(e2, 4), void 0 !== t2.categoryDenylist ? Hr(e2, 5, t2.categoryDenylist) : "categoryDenylist" in t2 && ar(e2, 5), e2;
  }
  function Ja(t2) {
    var e2 = Number(t2);
    return Number.isSafeInteger(e2) ? e2 : String(t2);
  }
  function Za(t2, e2 = -1, r2 = "") {
    return { categories: t2.map((t3) => ({ index: Mr(t3, 1) ?? 0 ?? -1, score: Or(t3, 2) ?? 0, categoryName: _e(sr(t3, 3)) ?? "" ?? "", displayName: _e(sr(t3, 4)) ?? "" ?? "" })), headIndex: e2, headName: r2 };
  }
  function Qa(t2) {
    var e2 = { classifications: Lr(t2, Do, 1).map((t3) => Za(kr(t3, wo, 4)?.h() ?? [], Mr(t3, 2) ?? 0, _e(sr(t3, 3)) ?? "")) };
    return null != (function(t3) {
      return null == t3 ? t3 : "bigint" == typeof t3 ? (wt(t3) ? t3 = Number(t3) : (t3 = Ht(64, t3), t3 = wt(t3) ? Number(t3) : String(t3)), t3) : te(t3) ? "number" == typeof t3 ? ae(t3) : ce(t3) : void 0;
    })(sr(t2, 2, void 0, fe)) && (e2.timestampMs = Ja(sr(t2, 2, void 0, fe) ?? nr)), e2;
  }
  function th(t2) {
    var e2 = lr(t2, 3, Jt), r2 = lr(t2, 2, re), n2 = lr(t2, 1, _e), i2 = lr(t2, 9, _e), s2 = { categories: [], keypoints: [] };
    for (let t3 = 0; t3 < e2.length; t3++) s2.categories.push({ score: e2[t3], index: r2[t3] ?? -1, categoryName: n2[t3] ?? "", displayName: i2[t3] ?? "" });
    if ((e2 = kr(t2, Lo, 4)?.l()) && (s2.boundingBox = { originX: Mr(e2, 1, ir) ?? 0, originY: Mr(e2, 2, ir) ?? 0, width: Mr(e2, 3, ir) ?? 0, height: Mr(e2, 4, ir) ?? 0, angle: 0 }), kr(t2, Lo, 4)?.h().length) for (let e3 of kr(t2, Lo, 4).h()) s2.keypoints.push({ x: sr(e3, 1, ir, Jt) ?? 0, y: sr(e3, 2, ir, Jt) ?? 0, score: sr(e3, 4, ir, Jt) ?? 0, label: _e(sr(e3, 3, ir)) ?? "" });
    return s2;
  }
  function eh(t2) {
    var e2 = [];
    for (let r2 of Lr(t2, Fo, 1)) t2 = { x: Or(r2, 1) ?? 0, y: Or(r2, 2) ?? 0, z: Or(r2, 3) ?? 0, visibility: Or(r2, 4) ?? 0 }, null != sr(r2, 5, void 0, Jt) && (t2.presence = Or(r2, 5) ?? 0), e2.push(t2);
    return e2;
  }
  function rh(t2) {
    var e2 = [];
    for (let r2 of Lr(t2, Ro, 1)) t2 = { x: Or(r2, 1) ?? 0, y: Or(r2, 2) ?? 0, z: Or(r2, 3) ?? 0, visibility: Or(r2, 4) ?? 0 }, null != sr(r2, 5, void 0, Jt) && (t2.presence = Or(r2, 5) ?? 0), e2.push(t2);
    return e2;
  }
  function nh(t2) {
    return Array.from(t2, (t3) => t3 > 127 ? t3 - 256 : t3);
  }
  function ih(t2, e2) {
    if (t2.length !== e2.length) throw Error(`Cannot compute cosine similarity between embeddings of different sizes (${t2.length} vs. ${e2.length}).`);
    var r2 = 0, n2 = 0, i2 = 0;
    for (let s2 = 0; s2 < t2.length; s2++) r2 += t2[s2] * e2[s2], n2 += t2[s2] * t2[s2], i2 += e2[s2] * e2[s2];
    if (n2 <= 0 || i2 <= 0) throw Error("Cannot compute cosine similarity on embedding with 0 norm.");
    return r2 / Math.sqrt(n2 * i2);
  }
  oo[516587230] = [0, Zo, ka, Sa, ns], oo[518928384] = Sa;
  var sh;
  var oh = new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 10, 1, 8, 0, 65, 0, 253, 15, 253, 98, 11]);
  async function ah(t2) {
    if (t2) return true;
    if (void 0 === sh) try {
      await WebAssembly.instantiate(oh), sh = true;
    } catch {
      sh = false;
    }
    return sh;
  }
  async function hh(t2, e2, r2) {
    return { wasmLoaderPath: `${e2}/${t2}_${r2 = `wasm${r2 ? "_module" : ""}${await ah(r2) ? "" : "_nosimd"}_internal`}.js`, wasmBinaryPath: `${e2}/${t2}_${r2}.wasm` };
  }
  var uh = class {
  };
  function ch(t2) {
    return ar(new lh(), 1, ee(t2));
  }
  uh.forVisionTasks = function(t2, e2 = false) {
    return hh("vision", t2 ?? Ks``, e2);
  }, uh.forLiteRtLmTextTasks = function(t2, e2 = false) {
    return hh("litertlm_text", t2 ?? Ks``, e2);
  }, uh.forTextTasks = function(t2, e2 = false) {
    return hh("text", t2 ?? Ks``, e2);
  }, uh.forRetrievalTasks = function(t2, e2 = false) {
    return hh("retrieval", t2 ?? Ks``, e2);
  }, uh.forGenAiTasks = function(t2, e2 = false) {
    return hh("genai", t2 ?? Ks``, e2);
  }, uh.forDecisionTasks = function(t2, e2 = false) {
    return hh("decision", t2 ?? Ks``, e2);
  }, uh.forAudioTasks = function(t2, e2 = false) {
    return hh("audio", t2 ?? Ks``, e2);
  }, uh.isSimdSupported = function(t2 = false) {
    return ah(t2);
  };
  var lh = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var dh = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var fh = [0, xs, 2, ls, -2, hs, As, [0, xs, hs]];
  var ph = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var mh = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  function gh(t2, e2) {
    return ar(t2, 1, ee(e2));
  }
  function vh(t2, e2) {
    return ar(t2, 2, ee(e2));
  }
  var _h = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var yh = [3, 4, 5, 6, 7];
  var Eh = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  var Ah = class extends li {
    constructor(t2) {
      super(t2);
    }
  };
  Ah.prototype.h = Os([0, [0, xs, Es, -3, xs], [0, yh, xs, -1, ws, [0, xs, Es, ls], ws, fh, ws, [0, 1, fh], ws, [0, xs], ws, [0, xs, Es, ls]]]);
  var wh = class {
    constructor() {
      this.h = "undefined" != typeof AbortController;
    }
    async send(t2, e2, r2) {
      var n2 = this.h ? new AbortController() : void 0, i2 = n2 && t2.ma > 0 ? setTimeout(() => {
        n2.abort();
      }, t2.ma) : void 0;
      try {
        let i3 = await fetch(t2.url, { method: t2.cb, headers: { ...t2.bb }, ...t2.body && { body: t2.body }, ...t2.withCredentials && { credentials: "include" }, signal: t2.ma && n2 ? n2.signal : null });
        200 === i3.status ? e2?.(await i3.text()) : r2?.(i3.status);
      } catch (t3) {
        if ("AbortError" === t3?.name) r2?.(408);
        else r2?.(400);
      } finally {
        clearTimeout(i2);
      }
    }
  };
  var Th = class extends li {
    constructor(t2) {
      super(t2, 37);
    }
  };
  var bh = [-4, {}, js, xs, Ps];
  var kh = [0, Es, xs, 1, Es, -1, xs, 1, xs, 1, hs];
  var Sh = [0, xs, Es, -2];
  var Lh = [0, Es, xs];
  var xh = [0, Es, xs];
  var Rh = [0, gs, -3];
  var Ih = [0, xs, Es, -1, hs, ds, -1, Es, -5, As, [0, Es, -4], -1, gs, [0, gs, -3], xs];
  var Fh = class extends li {
    constructor(t2) {
      super(t2, 19);
    }
  };
  var Ch = Ms([-19, {}, [0, xs, 1, [0, Es, -6, hs, ds, Es, -1, hs], 1, [0, Es, 1, Es, -5], Es, -1, [0, xs, Es, -8], [0, Es, -3], [0, Es, xs, Es, -2], [0, Es, -1, xs, Es, -1, xs, Es, -1, [0, As, [0, Es, -1], gs, Es, -5], [0, xs, gs, ds, -2]], hs, [0, Es, -3, hs, ds, Es, -1], [0, xs, Es, -1], [0, Es, -9], [0, Es, -6, xs, Es, 1, Es, gs, xs, -1, gs, Es, -2, xs, Es, xs, Es, ds, -1], 1, [0, xs], 1, [0, Es, -4], 1, kh, [0, [1, 2, 3, 4, 5, 6], ws, kh, ws, Lh, ws, xh, ws, [0, xs], ws, Ih, ws, Sh], Lh, xh, Ih, [0, [0, xs, Es, -1, hs, ds, -1, Es, -4, As, [0, Es, -4], -1, 1, Rh], [0, xs, Es, -1, hs, ds, -1, Es, -4, Rh]], Sh, [0, Es, [0, ds, -3, xs], xs, -2, [0, ds, -1], gs], 4, [0, Es, xs, Es, -1, hs, xs, Es, -1, xs, ds, -1]], xs, As, [-37, {}, as, Es, As, [0, Es, -1], Ts, 1, Ts, [0, _s, -1, fs, us, -1], Es, [0, ds, Es, -1], gs, ds, hs, Es, -1, Is, Ds, as, Ts, xs, fs, hs, -1, [0, xs, -1], Es, gs, Es, ps, Es, -1, rs, 1, rs, bh, gs, [0, xs, [0, ns, ds, -2], [0, ns]], [0, xs, hs]], as, bs, Es, -1, as, xs, -1, [0, gs, -1, xs, gs], [0, hs, -1, Es], [0, as, gs, hs], hs, 1, ks, 1, bh]);
  var Nh = class {
    constructor(t2) {
      this.i = [], this.o = new wh(), this.l = t2 ?? "", this.h = setInterval(() => {
        this.flush();
      }, 6e4);
    }
    close() {
      void 0 !== this.h && (clearInterval(this.h), this.h = void 0), this.flush();
    }
    flush(t2, e2) {
      if (this.error) e2?.("net-send-failed");
      else if (0 === this.i.length) t2?.();
      else {
        var r2 = this.i;
        this.i = [], r2 = (function(t3) {
          var e3 = new Fh();
          return Fr(e3 = ar(e3, 2, ee(1786)), 3, t3);
        })(r2), r2 = Ch(r2), this.o.send({ url: "https://odml.pa.googleapis.com/v1/log", cb: "POST", ma: 1e4, body: r2, ib: 2, bb: { "Content-Type": "application/x-protobuf", "x-goog-api-key": this.l }, withCredentials: false }, () => {
          t2?.();
        }, (t3) => {
          this.error = Error(`Logging failed with HTTP error: ${t3}`), this.i = [], void 0 !== this.h && (clearInterval(this.h), this.h = void 0), e2?.("net-send-failed", t3);
        });
      }
    }
  };
  var Mh = class {
    constructor() {
      this.ba = this.V = this.Y = this.S = this.W = this.U = this.R = 0;
    }
  };
  function Oh(t2, e2) {
    var r2 = new Ah();
    r2 = Rr(r2, 0, 1, t2.C), r2 = Rr(r2, 0, 2, e2), e2 = ar(e2 = new Th(), 6, lt(r2 = r2.h(), false)), (t2 = t2.m).error || t2.i.push(e2);
  }
  function Dh(t2, e2) {
    var r2 = { R: e2.R - t2.l.R, U: e2.U - t2.l.U, W: e2.W - t2.l.W, S: e2.S - t2.l.S, Y: e2.Y - t2.l.Y, V: e2.V, ba: e2.ba }, n2 = vh(gh(new _h(), t2.D), 1);
    r2 = Ph(t2, r2), Oh(t2, n2 = Ir(n2, 4, yh, r2)), t2.l = e2;
  }
  function Ph(t2, e2) {
    var r2 = new dh();
    return t2 = Br(t2 = Ur(t2 = ar(r2, 1, ee(t2.F)), 7, e2.S), 5, e2.V), t2 = Br(t2, 6, e2.ba), e2.W > 0 && Br(t2, 4, e2.Y / e2.W), 0 !== e2.R && (r2 = Ur(r2 = ch(3), 2, e2.R), Nr(t2, 8, lh, r2)), 0 !== e2.U && (e2 = Ur(r2 = ch(4), 2, e2.U), Nr(t2, 8, lh, e2)), t2;
  }
  var $h = class {
    constructor(t2, e2, r2) {
      this.v = performance.now(), this.o = performance.now(), this.i = /* @__PURE__ */ new Map(), this.u = 0, this.h = new Mh(), this.l = new Mh(), this.m = new Nh(r2), this.D = (function(t3) {
        switch (t3) {
          case "AudioClassifier":
            return 4;
          case "AudioEmbedder":
            return 5;
          case "TextClassifier":
            return 6;
          case "TextEmbedder":
            return 7;
          case "GestureRecognizer":
            return 8;
          case "HandDetector":
            return 9;
          case "HandLandmarker":
            return 10;
          case "ImageClassifier":
            return 11;
          case "ImageEmbedder":
            return 12;
          case "ImageSegmenter":
            return 13;
          case "ObjectDetector":
            return 14;
          case "FaceDetector":
            return 15;
          case "FaceLandmarker":
            return 16;
          case "InteractiveSegmenter":
          case "InteractiveSegmenterLegacy":
            return 18;
          case "HolisticLandmarker":
            return 20;
          case "LlmInference":
            return 21;
          case "LanguageDetector":
            return 22;
          case "PoseLandmarker":
            return 23;
          case "UniversalEmbedder":
            return 28;
          case "SemanticRetriever":
            return 29;
          case "DecisionMaker":
            return 30;
          case "TextSummarizer":
            return 26;
          case "TextProofreader":
            return 27;
          case "AudioTranscriber":
            return 31;
          default:
            return 0;
        }
      })(t2), this.F = (function(t3) {
        switch (t3) {
          case "IMAGE":
            return 11;
          case "VIDEO":
            return 12;
          case "LIVE_STREAM":
            return 13;
          case "AUDIO_CLIPS":
            return 14;
          case "AUDIO_STREAM":
            return 15;
          default:
            return 10;
        }
      })(e2), t2 = new Eh(), "undefined" == typeof window ? e2 = 0 : (e2 = navigator.userAgent, e2 = /Android/i.test(e2) ? 1 : /iPhone|iPad|iPod/i.test(e2) ? 2 : /Windows/i.test(e2) ? 5 : /Macintosh/i.test(e2) ? 4 : /Linux/i.test(e2) ? 3 : 0), t2 = ar(t2, 1, ee(e2)), t2 = ar(t2, 2, ve("")), t2 = ar(t2, 3, ve("")), t2 = ar(t2, 4, ve("1.1.1")), t2 = ar(t2, 5, ve("")), this.C = ar(t2, 6, ee(4));
    }
    za() {
      var t2 = new mh();
      t2 = Br(t2 = ar(t2, 1, ee(this.F)), 3, performance.now() - this.v), Oh(this, t2 = Ir(vh(gh(new _h(), this.D), 0), 3, yh, t2)), this.o = performance.now();
    }
    Aa(t2) {
      var e2 = this.i.get(t2);
      if (void 0 !== e2 && (this.i.delete(t2), t2 = performance.now() - e2, ++this.h.W, this.h.Y += t2, this.h.V = Math.max(this.h.V, t2), this.u = Math.max(this.u, t2), performance.now() > this.o + 3e4)) {
        for (let [r2, n2] of this.i.entries()) t2 = r2, n2 < e2 && (this.h.S++, this.i.delete(t2));
        e2 = { ...this.h, ba: performance.now() - this.o }, this.h.V = 0, this.o = performance.now(), Dh(this, e2);
      }
    }
    ya() {
      var t2 = { ...this.h, S: this.h.S + this.i.size, V: this.u, ba: performance.now() - this.v };
      Dh(this, t2);
      var e2 = new ph();
      e2 = Rr(e2, 0, 2, t2 = Ph(this, t2)), Oh(this, e2 = Ir(t2 = vh(gh(new _h(), this.D), 2), 5, yh, e2));
    }
    close() {
      var t2 = this.m;
      "function" == typeof t2.close ? t2.close() : t2.flush();
    }
  };
  function Uh() {
    var t2 = navigator;
    return "undefined" != typeof OffscreenCanvas && (!(function(t3 = navigator) {
      return (t3 = t3.userAgent).includes("Safari") && !t3.includes("Chrome");
    })(t2) || !!((t2 = t2.userAgent.match(/Version\/([\d]+).*Safari/)) && t2.length >= 1 && Number(t2[1]) >= 17));
  }
  async function Bh(t2) {
    if ("function" != typeof importScripts) {
      let e2 = document.createElement("script");
      return e2.src = t2.toString(), e2.crossOrigin = "anonymous", new Promise((t3, r2) => {
        e2.addEventListener("load", () => {
          t3();
        }, false), e2.addEventListener("error", (t4) => {
          r2(t4);
        }, false), document.body.appendChild(e2);
      });
    }
    try {
      importScripts(t2.toString());
    } catch (e2) {
      if (!(e2 instanceof TypeError)) throw e2;
      {
        let e3 = self.import;
        e3 ? await e3(t2.toString()) : await import(t2.toString());
      }
    }
  }
  function jh(t2) {
    return void 0 !== t2.videoWidth ? [t2.videoWidth, t2.videoHeight] : void 0 !== t2.naturalWidth ? [t2.naturalWidth, t2.naturalHeight] : void 0 !== t2.displayWidth ? [t2.displayWidth, t2.displayHeight] : [t2.width, t2.height];
  }
  function Gh(t2, e2, r2) {
    t2.o || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target"), r2(e2 = t2.j.stringToNewUTF8(e2)), t2.j._free(e2);
  }
  function Vh(t2, e2, r2) {
    if (!t2.j.canvas) throw Error("No OpenGL canvas configured.");
    if (r2 ? t2.j._bindTextureToStream(r2) : t2.j._bindTextureToCanvas(), !(r2 = t2.j.canvas.getContext("webgl2") || t2.j.canvas.getContext("webgl"))) throw Error("Failed to obtain WebGL context from the provided canvas. `getContext()` should only be invoked with `webgl` or `webgl2`.");
    t2.j.gpuOriginForWebTexturesIsBottomLeft && r2.pixelStorei(r2.UNPACK_FLIP_Y_WEBGL, true), r2.texImage2D(r2.TEXTURE_2D, 0, r2.RGBA, r2.RGBA, r2.UNSIGNED_BYTE, e2), t2.j.gpuOriginForWebTexturesIsBottomLeft && r2.pixelStorei(r2.UNPACK_FLIP_Y_WEBGL, false);
    var [n2, i2] = jh(e2);
    return !t2.l || n2 === t2.j.canvas.width && i2 === t2.j.canvas.height || (t2.j.canvas.width = n2, t2.j.canvas.height = i2), [n2, i2];
  }
  function Hh(t2, e2, r2) {
    t2.o || console.error("No wasm multistream support detected: ensure dependency inclusion of :gl_graph_runner_internal_multi_input target");
    var n2 = new Uint32Array(e2.length);
    for (let r3 = 0; r3 < e2.length; r3++) n2[r3] = t2.j.stringToNewUTF8(e2[r3]);
    e2 = t2.j._malloc(4 * n2.length), t2.j.HEAPU32.set(n2, e2 >> 2), r2(e2);
    for (let e3 of n2) t2.j._free(e3);
    t2.j._free(e2);
  }
  function Kh(t2, e2, r2) {
    t2.j.simpleListeners = t2.j.simpleListeners || {}, t2.j.simpleListeners[e2] = r2;
  }
  function Xh(t2, e2, r2) {
    var n2 = [];
    t2.j.simpleListeners = t2.j.simpleListeners || {}, t2.j.simpleListeners[e2] = (t3, e3, i2) => {
      e3 ? (r2(n2, i2), n2 = []) : n2.push(t3);
    };
  }
  var Wh = class {
    constructor(t2, e2) {
      this.l = true, this.j = t2, this.h = null, this.i = 0, this.o = "function" == typeof this.j._addIntToInputStream, void 0 !== e2 ? this.j.canvas = e2 : Uh() ? this.j.canvas = new OffscreenCanvas(1, 1) : (console.warn("OffscreenCanvas not supported and GraphRunner constructor glCanvas parameter is undefined. Creating backup canvas."), this.j.canvas = document.createElement("canvas"));
    }
    async initializeGraph(t2) {
      var e2 = await (await fetch(t2)).arrayBuffer();
      t2 = !(t2.endsWith(".pbtxt") || t2.endsWith(".textproto")), this.setGraph(new Uint8Array(e2), t2);
    }
    setGraphFromString(t2) {
      this.setGraph(new TextEncoder().encode(t2), false);
    }
    setGraph(t2, e2) {
      var r2 = t2.length, n2 = this.j._malloc(r2);
      this.j.HEAPU8.set(t2, n2), e2 ? this.j._changeBinaryGraph(r2, n2) : this.j._changeTextGraph(r2, n2), this.j._free(n2);
    }
    configureAudio(t2, e2, r2, n2, i2) {
      this.j._configureAudio || console.warn('Attempting to use configureAudio without support for input audio. Is build dep ":gl_graph_runner_audio" missing?'), Gh(this, n2 || "input_audio", (n3) => {
        Gh(this, i2 = i2 || "audio_header", (i3) => {
          this.j._configureAudio(n3, i3, t2, e2 ?? 0, r2);
        });
      });
    }
    setAutoResizeCanvas(t2) {
      this.l = t2;
    }
    setAutoRenderToScreen(t2) {
      this.j._setAutoRenderToScreen(t2);
    }
    setGpuBufferVerticalFlip(t2) {
      this.j.gpuOriginForWebTexturesIsBottomLeft = t2;
    }
    ka(t2) {
      Kh(this, "__graph_config__", (e2) => {
        t2(e2);
      }), Gh(this, "__graph_config__", (t3) => {
        this.j._getGraphConfig(t3, void 0);
      }), delete this.j.simpleListeners.__graph_config__;
    }
    attachErrorListener(t2) {
      this.j.errorListener = t2;
    }
    attachEmptyPacketListener(t2, e2) {
      this.j.emptyPacketListeners = this.j.emptyPacketListeners || {}, this.j.emptyPacketListeners[t2] = e2;
    }
    addAudioToStream(t2, e2, r2) {
      this.addAudioToStreamWithShape(t2, 0, 0, e2, r2);
    }
    addAudioToStreamWithShape(t2, e2, r2, n2, i2) {
      var s2 = 4 * t2.length;
      this.i !== s2 && (this.h && this.j._free(this.h), this.h = this.j._malloc(s2), this.i = s2), this.j.HEAPF32.set(t2, this.h / 4), Gh(this, n2, (t3) => {
        this.j._addAudioToInputStream(this.h, e2, r2, t3, i2);
      });
    }
    addGpuBufferToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var [n2, i2] = Vh(this, t2, e3);
        this.j._addBoundTextureToStream(e3, n2, i2, r2);
      });
    }
    addBoolToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        this.j._addBoolToInputStream(t2, e3, r2);
      });
    }
    addDoubleToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        this.j._addDoubleToInputStream(t2, e3, r2);
      });
    }
    addFloatToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        this.j._addFloatToInputStream(t2, e3, r2);
      });
    }
    addIntToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        this.j._addIntToInputStream(t2, e3, r2);
      });
    }
    addUintToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        this.j._addUintToInputStream(t2, e3, r2);
      });
    }
    addStringToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        Gh(this, t2, (t3) => {
          this.j._addStringToInputStream(t3, e3, r2);
        });
      });
    }
    addStringRecordToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        Hh(this, Object.keys(t2), (n2) => {
          Hh(this, Object.values(t2), (i2) => {
            this.j._addFlatHashMapToInputStream(n2, i2, Object.keys(t2).length, e3, r2);
          });
        });
      });
    }
    addProtoToStream(t2, e2, r2, n2) {
      Gh(this, r2, (r3) => {
        Gh(this, e2, (e3) => {
          var i2 = this.j._malloc(t2.length);
          this.j.HEAPU8.set(t2, i2), this.j._addProtoToInputStream(i2, t2.length, e3, r3, n2), this.j._free(i2);
        });
      });
    }
    addEmptyPacketToStream(t2, e2) {
      Gh(this, t2, (t3) => {
        this.j._addEmptyPacketToInputStream(t3, e2);
      });
    }
    addBoolVectorToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var n2 = this.j._allocateBoolVector(t2.length);
        if (!n2) throw Error("Unable to allocate new bool vector on heap.");
        for (let e4 of t2) this.j._addBoolVectorEntry(n2, e4);
        this.j._addBoolVectorToInputStream(n2, e3, r2);
      });
    }
    addDoubleVectorToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var n2 = this.j._allocateDoubleVector(t2.length);
        if (!n2) throw Error("Unable to allocate new double vector on heap.");
        for (let e4 of t2) this.j._addDoubleVectorEntry(n2, e4);
        this.j._addDoubleVectorToInputStream(n2, e3, r2);
      });
    }
    addFloatVectorToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var n2 = this.j._allocateFloatVector(t2.length);
        if (!n2) throw Error("Unable to allocate new float vector on heap.");
        for (let e4 of t2) this.j._addFloatVectorEntry(n2, e4);
        this.j._addFloatVectorToInputStream(n2, e3, r2);
      });
    }
    addIntVectorToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var n2 = this.j._allocateIntVector(t2.length);
        if (!n2) throw Error("Unable to allocate new int vector on heap.");
        for (let e4 of t2) this.j._addIntVectorEntry(n2, e4);
        this.j._addIntVectorToInputStream(n2, e3, r2);
      });
    }
    addUintVectorToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var n2 = this.j._allocateUintVector(t2.length);
        if (!n2) throw Error("Unable to allocate new unsigned int vector on heap.");
        for (let e4 of t2) this.j._addUintVectorEntry(n2, e4);
        this.j._addUintVectorToInputStream(n2, e3, r2);
      });
    }
    addStringVectorToStream(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var n2 = this.j._allocateStringVector(t2.length);
        if (!n2) throw Error("Unable to allocate new string vector on heap.");
        for (let e4 of t2) Gh(this, e4, (t3) => {
          this.j._addStringVectorEntry(n2, t3);
        });
        this.j._addStringVectorToInputStream(n2, e3, r2);
      });
    }
    addBoolToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        this.j._addBoolToInputSidePacket(t2, e3);
      });
    }
    addDoubleToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        this.j._addDoubleToInputSidePacket(t2, e3);
      });
    }
    addFloatToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        this.j._addFloatToInputSidePacket(t2, e3);
      });
    }
    addIntToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        this.j._addIntToInputSidePacket(t2, e3);
      });
    }
    addUintToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        this.j._addUintToInputSidePacket(t2, e3);
      });
    }
    addStringToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        Gh(this, t2, (t3) => {
          this.j._addStringToInputSidePacket(t3, e3);
        });
      });
    }
    addProtoToInputSidePacket(t2, e2, r2) {
      Gh(this, r2, (r3) => {
        Gh(this, e2, (e3) => {
          var n2 = this.j._malloc(t2.length);
          this.j.HEAPU8.set(t2, n2), this.j._addProtoToInputSidePacket(n2, t2.length, e3, r3), this.j._free(n2);
        });
      });
    }
    addBoolVectorToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        var r2 = this.j._allocateBoolVector(t2.length);
        if (!r2) throw Error("Unable to allocate new bool vector on heap.");
        for (let e4 of t2) this.j._addBoolVectorEntry(r2, e4);
        this.j._addBoolVectorToInputSidePacket(r2, e3);
      });
    }
    addDoubleVectorToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        var r2 = this.j._allocateDoubleVector(t2.length);
        if (!r2) throw Error("Unable to allocate new double vector on heap.");
        for (let e4 of t2) this.j._addDoubleVectorEntry(r2, e4);
        this.j._addDoubleVectorToInputSidePacket(r2, e3);
      });
    }
    addFloatVectorToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        var r2 = this.j._allocateFloatVector(t2.length);
        if (!r2) throw Error("Unable to allocate new float vector on heap.");
        for (let e4 of t2) this.j._addFloatVectorEntry(r2, e4);
        this.j._addFloatVectorToInputSidePacket(r2, e3);
      });
    }
    addIntVectorToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        var r2 = this.j._allocateIntVector(t2.length);
        if (!r2) throw Error("Unable to allocate new int vector on heap.");
        for (let e4 of t2) this.j._addIntVectorEntry(r2, e4);
        this.j._addIntVectorToInputSidePacket(r2, e3);
      });
    }
    addUintVectorToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        var r2 = this.j._allocateUintVector(t2.length);
        if (!r2) throw Error("Unable to allocate new unsigned int vector on heap.");
        for (let e4 of t2) this.j._addUintVectorEntry(r2, e4);
        this.j._addUintVectorToInputSidePacket(r2, e3);
      });
    }
    addStringVectorToInputSidePacket(t2, e2) {
      Gh(this, e2, (e3) => {
        var r2 = this.j._allocateStringVector(t2.length);
        if (!r2) throw Error("Unable to allocate new string vector on heap.");
        for (let e4 of t2) Gh(this, e4, (t3) => {
          this.j._addStringVectorEntry(r2, t3);
        });
        this.j._addStringVectorToInputSidePacket(r2, e3);
      });
    }
    attachBoolListener(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachBoolListener(t3);
      });
    }
    attachBoolVectorListener(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachBoolVectorListener(t3);
      });
    }
    attachIntListener(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachIntListener(t3);
      });
    }
    attachIntVectorListener(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachIntVectorListener(t3);
      });
    }
    attachUintListener(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachUintListener(t3);
      });
    }
    attachUintVectorListener(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachUintVectorListener(t3);
      });
    }
    attachDoubleListener(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachDoubleListener(t3);
      });
    }
    attachDoubleVectorListener(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachDoubleVectorListener(t3);
      });
    }
    attachFloatListener(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachFloatListener(t3);
      });
    }
    attachFloatVectorListener(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachFloatVectorListener(t3);
      });
    }
    attachStringListener(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachStringListener(t3);
      });
    }
    attachStringVectorListener(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachStringVectorListener(t3);
      });
    }
    attachProtoListener(t2, e2, r2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachProtoListener(t3, r2 || false);
      });
    }
    attachProtoVectorListener(t2, e2, r2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.j._attachProtoVectorListener(t3, r2 || false);
      });
    }
    attachAudioListener(t2, e2, r2) {
      this.j._attachAudioListener || console.warn('Attempting to use attachAudioListener without support for output audio. Is build dep ":gl_graph_runner_audio_out" missing?'), Kh(this, t2, (t3, r3) => {
        t3 = new Float32Array(t3.buffer, t3.byteOffset, t3.length / 4), e2(t3, r3);
      }), Gh(this, t2, (t3) => {
        this.j._attachAudioListener(t3, r2 || false);
      });
    }
    finishProcessing() {
      this.j._waitUntilIdle();
    }
    closeGraph() {
      this.j._closeGraph(), this.j.simpleListeners = void 0, this.j.emptyPacketListeners = void 0;
    }
  };
  function zh(t2) {
    return class extends t2 {
      get qa() {
        return this.j;
      }
      Ta() {
        if ("function" == typeof this.qa._mediapipeLoggerGetEncodedApiKey) {
          let t3 = this.qa._mediapipeLoggerGetEncodedApiKey();
          return this.qa._decodeBase64(t3);
        }
      }
    };
  }
  function Yh(t2) {
    return class extends t2 {
      ab() {
        this.j._registerModelResourcesGraphService();
      }
    };
  }
  var qh = zh(Yh(Wh));
  var Jh = class extends qh {
  };
  async function Zh(t2, e2, r2, n2) {
    return t2 = await (async (t3, e3, r3, n3, i2) => {
      if (e3 && await Bh(e3), !self.ModuleFactory) throw Error("ModuleFactory not set.");
      if (r3 && (await Bh(r3), !self.ModuleFactory)) throw Error("ModuleFactory not set.");
      return self.Module && i2 && ((e3 = self.Module).locateFile = i2.locateFile, i2.mainScriptUrlOrBlob && (e3.mainScriptUrlOrBlob = i2.mainScriptUrlOrBlob)), i2 = await self.ModuleFactory(self.Module || i2), self.ModuleFactory = self.Module = void 0, new t3(i2, n3);
    })(t2, r2.wasmLoaderPath, r2.assetLoaderPath, e2, { locateFile: (t3) => t3.endsWith(".wasm") ? r2.wasmBinaryPath.toString() : r2.assetBinaryPath && t3.endsWith(".data") ? r2.assetBinaryPath.toString() : t3 }), (function(t3, e3) {
      e3 = e3.runningMode ?? "";
      var r3 = t3.h.Ta();
      t3.o = new $h(t3.D(), e3, r3);
    })(t2, n2), await t2.A(n2), t2;
  }
  async function Qh(t2, e2, r2, n2) {
    return Zh(t2, e2, r2, n2);
  }
  function tu(t2, e2, r2) {
    try {
      t2.h.j.FS_unlink(`/${r2}`);
    } catch {
    }
    t2.h.j.FS_createDataFile("/", r2, e2, true, false, false), eu(t2, `/${r2}`);
  }
  function eu(t2, e2) {
    var r2 = kr(t2.baseOptions, Yo, 1) || new Yo();
    "string" == typeof e2 ? (ar(r2, 2, ve(e2)), ar(r2, 1)) : e2 instanceof Uint8Array && (ar(r2, 1, lt(e2, false)), ar(r2, 2)), Rr(t2.baseOptions, 0, 1, r2);
  }
  function ru(t2) {
    try {
      let e2 = t2.L.length;
      if (1 === e2) throw Error(t2.L[0].message);
      if (e2 > 1) throw Error("Encountered multiple errors: " + t2.L.map((t3) => t3.message).join(", "));
    } finally {
      t2.L = [];
    }
  }
  function nu(t2, e2) {
    t2.J = Math.max(t2.J, e2);
  }
  function iu(t2, e2) {
    t2.F = new co(), Vr(t2.F, 2, "PassThroughCalculator"), ho(t2.F, "free_memory"), uo(t2.F, "free_memory_unused_out"), go(e2, "free_memory"), mo(e2, t2.F);
  }
  function su(t2, e2) {
    ho(t2.F, e2), uo(t2.F, e2 + "_unused_out");
  }
  function ou(t2) {
    t2.h.addBoolToStream(true, "free_memory", t2.J);
  }
  var au = class {
    constructor(t2) {
      this.h = t2, this.L = [], this.J = 0, this.h.setAutoRenderToScreen(false);
    }
    l(t2, e2 = true, r2 = false, n2 = false) {
      if (e2) {
        let e3 = t2.baseOptions || {};
        if (t2.baseOptions?.modelAssetBuffer && t2.baseOptions?.modelAssetPath) throw Error("Cannot set both baseOptions.modelAssetPath and baseOptions.modelAssetBuffer");
        if (!(kr(this.baseOptions, Yo, 1)?.h() || kr(this.baseOptions, Yo, 1)?.l() || t2.baseOptions?.modelAssetBuffer || t2.baseOptions?.modelAssetPath)) throw Error("Either baseOptions.modelAssetPath or baseOptions.modelAssetBuffer must be set");
        !(function(t3, e4, r3 = false) {
          var n3 = kr(t3.baseOptions, Wo, 3);
          if (!n3) {
            var i3 = n3 = new Wo(), s2 = new eo();
            Ir(i3, 4, zo, s2);
          }
          "delegate" in e4 && ("GPU" === e4.delegate ? (e4 = n3, i3 = new zs(), Ir(e4, 2, zo, i3)) : (e4 = n3, i3 = new eo(), Ir(e4, 4, zo, i3))), r3 && (r3 = n3.l(), e4 = n3.h() || true === r3?.h(), r3 = new Zs(), e4 ? Rr(r3, 0, 9, e4 = new Js()) : Rr(r3, 0, 8, e4 = new qs()), Ir(n3, 6, zo, r3)), Rr(t3.baseOptions, 0, 3, n3);
        })(this, e3, n2);
        let i2 = r2 ? "model.litertlm" : "model.dat";
        if (e3.modelAssetPath) return fetch(e3.modelAssetPath.toString()).then((t3) => {
          if (t3.ok) return t3.arrayBuffer();
          throw Error(`Failed to fetch model: ${e3.modelAssetPath} (${t3.status})`);
        }).then((t3) => {
          tu(this, new Uint8Array(t3), i2), this.u(), this.M();
        });
        if (e3.modelAssetBuffer instanceof Uint8Array) r2 ? tu(this, e3.modelAssetBuffer, i2) : eu(this, e3.modelAssetBuffer);
        else if (e3.modelAssetBuffer) return (async function(t3) {
          for (var e4 = [], r3 = 0; ; ) {
            let { done: n3, value: i3 } = await t3.read();
            if (n3) break;
            e4.push(i3), r3 += i3.length;
          }
          if (0 === e4.length) return new Uint8Array(0);
          if (1 === e4.length) return e4[0];
          t3 = new Uint8Array(r3), r3 = 0;
          for (let n3 of e4) t3.set(n3, r3), r3 += n3.length;
          return t3;
        })(e3.modelAssetBuffer).then((t3) => {
          r2 ? tu(this, t3, i2) : eu(this, t3), this.u(), this.M();
        });
      }
      return this.u(), this.M(), Promise.resolve();
    }
    M() {
    }
    ka() {
      var t2;
      if (this.h.ka((e2) => {
        t2 = Eo(e2);
      }), !t2) throw Error("Failed to retrieve CalculatorGraphConfig");
      return t2;
    }
    setGraph(t2, e2) {
      this.h.attachErrorListener((t3, e3) => {
        this.L.push(Error(e3));
      }), this.h.ab(), this.h.setGraph(t2, e2), this.o?.za(), this.F = void 0, ru(this);
    }
    finishProcessing(t2) {
      this.h.finishProcessing(), ru(this), this.o && void 0 !== t2 && this.o.Aa(t2);
    }
    close() {
      this.F = void 0, this.o?.ya(), this.o?.close(), this.h.closeGraph();
    }
  };
  function hu(t2, e2) {
    if (!t2) throw Error(`Unable to obtain required WebGL resource: ${e2}`);
    return t2;
  }
  au.prototype.close = au.prototype.close;
  var uu = class {
    constructor(t2, e2, r2, n2) {
      this.h = t2, this.i = e2, this.o = r2, this.l = n2;
    }
    bind() {
      this.h.bindVertexArray(this.i);
    }
    close() {
      this.h.deleteVertexArray(this.i), this.h.deleteBuffer(this.o), this.h.deleteBuffer(this.l);
    }
  };
  function cu(t2, e2, r2) {
    var n2 = t2.h;
    if (r2 = hu(n2.createShader(r2), "Failed to create WebGL shader"), n2.shaderSource(r2, e2), n2.compileShader(r2), !n2.getShaderParameter(r2, n2.COMPILE_STATUS)) throw Error(`Could not compile WebGL shader: ${n2.getShaderInfoLog(r2)}`);
    return n2.attachShader(t2.i, r2), r2;
  }
  function lu(t2, e2) {
    var r2 = t2.h, n2 = hu(r2.createVertexArray(), "Failed to create vertex array");
    r2.bindVertexArray(n2);
    var i2 = hu(r2.createBuffer(), "Failed to create buffer");
    r2.bindBuffer(r2.ARRAY_BUFFER, i2), r2.enableVertexAttribArray(t2.G), r2.vertexAttribPointer(t2.G, 2, r2.FLOAT, false, 0, 0), r2.bufferData(r2.ARRAY_BUFFER, new Float32Array([-1, -1, -1, 1, 1, 1, 1, -1]), r2.STATIC_DRAW);
    var s2 = hu(r2.createBuffer(), "Failed to create buffer");
    return r2.bindBuffer(r2.ARRAY_BUFFER, s2), r2.enableVertexAttribArray(t2.L), r2.vertexAttribPointer(t2.L, 2, r2.FLOAT, false, 0, 0), r2.bufferData(r2.ARRAY_BUFFER, new Float32Array(e2 ? [0, 1, 0, 0, 1, 0, 1, 1] : [0, 0, 0, 1, 1, 1, 1, 0]), r2.STATIC_DRAW), r2.bindBuffer(r2.ARRAY_BUFFER, null), r2.bindVertexArray(null), new uu(r2, n2, i2, s2);
  }
  function du(t2, e2) {
    if (t2.h) {
      if (e2 !== t2.h) throw Error("Cannot change GL context once initialized");
    } else t2.h = e2;
  }
  function fu(t2, e2, r2, n2) {
    return du(t2, e2), t2.i || (t2.o(), t2.J()), r2 ? (t2.m || (t2.m = lu(t2, true)), r2 = t2.m) : (t2.F || (t2.F = lu(t2, false)), r2 = t2.F), e2.useProgram(t2.i), r2.bind(), t2.l(), t2 = n2(), r2.h.bindVertexArray(null), t2;
  }
  function pu(t2, e2, r2) {
    return du(t2, e2), t2 = hu(e2.createTexture(), "Failed to create texture"), e2.bindTexture(e2.TEXTURE_2D, t2), e2.texParameteri(e2.TEXTURE_2D, e2.TEXTURE_WRAP_S, e2.CLAMP_TO_EDGE), e2.texParameteri(e2.TEXTURE_2D, e2.TEXTURE_WRAP_T, e2.CLAMP_TO_EDGE), e2.texParameteri(e2.TEXTURE_2D, e2.TEXTURE_MIN_FILTER, r2 ?? e2.LINEAR), e2.texParameteri(e2.TEXTURE_2D, e2.TEXTURE_MAG_FILTER, r2 ?? e2.LINEAR), e2.bindTexture(e2.TEXTURE_2D, null), t2;
  }
  function mu(t2, e2, r2) {
    du(t2, e2), t2.D || (t2.D = hu(e2.createFramebuffer(), "Failed to create framebuffe.")), e2.bindFramebuffer(e2.FRAMEBUFFER, t2.D), e2.framebufferTexture2D(e2.FRAMEBUFFER, e2.COLOR_ATTACHMENT0, e2.TEXTURE_2D, r2, 0);
  }
  function gu(t2) {
    t2.h?.bindFramebuffer(t2.h.FRAMEBUFFER, null);
  }
  var vu = class {
    C() {
      return "\n  precision mediump float;\n  varying vec2 vTex;\n  uniform sampler2D inputTexture;\n  void main() {\n    gl_FragColor = texture2D(inputTexture, vTex);\n  }\n ";
    }
    o() {
      var t2 = this.h;
      if (this.i = hu(t2.createProgram(), "Failed to create WebGL program"), this.ea = cu(this, "\n  attribute vec2 aVertex;\n  attribute vec2 aTex;\n  varying vec2 vTex;\n  void main(void) {\n    gl_Position = vec4(aVertex, 0.0, 1.0);\n    vTex = aTex;\n  }", t2.VERTEX_SHADER), this.aa = cu(this, this.C(), t2.FRAGMENT_SHADER), t2.linkProgram(this.i), !t2.getProgramParameter(this.i, t2.LINK_STATUS)) throw Error(`Error during program linking: ${t2.getProgramInfoLog(this.i)}`);
      this.G = t2.getAttribLocation(this.i, "aVertex"), this.L = t2.getAttribLocation(this.i, "aTex");
    }
    J() {
    }
    l() {
    }
    close() {
      if (this.i) {
        let t2 = this.h;
        t2.deleteProgram(this.i), t2.deleteShader(this.ea), t2.deleteShader(this.aa);
      }
      this.D && this.h.deleteFramebuffer(this.D), this.F && this.F.close(), this.m && this.m.close();
    }
  };
  var _u = class extends vu {
    C() {
      return "\n  precision mediump float;\n  uniform sampler2D backgroundTexture;\n  uniform sampler2D maskTexture;\n  uniform sampler2D colorMappingTexture;\n  varying vec2 vTex;\n  void main() {\n    vec4 backgroundColor = texture2D(backgroundTexture, vTex);\n    float category = texture2D(maskTexture, vTex).r;\n    vec4 categoryColor = texture2D(colorMappingTexture, vec2(category, 0.0));\n    gl_FragColor = mix(backgroundColor, categoryColor, categoryColor.a);\n  }\n ";
    }
    J() {
      var t2 = this.h;
      t2.activeTexture(t2.TEXTURE1), this.v = pu(this, t2, t2.LINEAR), t2.activeTexture(t2.TEXTURE2), this.u = pu(this, t2, t2.NEAREST);
    }
    o() {
      super.o();
      var t2 = this.h;
      this.P = hu(t2.getUniformLocation(this.i, "backgroundTexture"), "Uniform location"), this.Z = hu(t2.getUniformLocation(this.i, "colorMappingTexture"), "Uniform location"), this.M = hu(t2.getUniformLocation(this.i, "maskTexture"), "Uniform location");
    }
    l() {
      super.l();
      var t2 = this.h;
      t2.uniform1i(this.M, 0), t2.uniform1i(this.P, 1), t2.uniform1i(this.Z, 2);
    }
    close() {
      this.v && this.h.deleteTexture(this.v), this.u && this.h.deleteTexture(this.u), super.close();
    }
  };
  var yu = class extends vu {
    C() {
      return "\n  precision mediump float;\n  uniform sampler2D maskTexture;\n  uniform sampler2D defaultTexture;\n  uniform sampler2D overlayTexture;\n  varying vec2 vTex;\n  void main() {\n    float confidence = texture2D(maskTexture, vTex).r;\n    vec4 defaultColor = texture2D(defaultTexture, vTex);\n    vec4 overlayColor = texture2D(overlayTexture, vTex);\n    // Apply the alpha from the overlay and merge in the default color\n    overlayColor = mix(defaultColor, overlayColor, overlayColor.a);\n    gl_FragColor = mix(defaultColor, overlayColor, confidence);\n  }\n ";
    }
    J() {
      var t2 = this.h;
      t2.activeTexture(t2.TEXTURE1), this.u = pu(this, t2), t2.activeTexture(t2.TEXTURE2), this.v = pu(this, t2);
    }
    o() {
      super.o();
      var t2 = this.h;
      this.M = hu(t2.getUniformLocation(this.i, "defaultTexture"), "Uniform location"), this.P = hu(t2.getUniformLocation(this.i, "overlayTexture"), "Uniform location"), this.K = hu(t2.getUniformLocation(this.i, "maskTexture"), "Uniform location");
    }
    l() {
      super.l();
      var t2 = this.h;
      t2.uniform1i(this.K, 0), t2.uniform1i(this.M, 1), t2.uniform1i(this.P, 2);
    }
    close() {
      this.u && this.h.deleteTexture(this.u), this.v && this.h.deleteTexture(this.v), super.close();
    }
  };
  function Eu(t2, e2) {
    switch (e2) {
      case 0:
        return t2.h.find((t3) => t3 instanceof Uint8Array);
      case 1:
        return t2.h.find((t3) => t3 instanceof Float32Array);
      case 2:
        return t2.h.find((t3) => "undefined" != typeof WebGLTexture && t3 instanceof WebGLTexture);
      default:
        throw Error(`Type is not supported: ${e2}`);
    }
  }
  function Au(t2) {
    var e2 = Eu(t2, 1);
    if (!e2) {
      if (e2 = Eu(t2, 0)) e2 = new Float32Array(e2).map((t3) => t3 / 255);
      else {
        e2 = new Float32Array(t2.width * t2.height);
        let n2 = Tu(t2);
        var r2 = ku(t2);
        if (mu(r2, n2, wu(t2)), "iPad Simulator;iPhone Simulator;iPod Simulator;iPad;iPhone;iPod".split(";").includes(navigator.platform) || navigator.userAgent.includes("Mac") && "document" in self && "ontouchend" in self.document) {
          r2 = new Float32Array(t2.width * t2.height * 4), n2.readPixels(0, 0, t2.width, t2.height, n2.RGBA, n2.FLOAT, r2);
          for (let t3 = 0, n3 = 0; t3 < e2.length; ++t3, n3 += 4) e2[t3] = r2[n3];
        } else n2.readPixels(0, 0, t2.width, t2.height, n2.RED, n2.FLOAT, e2);
      }
      t2.h.push(e2);
    }
    return e2;
  }
  function wu(t2) {
    var e2 = Eu(t2, 2);
    if (!e2) {
      let r2 = Tu(t2);
      e2 = Su(t2);
      let n2 = Au(t2), i2 = bu(t2);
      r2.texImage2D(r2.TEXTURE_2D, 0, i2, t2.width, t2.height, 0, r2.RED, r2.FLOAT, n2), Lu(t2);
    }
    return e2;
  }
  function Tu(t2) {
    if (!t2.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
    return t2.i || (t2.i = hu(t2.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context.")), t2.i;
  }
  function bu(t2) {
    if (t2 = Tu(t2), !xu) if (t2.getExtension("EXT_color_buffer_float") && t2.getExtension("OES_texture_float_linear") && t2.getExtension("EXT_float_blend")) xu = t2.R32F;
    else {
      if (!t2.getExtension("EXT_color_buffer_half_float")) throw Error("GPU does not fully support 4-channel float32 or float16 formats");
      xu = t2.R16F;
    }
    return xu;
  }
  function ku(t2) {
    return t2.l || (t2.l = new vu()), t2.l;
  }
  function Su(t2) {
    var e2 = Tu(t2);
    e2.viewport(0, 0, t2.width, t2.height), e2.activeTexture(e2.TEXTURE0);
    var r2 = Eu(t2, 2);
    return r2 || (r2 = pu(ku(t2), e2, t2.o ? e2.LINEAR : e2.NEAREST), t2.h.push(r2), t2.u = true), e2.bindTexture(e2.TEXTURE_2D, r2), r2;
  }
  function Lu(t2) {
    t2.i.bindTexture(t2.i.TEXTURE_2D, null);
  }
  var xu;
  var Ru = class {
    constructor(t2, e2, r2, n2, i2, s2, o2) {
      this.h = t2, this.o = e2, this.u = r2, this.canvas = n2, this.l = i2, this.width = s2, this.height = o2, this.u && (0 === --Iu && console.error("You seem to be creating MPMask instances without invoking .close(). This leaks resources."));
    }
    Va() {
      return !!Eu(this, 0);
    }
    va() {
      return !!Eu(this, 1);
    }
    X() {
      return !!Eu(this, 2);
    }
    ua() {
      return (e2 = Eu(t2 = this, 0)) || (e2 = Au(t2), e2 = new Uint8Array(e2.map((t3) => Math.round(255 * t3))), t2.h.push(e2)), e2;
      var t2, e2;
    }
    ta() {
      return Au(this);
    }
    T() {
      return wu(this);
    }
    clone() {
      var t2 = [];
      for (let e2 of this.h) {
        let r2;
        if (e2 instanceof Uint8Array) r2 = new Uint8Array(e2);
        else if (e2 instanceof Float32Array) r2 = new Float32Array(e2);
        else {
          if (!(e2 instanceof WebGLTexture)) throw Error(`Type is not supported: ${e2}`);
          {
            let t3 = Tu(this), e3 = ku(this);
            t3.activeTexture(t3.TEXTURE1), r2 = pu(e3, t3, this.o ? t3.LINEAR : t3.NEAREST), t3.bindTexture(t3.TEXTURE_2D, r2);
            let n2 = bu(this);
            t3.texImage2D(t3.TEXTURE_2D, 0, n2, this.width, this.height, 0, t3.RED, t3.FLOAT, null), t3.bindTexture(t3.TEXTURE_2D, null), mu(e3, t3, r2), fu(e3, t3, false, () => {
              Su(this), t3.clearColor(0, 0, 0, 0), t3.clear(t3.COLOR_BUFFER_BIT), t3.drawArrays(t3.TRIANGLE_FAN, 0, 4), Lu(this);
            }), gu(e3), Lu(this);
          }
        }
        t2.push(r2);
      }
      return new Ru(t2, this.o, this.X(), this.canvas, this.l, this.width, this.height);
    }
    close() {
      this.u && Tu(this).deleteTexture(Eu(this, 2)), Iu = -1;
    }
  };
  Ru.prototype.close = Ru.prototype.close, Ru.prototype.clone = Ru.prototype.clone, Ru.prototype.getAsWebGLTexture = Ru.prototype.T, Ru.prototype.getAsFloat32Array = Ru.prototype.ta, Ru.prototype.getAsUint8Array = Ru.prototype.ua, Ru.prototype.hasWebGLTexture = Ru.prototype.X, Ru.prototype.hasFloat32Array = Ru.prototype.va, Ru.prototype.hasUint8Array = Ru.prototype.Va;
  var Iu = 250;
  var Fu = { color: "white", lineWidth: 4, radius: 6 };
  function Cu(t2) {
    return { ...Fu, fillColor: (t2 = t2 || {}).color, ...t2 };
  }
  function Nu(t2, e2) {
    return t2 instanceof Function ? t2(e2) : t2;
  }
  function Mu(t2, e2, r2) {
    return Math.max(Math.min(e2, r2), Math.min(Math.max(e2, r2), t2));
  }
  function Ou(t2) {
    if (!t2.l) throw Error("CPU rendering requested but CanvasRenderingContext2D not provided.");
    return t2.l;
  }
  function Du(t2) {
    if (!t2.u) throw Error("GPU rendering requested but WebGL2RenderingContext not provided.");
    return t2.u;
  }
  function Pu(t2, e2, r2) {
    if (e2.X()) r2(e2.T());
    else {
      let n2 = e2.va() ? e2.ta() : e2.ua();
      t2.o = t2.o ?? new vu();
      let i2 = Du(t2);
      r2((t2 = new Ru([n2], e2.o, false, i2.canvas, t2.o, e2.width, e2.height)).T()), t2.close();
    }
  }
  function $u(t2, e2, r2, n2) {
    var i2 = (function(t3) {
      return t3.h || (t3.h = new _u()), t3.h;
    })(t2), s2 = Du(t2), o2 = Array.isArray(r2) ? new ImageData(new Uint8ClampedArray(r2), 1, 1) : r2;
    fu(i2, s2, true, () => {
      !(function(t4, e3, r3, n3) {
        var i3 = t4.h;
        if (i3.activeTexture(i3.TEXTURE0), i3.bindTexture(i3.TEXTURE_2D, e3), i3.activeTexture(i3.TEXTURE1), i3.bindTexture(i3.TEXTURE_2D, t4.v), i3.texImage2D(i3.TEXTURE_2D, 0, i3.RGBA, i3.RGBA, i3.UNSIGNED_BYTE, r3), t4.K && (function(t5, e4) {
          if (t5 !== e4) return false;
          t5 = t5.entries(), e4 = e4.entries();
          for (let [r4, n4] of t5) {
            t5 = r4;
            let i4 = n4, s3 = e4.next();
            if (s3.done) return false;
            let [o3, a2] = s3.value;
            if (t5 !== o3 || i4[0] !== a2[0] || i4[1] !== a2[1] || i4[2] !== a2[2] || i4[3] !== a2[3]) return false;
          }
          return !!e4.next().done;
        })(t4.K, n3)) i3.activeTexture(i3.TEXTURE2), i3.bindTexture(i3.TEXTURE_2D, t4.u);
        else {
          t4.K = n3;
          let e4 = Array(1024).fill(0);
          n3.forEach((t5, r4) => {
            if (4 !== t5.length) throw Error(`Color at index ${r4} is not a four-channel value.`);
            e4[4 * r4] = t5[0], e4[4 * r4 + 1] = t5[1], e4[4 * r4 + 2] = t5[2], e4[4 * r4 + 3] = t5[3];
          }), i3.activeTexture(i3.TEXTURE2), i3.bindTexture(i3.TEXTURE_2D, t4.u), i3.texImage2D(i3.TEXTURE_2D, 0, i3.RGBA, 256, 1, 0, i3.RGBA, i3.UNSIGNED_BYTE, new Uint8Array(e4));
        }
      })(i2, e2, o2, n2), s2.clearColor(0, 0, 0, 0), s2.clear(s2.COLOR_BUFFER_BIT), s2.drawArrays(s2.TRIANGLE_FAN, 0, 4);
      var t3 = i2.h;
      t3.activeTexture(t3.TEXTURE0), t3.bindTexture(t3.TEXTURE_2D, null), t3.activeTexture(t3.TEXTURE1), t3.bindTexture(t3.TEXTURE_2D, null), t3.activeTexture(t3.TEXTURE2), t3.bindTexture(t3.TEXTURE_2D, null);
    });
  }
  function Uu(t2, e2, r2, n2) {
    var i2 = Du(t2), s2 = (function(t3) {
      return t3.i || (t3.i = new yu()), t3.i;
    })(t2), o2 = Array.isArray(r2) ? new ImageData(new Uint8ClampedArray(r2), 1, 1) : r2, a2 = Array.isArray(n2) ? new ImageData(new Uint8ClampedArray(n2), 1, 1) : n2;
    fu(s2, i2, true, () => {
      var t3 = s2.h;
      t3.activeTexture(t3.TEXTURE0), t3.bindTexture(t3.TEXTURE_2D, e2), t3.activeTexture(t3.TEXTURE1), t3.bindTexture(t3.TEXTURE_2D, s2.u), t3.texImage2D(t3.TEXTURE_2D, 0, t3.RGBA, t3.RGBA, t3.UNSIGNED_BYTE, o2), t3.activeTexture(t3.TEXTURE2), t3.bindTexture(t3.TEXTURE_2D, s2.v), t3.texImage2D(t3.TEXTURE_2D, 0, t3.RGBA, t3.RGBA, t3.UNSIGNED_BYTE, a2), i2.clearColor(0, 0, 0, 0), i2.clear(i2.COLOR_BUFFER_BIT), i2.drawArrays(i2.TRIANGLE_FAN, 0, 4), i2.bindTexture(i2.TEXTURE_2D, null), (t3 = s2.h).activeTexture(t3.TEXTURE0), t3.bindTexture(t3.TEXTURE_2D, null), t3.activeTexture(t3.TEXTURE1), t3.bindTexture(t3.TEXTURE_2D, null), t3.activeTexture(t3.TEXTURE2), t3.bindTexture(t3.TEXTURE_2D, null);
    });
  }
  var Bu = class {
    constructor(t2, e2) {
      "undefined" != typeof CanvasRenderingContext2D && t2 instanceof CanvasRenderingContext2D || t2 instanceof OffscreenCanvasRenderingContext2D ? (this.l = t2, this.u = e2) : this.u = t2;
    }
    Na(t2, e2) {
      if (t2) {
        var r2 = Ou(this);
        e2 = Cu(e2), r2.save();
        var n2 = r2.canvas, i2 = 0;
        for (let s2 of t2) r2.fillStyle = Nu(e2.fillColor, { index: i2, from: s2 }), r2.strokeStyle = Nu(e2.color, { index: i2, from: s2 }), r2.lineWidth = Nu(e2.lineWidth, { index: i2, from: s2 }), (t2 = new Path2D()).arc(s2.x * n2.width, s2.y * n2.height, Nu(e2.radius, { index: i2, from: s2 }), 0, 2 * Math.PI), r2.fill(t2), r2.stroke(t2), ++i2;
        r2.restore();
      }
    }
    Ma(t2, e2, r2) {
      if (t2 && e2) {
        var n2 = Ou(this);
        r2 = Cu(r2), n2.save();
        var i2 = n2.canvas, s2 = 0;
        for (let o2 of e2) {
          n2.beginPath(), e2 = t2[o2.start];
          let a2 = t2[o2.end];
          e2 && a2 && (n2.strokeStyle = Nu(r2.color, { index: s2, from: e2, to: a2 }), n2.lineWidth = Nu(r2.lineWidth, { index: s2, from: e2, to: a2 }), n2.moveTo(e2.x * i2.width, e2.y * i2.height), n2.lineTo(a2.x * i2.width, a2.y * i2.height)), ++s2, n2.stroke();
        }
        n2.restore();
      }
    }
    Ja(t2, e2) {
      var r2 = Ou(this);
      e2 = Cu(e2), r2.save(), r2.beginPath(), r2.lineWidth = Nu(e2.lineWidth, {}), r2.strokeStyle = Nu(e2.color, {}), r2.fillStyle = Nu(e2.fillColor, {}), r2.moveTo(t2.originX, t2.originY), r2.lineTo(t2.originX + t2.width, t2.originY), r2.lineTo(t2.originX + t2.width, t2.originY + t2.height), r2.lineTo(t2.originX, t2.originY + t2.height), r2.lineTo(t2.originX, t2.originY), r2.stroke(), r2.fill(), r2.restore();
    }
    Ka(t2, e2, r2 = [0, 0, 0, 255]) {
      this.l ? (function(t3, e3, r3, n2) {
        var i2 = Du(t3);
        Pu(t3, e3, (e4) => {
          $u(t3, e4, r3, n2), (e4 = Ou(t3)).drawImage(i2.canvas, 0, 0, e4.canvas.width, e4.canvas.height);
        });
      })(this, t2, r2, e2) : $u(this, t2.T(), r2, e2);
    }
    La(t2, e2, r2) {
      this.l ? (function(t3, e3, r3, n2) {
        var i2 = Du(t3);
        Pu(t3, e3, (e4) => {
          Uu(t3, e4, r3, n2), (e4 = Ou(t3)).drawImage(i2.canvas, 0, 0, e4.canvas.width, e4.canvas.height);
        });
      })(this, t2, e2, r2) : Uu(this, t2.T(), e2, r2);
    }
    close() {
      this.h?.close(), this.h = void 0, this.i?.close(), this.i = void 0, this.o?.close(), this.o = void 0;
    }
  };
  function ju(t2, e2) {
    switch (e2) {
      case 0:
        return t2.h.find((t3) => t3 instanceof ImageData);
      case 1:
        return t2.h.find((t3) => "undefined" != typeof ImageBitmap && t3 instanceof ImageBitmap);
      case 2:
        return t2.h.find((t3) => "undefined" != typeof WebGLTexture && t3 instanceof WebGLTexture);
      default:
        throw Error(`Type is not supported: ${e2}`);
    }
  }
  function Gu(t2) {
    var e2 = ju(t2, 0);
    if (!e2) {
      e2 = Hu(t2);
      let r2 = Ku(t2), n2 = new Uint8Array(t2.width * t2.height * 4);
      mu(r2, e2, Vu(t2)), e2.readPixels(0, 0, t2.width, t2.height, e2.RGBA, e2.UNSIGNED_BYTE, n2), gu(r2), e2 = new ImageData(new Uint8ClampedArray(n2.buffer), t2.width, t2.height), t2.h.push(e2);
    }
    return e2;
  }
  function Vu(t2) {
    var e2 = ju(t2, 2);
    if (!e2) {
      let r2 = Hu(t2);
      e2 = Xu(t2);
      let n2 = ju(t2, 1) || Gu(t2);
      r2.texImage2D(r2.TEXTURE_2D, 0, r2.RGBA, r2.RGBA, r2.UNSIGNED_BYTE, n2), Wu(t2);
    }
    return e2;
  }
  function Hu(t2) {
    if (!t2.canvas) throw Error("Conversion to different image formats require that a canvas is passed when initializing the image.");
    return t2.i || (t2.i = hu(t2.canvas.getContext("webgl2"), "You cannot use a canvas that is already bound to a different type of rendering context.")), t2.i;
  }
  function Ku(t2) {
    return t2.l || (t2.l = new vu()), t2.l;
  }
  function Xu(t2) {
    var e2 = Hu(t2);
    e2.viewport(0, 0, t2.width, t2.height), e2.activeTexture(e2.TEXTURE0);
    var r2 = ju(t2, 2);
    return r2 || (r2 = pu(Ku(t2), e2), t2.h.push(r2), t2.o = true), e2.bindTexture(e2.TEXTURE_2D, r2), r2;
  }
  function Wu(t2) {
    t2.i.bindTexture(t2.i.TEXTURE_2D, null);
  }
  function zu(t2) {
    var e2 = Hu(t2);
    return fu(Ku(t2), e2, true, () => (function(t3, e3) {
      var r2 = t3.canvas;
      if (r2.width === t3.width && r2.height === t3.height) return e3();
      var n2 = r2.width, i2 = r2.height;
      return r2.width = t3.width, r2.height = t3.height, t3 = e3(), r2.width = n2, r2.height = i2, t3;
    })(t2, () => {
      if (e2.bindFramebuffer(e2.FRAMEBUFFER, null), e2.clearColor(0, 0, 0, 0), e2.clear(e2.COLOR_BUFFER_BIT), e2.drawArrays(e2.TRIANGLE_FAN, 0, 4), !(t2.canvas instanceof OffscreenCanvas)) throw Error("Conversion to ImageBitmap requires that the MediaPipe Tasks is initialized with an OffscreenCanvas");
      return t2.canvas.transferToImageBitmap();
    }));
  }
  Bu.prototype.close = Bu.prototype.close, Bu.prototype.drawConfidenceMask = Bu.prototype.La, Bu.prototype.drawCategoryMask = Bu.prototype.Ka, Bu.prototype.drawBoundingBox = Bu.prototype.Ja, Bu.prototype.drawConnectors = Bu.prototype.Ma, Bu.prototype.drawLandmarks = Bu.prototype.Na, Bu.lerp = function(t2, e2, r2, n2, i2) {
    return Mu(n2 * (1 - (t2 - e2) / (r2 - e2)) + i2 * (1 - (r2 - t2) / (r2 - e2)), n2, i2);
  }, Bu.clamp = Mu;
  var Yu = class {
    constructor(t2, e2, r2, n2, i2, s2, o2) {
      this.h = t2, this.u = e2, this.o = r2, this.canvas = n2, this.l = i2, this.width = s2, this.height = o2, (this.u || this.o) && (0 === --qu && console.error("You seem to be creating MPImage instances without invoking .close(). This leaks resources."));
    }
    Ua() {
      return !!ju(this, 0);
    }
    wa() {
      return !!ju(this, 1);
    }
    X() {
      return !!ju(this, 2);
    }
    Ra() {
      return Gu(this);
    }
    Qa() {
      var t2 = ju(this, 1);
      return t2 || (Vu(this), Xu(this), t2 = zu(this), Wu(this), this.h.push(t2), this.u = true), t2;
    }
    T() {
      return Vu(this);
    }
    clone() {
      var t2 = [];
      for (let e2 of this.h) {
        let r2;
        if (e2 instanceof ImageData) r2 = new ImageData(e2.data, this.width, this.height);
        else if (e2 instanceof WebGLTexture) {
          let t3 = Hu(this), e3 = Ku(this);
          t3.activeTexture(t3.TEXTURE1), r2 = pu(e3, t3), t3.bindTexture(t3.TEXTURE_2D, r2), t3.texImage2D(t3.TEXTURE_2D, 0, t3.RGBA, this.width, this.height, 0, t3.RGBA, t3.UNSIGNED_BYTE, null), t3.bindTexture(t3.TEXTURE_2D, null), mu(e3, t3, r2), fu(e3, t3, false, () => {
            Xu(this), t3.clearColor(0, 0, 0, 0), t3.clear(t3.COLOR_BUFFER_BIT), t3.drawArrays(t3.TRIANGLE_FAN, 0, 4), Wu(this);
          }), gu(e3), Wu(this);
        } else {
          if (!(e2 instanceof ImageBitmap)) throw Error(`Type is not supported: ${e2}`);
          Vu(this), Xu(this), r2 = zu(this), Wu(this);
        }
        t2.push(r2);
      }
      return new Yu(t2, this.wa(), this.X(), this.canvas, this.l, this.width, this.height);
    }
    close() {
      this.u && ju(this, 1).close(), this.o && Hu(this).deleteTexture(ju(this, 2)), qu = -1;
    }
  };
  Yu.prototype.close = Yu.prototype.close, Yu.prototype.clone = Yu.prototype.clone, Yu.prototype.getAsWebGLTexture = Yu.prototype.T, Yu.prototype.getAsImageBitmap = Yu.prototype.Qa, Yu.prototype.getAsImageData = Yu.prototype.Ra, Yu.prototype.hasWebGLTexture = Yu.prototype.X, Yu.prototype.hasImageBitmap = Yu.prototype.wa, Yu.prototype.hasImageData = Yu.prototype.Ua;
  var qu = 250;
  function Ju(...t2) {
    return t2.map(([t3, e2]) => ({ start: t3, end: e2 }));
  }
  var Zu;
  var Qu = Yh((Zu = zh(Wh), class extends Zu {
    get pa() {
      return this.j;
    }
    Ea(t2, e2, r2) {
      Gh(this, e2, (e3) => {
        var [n2, i2] = Vh(this, t2, e3);
        this.pa._addBoundTextureAsImageToStream(e3, n2, i2, r2);
      });
    }
    ha(t2, e2) {
      Kh(this, t2, e2), Gh(this, t2, (t3) => {
        this.pa._attachImageListener(t3);
      });
    }
    ia(t2, e2) {
      Xh(this, t2, e2), Gh(this, t2, (t3) => {
        this.pa._attachImageVectorListener(t3);
      });
    }
  }));
  var tc = class extends Qu {
  };
  async function ec(t2, e2, r2) {
    return Qh(t2, r2.canvas ?? (Uh() ? void 0 : document.createElement("canvas")), e2, r2);
  }
  function rc(t2, e2, r2, n2) {
    if (t2.o && void 0 !== n2) {
      var i2 = kr(t2.baseOptions, Wo, 3);
      i2?.h() || i2?.l()?.h() ? (++(i2 = t2.o).h.U, i2.i.set(n2, performance.now())) : (++(i2 = t2.o).h.R, i2.i.set(n2, performance.now()));
    }
    if (t2.ra) {
      if (i2 = new Oo(), r2?.regionOfInterest) {
        if (!t2.Da) throw Error("This task doesn't support region-of-interest.");
        var s2 = r2.regionOfInterest;
        if (s2.left >= s2.right || s2.top >= s2.bottom) throw Error("Expected RectF with left < right and top < bottom.");
        if (s2.left < 0 || s2.top < 0 || s2.right > 1 || s2.bottom > 1) throw Error("Expected RectF values to be in [0,1].");
        jr(i2, 1, (s2.left + s2.right) / 2), jr(i2, 2, (s2.top + s2.bottom) / 2), jr(i2, 4, s2.right - s2.left), jr(i2, 3, s2.bottom - s2.top);
      } else jr(i2, 1, 0.5), jr(i2, 2, 0.5), jr(i2, 4, 1), jr(i2, 3, 1);
      if (r2?.rotationDegrees) {
        if (r2?.rotationDegrees % 90 != 0) throw Error("Expected rotation to be a multiple of 90\xB0.");
        if (jr(i2, 5, -Math.PI * r2.rotationDegrees / 180), r2?.rotationDegrees % 180 != 0) {
          let [t3, n3] = jh(e2);
          r2 = Or(i2, 3) * n3 / t3, s2 = Or(i2, 4) * t3 / n3, jr(i2, 4, r2), jr(i2, 3, s2);
        }
      }
      t2.h.addProtoToStream(i2.h(), "mediapipe.NormalizedRect", t2.ra, n2);
    }
    t2.h.Ea(e2, t2.Ca, n2 ?? performance.now()), t2.finishProcessing(n2);
  }
  function nc(t2, e2, r2) {
    if (t2.K) throw Error("Task is not initialized with image mode. 'runningMode' must be set to 'IMAGE'.");
    rc(t2, e2, r2, t2.J + 1);
  }
  function ic(t2, e2, r2, n2) {
    if (!t2.K) throw Error("Task is not initialized with video mode. 'runningMode' must be set to 'VIDEO'.");
    rc(t2, e2, r2, n2);
  }
  function sc(t2, e2, r2, n2) {
    var i2 = e2.data, s2 = e2.width, o2 = s2 * (e2 = e2.height);
    if ((i2 instanceof Uint8Array || i2 instanceof Float32Array) && i2.length !== o2) throw Error("Unsupported channel count: " + i2.length / o2);
    return t2 = new Ru([i2], r2, false, t2.h.j.canvas, t2.ea, s2, e2), n2 ? t2.clone() : t2;
  }
  var oc = class extends au {
    constructor(t2, e2, r2, n2) {
      super(t2), this.h = t2, this.Ca = e2, this.ra = r2, this.Da = n2, this.ea = new vu(), this.K = false;
    }
    l(t2, e2 = true, r2 = false, n2 = false) {
      if ("runningMode" in t2) {
        var i2 = this.K = !!t2.runningMode && "IMAGE" !== t2.runningMode;
        ar(this.baseOptions, 2, null == i2 ? i2 : Zt(i2));
      }
      if (void 0 !== t2.canvas && this.h.j.canvas !== t2.canvas) throw Error("You must create a new task to reset the canvas.");
      return super.l(t2, e2, r2, n2);
    }
    close() {
      this.ea.close(), super.close();
    }
  };
  oc.prototype.close = oc.prototype.close;
  var ac = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect_in", false), this.m = { detections: [] }, Rr(t2 = this.i = new ta(), 0, 1, e2 = new qo()), jr(this.i, 2, 0.5), jr(this.i, 3, 0.3);
    }
    D() {
      return "FaceDetector";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return "minDetectionConfidence" in t2 && jr(this.i, 2, t2.minDetectionConfidence ?? 0.5), "minSuppressionThreshold" in t2 && jr(this.i, 3, t2.minSuppressionThreshold ?? 0.3), this.l(t2);
    }
    H(t2, e2) {
      return this.m = { detections: [] }, nc(this, t2, e2), this.m;
    }
    I(t2, e2, r2) {
      return this.m = { detections: [] }, ic(this, t2, r2, e2), this.m;
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect_in"), vo(t2, "detections");
      var e2 = new so();
      ci(e2, ra, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.face_detector.FaceDetectorGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect_in"), uo(r2, "DETECTIONS:detections"), r2.A(e2), mo(t2, r2), this.h.attachProtoVectorListener("detections", (t3, e3) => {
        for (let e4 of t3) t3 = xo(e4), this.m.detections.push(th(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("detections", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  ac.prototype.detectForVideo = ac.prototype.I, ac.prototype.detect = ac.prototype.H, ac.prototype.setOptions = ac.prototype.A, ac.createFromModelPath = async function(t2, e2) {
    return ec(ac, t2, { baseOptions: { modelAssetPath: e2 } });
  }, ac.createFromModelBuffer = function(t2, e2) {
    return ec(ac, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, ac.createFromOptions = function(t2, e2) {
    return ec(ac, t2, e2);
  };
  var hc = Ju([61, 146], [146, 91], [91, 181], [181, 84], [84, 17], [17, 314], [314, 405], [405, 321], [321, 375], [375, 291], [61, 185], [185, 40], [40, 39], [39, 37], [37, 0], [0, 267], [267, 269], [269, 270], [270, 409], [409, 291], [78, 95], [95, 88], [88, 178], [178, 87], [87, 14], [14, 317], [317, 402], [402, 318], [318, 324], [324, 308], [78, 191], [191, 80], [80, 81], [81, 82], [82, 13], [13, 312], [312, 311], [311, 310], [310, 415], [415, 308]);
  var uc = Ju([263, 249], [249, 390], [390, 373], [373, 374], [374, 380], [380, 381], [381, 382], [382, 362], [263, 466], [466, 388], [388, 387], [387, 386], [386, 385], [385, 384], [384, 398], [398, 362]);
  var cc = Ju([276, 283], [283, 282], [282, 295], [295, 285], [300, 293], [293, 334], [334, 296], [296, 336]);
  var lc = Ju([474, 475], [475, 476], [476, 477], [477, 474]);
  var dc = Ju([33, 7], [7, 163], [163, 144], [144, 145], [145, 153], [153, 154], [154, 155], [155, 133], [33, 246], [246, 161], [161, 160], [160, 159], [159, 158], [158, 157], [157, 173], [173, 133]);
  var fc = Ju([46, 53], [53, 52], [52, 65], [65, 55], [70, 63], [63, 105], [105, 66], [66, 107]);
  var pc = Ju([469, 470], [470, 471], [471, 472], [472, 469]);
  var mc = Ju([10, 338], [338, 297], [297, 332], [332, 284], [284, 251], [251, 389], [389, 356], [356, 454], [454, 323], [323, 361], [361, 288], [288, 397], [397, 365], [365, 379], [379, 378], [378, 400], [400, 377], [377, 152], [152, 148], [148, 176], [176, 149], [149, 150], [150, 136], [136, 172], [172, 58], [58, 132], [132, 93], [93, 234], [234, 127], [127, 162], [162, 21], [21, 54], [54, 103], [103, 67], [67, 109], [109, 10]);
  var gc = [...hc, ...uc, ...cc, ...dc, ...fc, ...mc];
  var vc = Ju([127, 34], [34, 139], [139, 127], [11, 0], [0, 37], [37, 11], [232, 231], [231, 120], [120, 232], [72, 37], [37, 39], [39, 72], [128, 121], [121, 47], [47, 128], [232, 121], [121, 128], [128, 232], [104, 69], [69, 67], [67, 104], [175, 171], [171, 148], [148, 175], [118, 50], [50, 101], [101, 118], [73, 39], [39, 40], [40, 73], [9, 151], [151, 108], [108, 9], [48, 115], [115, 131], [131, 48], [194, 204], [204, 211], [211, 194], [74, 40], [40, 185], [185, 74], [80, 42], [42, 183], [183, 80], [40, 92], [92, 186], [186, 40], [230, 229], [229, 118], [118, 230], [202, 212], [212, 214], [214, 202], [83, 18], [18, 17], [17, 83], [76, 61], [61, 146], [146, 76], [160, 29], [29, 30], [30, 160], [56, 157], [157, 173], [173, 56], [106, 204], [204, 194], [194, 106], [135, 214], [214, 192], [192, 135], [203, 165], [165, 98], [98, 203], [21, 71], [71, 68], [68, 21], [51, 45], [45, 4], [4, 51], [144, 24], [24, 23], [23, 144], [77, 146], [146, 91], [91, 77], [205, 50], [50, 187], [187, 205], [201, 200], [200, 18], [18, 201], [91, 106], [106, 182], [182, 91], [90, 91], [91, 181], [181, 90], [85, 84], [84, 17], [17, 85], [206, 203], [203, 36], [36, 206], [148, 171], [171, 140], [140, 148], [92, 40], [40, 39], [39, 92], [193, 189], [189, 244], [244, 193], [159, 158], [158, 28], [28, 159], [247, 246], [246, 161], [161, 247], [236, 3], [3, 196], [196, 236], [54, 68], [68, 104], [104, 54], [193, 168], [168, 8], [8, 193], [117, 228], [228, 31], [31, 117], [189, 193], [193, 55], [55, 189], [98, 97], [97, 99], [99, 98], [126, 47], [47, 100], [100, 126], [166, 79], [79, 218], [218, 166], [155, 154], [154, 26], [26, 155], [209, 49], [49, 131], [131, 209], [135, 136], [136, 150], [150, 135], [47, 126], [126, 217], [217, 47], [223, 52], [52, 53], [53, 223], [45, 51], [51, 134], [134, 45], [211, 170], [170, 140], [140, 211], [67, 69], [69, 108], [108, 67], [43, 106], [106, 91], [91, 43], [230, 119], [119, 120], [120, 230], [226, 130], [130, 247], [247, 226], [63, 53], [53, 52], [52, 63], [238, 20], [20, 242], [242, 238], [46, 70], [70, 156], [156, 46], [78, 62], [62, 96], [96, 78], [46, 53], [53, 63], [63, 46], [143, 34], [34, 227], [227, 143], [123, 117], [117, 111], [111, 123], [44, 125], [125, 19], [19, 44], [236, 134], [134, 51], [51, 236], [216, 206], [206, 205], [205, 216], [154, 153], [153, 22], [22, 154], [39, 37], [37, 167], [167, 39], [200, 201], [201, 208], [208, 200], [36, 142], [142, 100], [100, 36], [57, 212], [212, 202], [202, 57], [20, 60], [60, 99], [99, 20], [28, 158], [158, 157], [157, 28], [35, 226], [226, 113], [113, 35], [160, 159], [159, 27], [27, 160], [204, 202], [202, 210], [210, 204], [113, 225], [225, 46], [46, 113], [43, 202], [202, 204], [204, 43], [62, 76], [76, 77], [77, 62], [137, 123], [123, 116], [116, 137], [41, 38], [38, 72], [72, 41], [203, 129], [129, 142], [142, 203], [64, 98], [98, 240], [240, 64], [49, 102], [102, 64], [64, 49], [41, 73], [73, 74], [74, 41], [212, 216], [216, 207], [207, 212], [42, 74], [74, 184], [184, 42], [169, 170], [170, 211], [211, 169], [170, 149], [149, 176], [176, 170], [105, 66], [66, 69], [69, 105], [122, 6], [6, 168], [168, 122], [123, 147], [147, 187], [187, 123], [96, 77], [77, 90], [90, 96], [65, 55], [55, 107], [107, 65], [89, 90], [90, 180], [180, 89], [101, 100], [100, 120], [120, 101], [63, 105], [105, 104], [104, 63], [93, 137], [137, 227], [227, 93], [15, 86], [86, 85], [85, 15], [129, 102], [102, 49], [49, 129], [14, 87], [87, 86], [86, 14], [55, 8], [8, 9], [9, 55], [100, 47], [47, 121], [121, 100], [145, 23], [23, 22], [22, 145], [88, 89], [89, 179], [179, 88], [6, 122], [122, 196], [196, 6], [88, 95], [95, 96], [96, 88], [138, 172], [172, 136], [136, 138], [215, 58], [58, 172], [172, 215], [115, 48], [48, 219], [219, 115], [42, 80], [80, 81], [81, 42], [195, 3], [3, 51], [51, 195], [43, 146], [146, 61], [61, 43], [171, 175], [175, 199], [199, 171], [81, 82], [82, 38], [38, 81], [53, 46], [46, 225], [225, 53], [144, 163], [163, 110], [110, 144], [52, 65], [65, 66], [66, 52], [229, 228], [228, 117], [117, 229], [34, 127], [127, 234], [234, 34], [107, 108], [108, 69], [69, 107], [109, 108], [108, 151], [151, 109], [48, 64], [64, 235], [235, 48], [62, 78], [78, 191], [191, 62], [129, 209], [209, 126], [126, 129], [111, 35], [35, 143], [143, 111], [117, 123], [123, 50], [50, 117], [222, 65], [65, 52], [52, 222], [19, 125], [125, 141], [141, 19], [221, 55], [55, 65], [65, 221], [3, 195], [195, 197], [197, 3], [25, 7], [7, 33], [33, 25], [220, 237], [237, 44], [44, 220], [70, 71], [71, 139], [139, 70], [122, 193], [193, 245], [245, 122], [247, 130], [130, 33], [33, 247], [71, 21], [21, 162], [162, 71], [170, 169], [169, 150], [150, 170], [188, 174], [174, 196], [196, 188], [216, 186], [186, 92], [92, 216], [2, 97], [97, 167], [167, 2], [141, 125], [125, 241], [241, 141], [164, 167], [167, 37], [37, 164], [72, 38], [38, 12], [12, 72], [38, 82], [82, 13], [13, 38], [63, 68], [68, 71], [71, 63], [226, 35], [35, 111], [111, 226], [101, 50], [50, 205], [205, 101], [206, 92], [92, 165], [165, 206], [209, 198], [198, 217], [217, 209], [165, 167], [167, 97], [97, 165], [220, 115], [115, 218], [218, 220], [133, 112], [112, 243], [243, 133], [239, 238], [238, 241], [241, 239], [214, 135], [135, 169], [169, 214], [190, 173], [173, 133], [133, 190], [171, 208], [208, 32], [32, 171], [125, 44], [44, 237], [237, 125], [86, 87], [87, 178], [178, 86], [85, 86], [86, 179], [179, 85], [84, 85], [85, 180], [180, 84], [83, 84], [84, 181], [181, 83], [201, 83], [83, 182], [182, 201], [137, 93], [93, 132], [132, 137], [76, 62], [62, 183], [183, 76], [61, 76], [76, 184], [184, 61], [57, 61], [61, 185], [185, 57], [212, 57], [57, 186], [186, 212], [214, 207], [207, 187], [187, 214], [34, 143], [143, 156], [156, 34], [79, 239], [239, 237], [237, 79], [123, 137], [137, 177], [177, 123], [44, 1], [1, 4], [4, 44], [201, 194], [194, 32], [32, 201], [64, 102], [102, 129], [129, 64], [213, 215], [215, 138], [138, 213], [59, 166], [166, 219], [219, 59], [242, 99], [99, 97], [97, 242], [2, 94], [94, 141], [141, 2], [75, 59], [59, 235], [235, 75], [24, 110], [110, 228], [228, 24], [25, 130], [130, 226], [226, 25], [23, 24], [24, 229], [229, 23], [22, 23], [23, 230], [230, 22], [26, 22], [22, 231], [231, 26], [112, 26], [26, 232], [232, 112], [189, 190], [190, 243], [243, 189], [221, 56], [56, 190], [190, 221], [28, 56], [56, 221], [221, 28], [27, 28], [28, 222], [222, 27], [29, 27], [27, 223], [223, 29], [30, 29], [29, 224], [224, 30], [247, 30], [30, 225], [225, 247], [238, 79], [79, 20], [20, 238], [166, 59], [59, 75], [75, 166], [60, 75], [75, 240], [240, 60], [147, 177], [177, 215], [215, 147], [20, 79], [79, 166], [166, 20], [187, 147], [147, 213], [213, 187], [112, 233], [233, 244], [244, 112], [233, 128], [128, 245], [245, 233], [128, 114], [114, 188], [188, 128], [114, 217], [217, 174], [174, 114], [131, 115], [115, 220], [220, 131], [217, 198], [198, 236], [236, 217], [198, 131], [131, 134], [134, 198], [177, 132], [132, 58], [58, 177], [143, 35], [35, 124], [124, 143], [110, 163], [163, 7], [7, 110], [228, 110], [110, 25], [25, 228], [356, 389], [389, 368], [368, 356], [11, 302], [302, 267], [267, 11], [452, 350], [350, 349], [349, 452], [302, 303], [303, 269], [269, 302], [357, 343], [343, 277], [277, 357], [452, 453], [453, 357], [357, 452], [333, 332], [332, 297], [297, 333], [175, 152], [152, 377], [377, 175], [347, 348], [348, 330], [330, 347], [303, 304], [304, 270], [270, 303], [9, 336], [336, 337], [337, 9], [278, 279], [279, 360], [360, 278], [418, 262], [262, 431], [431, 418], [304, 408], [408, 409], [409, 304], [310, 415], [415, 407], [407, 310], [270, 409], [409, 410], [410, 270], [450, 348], [348, 347], [347, 450], [422, 430], [430, 434], [434, 422], [313, 314], [314, 17], [17, 313], [306, 307], [307, 375], [375, 306], [387, 388], [388, 260], [260, 387], [286, 414], [414, 398], [398, 286], [335, 406], [406, 418], [418, 335], [364, 367], [367, 416], [416, 364], [423, 358], [358, 327], [327, 423], [251, 284], [284, 298], [298, 251], [281, 5], [5, 4], [4, 281], [373, 374], [374, 253], [253, 373], [307, 320], [320, 321], [321, 307], [425, 427], [427, 411], [411, 425], [421, 313], [313, 18], [18, 421], [321, 405], [405, 406], [406, 321], [320, 404], [404, 405], [405, 320], [315, 16], [16, 17], [17, 315], [426, 425], [425, 266], [266, 426], [377, 400], [400, 369], [369, 377], [322, 391], [391, 269], [269, 322], [417, 465], [465, 464], [464, 417], [386, 257], [257, 258], [258, 386], [466, 260], [260, 388], [388, 466], [456, 399], [399, 419], [419, 456], [284, 332], [332, 333], [333, 284], [417, 285], [285, 8], [8, 417], [346, 340], [340, 261], [261, 346], [413, 441], [441, 285], [285, 413], [327, 460], [460, 328], [328, 327], [355, 371], [371, 329], [329, 355], [392, 439], [439, 438], [438, 392], [382, 341], [341, 256], [256, 382], [429, 420], [420, 360], [360, 429], [364, 394], [394, 379], [379, 364], [277, 343], [343, 437], [437, 277], [443, 444], [444, 283], [283, 443], [275, 440], [440, 363], [363, 275], [431, 262], [262, 369], [369, 431], [297, 338], [338, 337], [337, 297], [273, 375], [375, 321], [321, 273], [450, 451], [451, 349], [349, 450], [446, 342], [342, 467], [467, 446], [293, 334], [334, 282], [282, 293], [458, 461], [461, 462], [462, 458], [276, 353], [353, 383], [383, 276], [308, 324], [324, 325], [325, 308], [276, 300], [300, 293], [293, 276], [372, 345], [345, 447], [447, 372], [352, 345], [345, 340], [340, 352], [274, 1], [1, 19], [19, 274], [456, 248], [248, 281], [281, 456], [436, 427], [427, 425], [425, 436], [381, 256], [256, 252], [252, 381], [269, 391], [391, 393], [393, 269], [200, 199], [199, 428], [428, 200], [266, 330], [330, 329], [329, 266], [287, 273], [273, 422], [422, 287], [250, 462], [462, 328], [328, 250], [258, 286], [286, 384], [384, 258], [265, 353], [353, 342], [342, 265], [387, 259], [259, 257], [257, 387], [424, 431], [431, 430], [430, 424], [342, 353], [353, 276], [276, 342], [273, 335], [335, 424], [424, 273], [292, 325], [325, 307], [307, 292], [366, 447], [447, 345], [345, 366], [271, 303], [303, 302], [302, 271], [423, 266], [266, 371], [371, 423], [294, 455], [455, 460], [460, 294], [279, 278], [278, 294], [294, 279], [271, 272], [272, 304], [304, 271], [432, 434], [434, 427], [427, 432], [272, 407], [407, 408], [408, 272], [394, 430], [430, 431], [431, 394], [395, 369], [369, 400], [400, 395], [334, 333], [333, 299], [299, 334], [351, 417], [417, 168], [168, 351], [352, 280], [280, 411], [411, 352], [325, 319], [319, 320], [320, 325], [295, 296], [296, 336], [336, 295], [319, 403], [403, 404], [404, 319], [330, 348], [348, 349], [349, 330], [293, 298], [298, 333], [333, 293], [323, 454], [454, 447], [447, 323], [15, 16], [16, 315], [315, 15], [358, 429], [429, 279], [279, 358], [14, 15], [15, 316], [316, 14], [285, 336], [336, 9], [9, 285], [329, 349], [349, 350], [350, 329], [374, 380], [380, 252], [252, 374], [318, 402], [402, 403], [403, 318], [6, 197], [197, 419], [419, 6], [318, 319], [319, 325], [325, 318], [367, 364], [364, 365], [365, 367], [435, 367], [367, 397], [397, 435], [344, 438], [438, 439], [439, 344], [272, 271], [271, 311], [311, 272], [195, 5], [5, 281], [281, 195], [273, 287], [287, 291], [291, 273], [396, 428], [428, 199], [199, 396], [311, 271], [271, 268], [268, 311], [283, 444], [444, 445], [445, 283], [373, 254], [254, 339], [339, 373], [282, 334], [334, 296], [296, 282], [449, 347], [347, 346], [346, 449], [264, 447], [447, 454], [454, 264], [336, 296], [296, 299], [299, 336], [338, 10], [10, 151], [151, 338], [278, 439], [439, 455], [455, 278], [292, 407], [407, 415], [415, 292], [358, 371], [371, 355], [355, 358], [340, 345], [345, 372], [372, 340], [346, 347], [347, 280], [280, 346], [442, 443], [443, 282], [282, 442], [19, 94], [94, 370], [370, 19], [441, 442], [442, 295], [295, 441], [248, 419], [419, 197], [197, 248], [263, 255], [255, 359], [359, 263], [440, 275], [275, 274], [274, 440], [300, 383], [383, 368], [368, 300], [351, 412], [412, 465], [465, 351], [263, 467], [467, 466], [466, 263], [301, 368], [368, 389], [389, 301], [395, 378], [378, 379], [379, 395], [412, 351], [351, 419], [419, 412], [436, 426], [426, 322], [322, 436], [2, 164], [164, 393], [393, 2], [370, 462], [462, 461], [461, 370], [164, 0], [0, 267], [267, 164], [302, 11], [11, 12], [12, 302], [268, 12], [12, 13], [13, 268], [293, 300], [300, 301], [301, 293], [446, 261], [261, 340], [340, 446], [330, 266], [266, 425], [425, 330], [426, 423], [423, 391], [391, 426], [429, 355], [355, 437], [437, 429], [391, 327], [327, 326], [326, 391], [440, 457], [457, 438], [438, 440], [341, 382], [382, 362], [362, 341], [459, 457], [457, 461], [461, 459], [434, 430], [430, 394], [394, 434], [414, 463], [463, 362], [362, 414], [396, 369], [369, 262], [262, 396], [354, 461], [461, 457], [457, 354], [316, 403], [403, 402], [402, 316], [315, 404], [404, 403], [403, 315], [314, 405], [405, 404], [404, 314], [313, 406], [406, 405], [405, 313], [421, 418], [418, 406], [406, 421], [366, 401], [401, 361], [361, 366], [306, 408], [408, 407], [407, 306], [291, 409], [409, 408], [408, 291], [287, 410], [410, 409], [409, 287], [432, 436], [436, 410], [410, 432], [434, 416], [416, 411], [411, 434], [264, 368], [368, 383], [383, 264], [309, 438], [438, 457], [457, 309], [352, 376], [376, 401], [401, 352], [274, 275], [275, 4], [4, 274], [421, 428], [428, 262], [262, 421], [294, 327], [327, 358], [358, 294], [433, 416], [416, 367], [367, 433], [289, 455], [455, 439], [439, 289], [462, 370], [370, 326], [326, 462], [2, 326], [326, 370], [370, 2], [305, 460], [460, 455], [455, 305], [254, 449], [449, 448], [448, 254], [255, 261], [261, 446], [446, 255], [253, 450], [450, 449], [449, 253], [252, 451], [451, 450], [450, 252], [256, 452], [452, 451], [451, 256], [341, 453], [453, 452], [452, 341], [413, 464], [464, 463], [463, 413], [441, 413], [413, 414], [414, 441], [258, 442], [442, 441], [441, 258], [257, 443], [443, 442], [442, 257], [259, 444], [444, 443], [443, 259], [260, 445], [445, 444], [444, 260], [467, 342], [342, 445], [445, 467], [459, 458], [458, 250], [250, 459], [289, 392], [392, 290], [290, 289], [290, 328], [328, 460], [460, 290], [376, 433], [433, 435], [435, 376], [250, 290], [290, 392], [392, 250], [411, 416], [416, 433], [433, 411], [341, 463], [463, 464], [464, 341], [453, 464], [464, 465], [465, 453], [357, 465], [465, 412], [412, 357], [343, 412], [412, 399], [399, 343], [360, 363], [363, 440], [440, 360], [437, 399], [399, 456], [456, 437], [420, 456], [456, 363], [363, 420], [401, 435], [435, 288], [288, 401], [372, 383], [383, 353], [353, 372], [339, 255], [255, 249], [249, 339], [448, 261], [261, 255], [255, 448], [133, 243], [243, 190], [190, 133], [133, 155], [155, 112], [112, 133], [33, 246], [246, 247], [247, 33], [33, 130], [130, 25], [25, 33], [398, 384], [384, 286], [286, 398], [362, 398], [398, 414], [414, 362], [362, 463], [463, 341], [341, 362], [263, 359], [359, 467], [467, 263], [263, 249], [249, 255], [255, 263], [466, 467], [467, 260], [260, 466], [75, 60], [60, 166], [166, 75], [238, 239], [239, 79], [79, 238], [162, 127], [127, 139], [139, 162], [72, 11], [11, 37], [37, 72], [121, 232], [232, 120], [120, 121], [73, 72], [72, 39], [39, 73], [114, 128], [128, 47], [47, 114], [233, 232], [232, 128], [128, 233], [103, 104], [104, 67], [67, 103], [152, 175], [175, 148], [148, 152], [119, 118], [118, 101], [101, 119], [74, 73], [73, 40], [40, 74], [107, 9], [9, 108], [108, 107], [49, 48], [48, 131], [131, 49], [32, 194], [194, 211], [211, 32], [184, 74], [74, 185], [185, 184], [191, 80], [80, 183], [183, 191], [185, 40], [40, 186], [186, 185], [119, 230], [230, 118], [118, 119], [210, 202], [202, 214], [214, 210], [84, 83], [83, 17], [17, 84], [77, 76], [76, 146], [146, 77], [161, 160], [160, 30], [30, 161], [190, 56], [56, 173], [173, 190], [182, 106], [106, 194], [194, 182], [138, 135], [135, 192], [192, 138], [129, 203], [203, 98], [98, 129], [54, 21], [21, 68], [68, 54], [5, 51], [51, 4], [4, 5], [145, 144], [144, 23], [23, 145], [90, 77], [77, 91], [91, 90], [207, 205], [205, 187], [187, 207], [83, 201], [201, 18], [18, 83], [181, 91], [91, 182], [182, 181], [180, 90], [90, 181], [181, 180], [16, 85], [85, 17], [17, 16], [205, 206], [206, 36], [36, 205], [176, 148], [148, 140], [140, 176], [165, 92], [92, 39], [39, 165], [245, 193], [193, 244], [244, 245], [27, 159], [159, 28], [28, 27], [30, 247], [247, 161], [161, 30], [174, 236], [236, 196], [196, 174], [103, 54], [54, 104], [104, 103], [55, 193], [193, 8], [8, 55], [111, 117], [117, 31], [31, 111], [221, 189], [189, 55], [55, 221], [240, 98], [98, 99], [99, 240], [142, 126], [126, 100], [100, 142], [219, 166], [166, 218], [218, 219], [112, 155], [155, 26], [26, 112], [198, 209], [209, 131], [131, 198], [169, 135], [135, 150], [150, 169], [114, 47], [47, 217], [217, 114], [224, 223], [223, 53], [53, 224], [220, 45], [45, 134], [134, 220], [32, 211], [211, 140], [140, 32], [109, 67], [67, 108], [108, 109], [146, 43], [43, 91], [91, 146], [231, 230], [230, 120], [120, 231], [113, 226], [226, 247], [247, 113], [105, 63], [63, 52], [52, 105], [241, 238], [238, 242], [242, 241], [124, 46], [46, 156], [156, 124], [95, 78], [78, 96], [96, 95], [70, 46], [46, 63], [63, 70], [116, 143], [143, 227], [227, 116], [116, 123], [123, 111], [111, 116], [1, 44], [44, 19], [19, 1], [3, 236], [236, 51], [51, 3], [207, 216], [216, 205], [205, 207], [26, 154], [154, 22], [22, 26], [165, 39], [39, 167], [167, 165], [199, 200], [200, 208], [208, 199], [101, 36], [36, 100], [100, 101], [43, 57], [57, 202], [202, 43], [242, 20], [20, 99], [99, 242], [56, 28], [28, 157], [157, 56], [124, 35], [35, 113], [113, 124], [29, 160], [160, 27], [27, 29], [211, 204], [204, 210], [210, 211], [124, 113], [113, 46], [46, 124], [106, 43], [43, 204], [204, 106], [96, 62], [62, 77], [77, 96], [227, 137], [137, 116], [116, 227], [73, 41], [41, 72], [72, 73], [36, 203], [203, 142], [142, 36], [235, 64], [64, 240], [240, 235], [48, 49], [49, 64], [64, 48], [42, 41], [41, 74], [74, 42], [214, 212], [212, 207], [207, 214], [183, 42], [42, 184], [184, 183], [210, 169], [169, 211], [211, 210], [140, 170], [170, 176], [176, 140], [104, 105], [105, 69], [69, 104], [193, 122], [122, 168], [168, 193], [50, 123], [123, 187], [187, 50], [89, 96], [96, 90], [90, 89], [66, 65], [65, 107], [107, 66], [179, 89], [89, 180], [180, 179], [119, 101], [101, 120], [120, 119], [68, 63], [63, 104], [104, 68], [234, 93], [93, 227], [227, 234], [16, 15], [15, 85], [85, 16], [209, 129], [129, 49], [49, 209], [15, 14], [14, 86], [86, 15], [107, 55], [55, 9], [9, 107], [120, 100], [100, 121], [121, 120], [153, 145], [145, 22], [22, 153], [178, 88], [88, 179], [179, 178], [197, 6], [6, 196], [196, 197], [89, 88], [88, 96], [96, 89], [135, 138], [138, 136], [136, 135], [138, 215], [215, 172], [172, 138], [218, 115], [115, 219], [219, 218], [41, 42], [42, 81], [81, 41], [5, 195], [195, 51], [51, 5], [57, 43], [43, 61], [61, 57], [208, 171], [171, 199], [199, 208], [41, 81], [81, 38], [38, 41], [224, 53], [53, 225], [225, 224], [24, 144], [144, 110], [110, 24], [105, 52], [52, 66], [66, 105], [118, 229], [229, 117], [117, 118], [227, 34], [34, 234], [234, 227], [66, 107], [107, 69], [69, 66], [10, 109], [109, 151], [151, 10], [219, 48], [48, 235], [235, 219], [183, 62], [62, 191], [191, 183], [142, 129], [129, 126], [126, 142], [116, 111], [111, 143], [143, 116], [118, 117], [117, 50], [50, 118], [223, 222], [222, 52], [52, 223], [94, 19], [19, 141], [141, 94], [222, 221], [221, 65], [65, 222], [196, 3], [3, 197], [197, 196], [45, 220], [220, 44], [44, 45], [156, 70], [70, 139], [139, 156], [188, 122], [122, 245], [245, 188], [139, 71], [71, 162], [162, 139], [149, 170], [170, 150], [150, 149], [122, 188], [188, 196], [196, 122], [206, 216], [216, 92], [92, 206], [164, 2], [2, 167], [167, 164], [242, 141], [141, 241], [241, 242], [0, 164], [164, 37], [37, 0], [11, 72], [72, 12], [12, 11], [12, 38], [38, 13], [13, 12], [70, 63], [63, 71], [71, 70], [31, 226], [226, 111], [111, 31], [36, 101], [101, 205], [205, 36], [203, 206], [206, 165], [165, 203], [126, 209], [209, 217], [217, 126], [98, 165], [165, 97], [97, 98], [237, 220], [220, 218], [218, 237], [237, 239], [239, 241], [241, 237], [210, 214], [214, 169], [169, 210], [140, 171], [171, 32], [32, 140], [241, 125], [125, 237], [237, 241], [179, 86], [86, 178], [178, 179], [180, 85], [85, 179], [179, 180], [181, 84], [84, 180], [180, 181], [182, 83], [83, 181], [181, 182], [194, 201], [201, 182], [182, 194], [177, 137], [137, 132], [132, 177], [184, 76], [76, 183], [183, 184], [185, 61], [61, 184], [184, 185], [186, 57], [57, 185], [185, 186], [216, 212], [212, 186], [186, 216], [192, 214], [214, 187], [187, 192], [139, 34], [34, 156], [156, 139], [218, 79], [79, 237], [237, 218], [147, 123], [123, 177], [177, 147], [45, 44], [44, 4], [4, 45], [208, 201], [201, 32], [32, 208], [98, 64], [64, 129], [129, 98], [192, 213], [213, 138], [138, 192], [235, 59], [59, 219], [219, 235], [141, 242], [242, 97], [97, 141], [97, 2], [2, 141], [141, 97], [240, 75], [75, 235], [235, 240], [229, 24], [24, 228], [228, 229], [31, 25], [25, 226], [226, 31], [230, 23], [23, 229], [229, 230], [231, 22], [22, 230], [230, 231], [232, 26], [26, 231], [231, 232], [233, 112], [112, 232], [232, 233], [244, 189], [189, 243], [243, 244], [189, 221], [221, 190], [190, 189], [222, 28], [28, 221], [221, 222], [223, 27], [27, 222], [222, 223], [224, 29], [29, 223], [223, 224], [225, 30], [30, 224], [224, 225], [113, 247], [247, 225], [225, 113], [99, 60], [60, 240], [240, 99], [213, 147], [147, 215], [215, 213], [60, 20], [20, 166], [166, 60], [192, 187], [187, 213], [213, 192], [243, 112], [112, 244], [244, 243], [244, 233], [233, 245], [245, 244], [245, 128], [128, 188], [188, 245], [188, 114], [114, 174], [174, 188], [134, 131], [131, 220], [220, 134], [174, 217], [217, 236], [236, 174], [236, 198], [198, 134], [134, 236], [215, 177], [177, 58], [58, 215], [156, 143], [143, 124], [124, 156], [25, 110], [110, 7], [7, 25], [31, 228], [228, 25], [25, 31], [264, 356], [356, 368], [368, 264], [0, 11], [11, 267], [267, 0], [451, 452], [452, 349], [349, 451], [267, 302], [302, 269], [269, 267], [350, 357], [357, 277], [277, 350], [350, 452], [452, 357], [357, 350], [299, 333], [333, 297], [297, 299], [396, 175], [175, 377], [377, 396], [280, 347], [347, 330], [330, 280], [269, 303], [303, 270], [270, 269], [151, 9], [9, 337], [337, 151], [344, 278], [278, 360], [360, 344], [424, 418], [418, 431], [431, 424], [270, 304], [304, 409], [409, 270], [272, 310], [310, 407], [407, 272], [322, 270], [270, 410], [410, 322], [449, 450], [450, 347], [347, 449], [432, 422], [422, 434], [434, 432], [18, 313], [313, 17], [17, 18], [291, 306], [306, 375], [375, 291], [259, 387], [387, 260], [260, 259], [424, 335], [335, 418], [418, 424], [434, 364], [364, 416], [416, 434], [391, 423], [423, 327], [327, 391], [301, 251], [251, 298], [298, 301], [275, 281], [281, 4], [4, 275], [254, 373], [373, 253], [253, 254], [375, 307], [307, 321], [321, 375], [280, 425], [425, 411], [411, 280], [200, 421], [421, 18], [18, 200], [335, 321], [321, 406], [406, 335], [321, 320], [320, 405], [405, 321], [314, 315], [315, 17], [17, 314], [423, 426], [426, 266], [266, 423], [396, 377], [377, 369], [369, 396], [270, 322], [322, 269], [269, 270], [413, 417], [417, 464], [464, 413], [385, 386], [386, 258], [258, 385], [248, 456], [456, 419], [419, 248], [298, 284], [284, 333], [333, 298], [168, 417], [417, 8], [8, 168], [448, 346], [346, 261], [261, 448], [417, 413], [413, 285], [285, 417], [326, 327], [327, 328], [328, 326], [277, 355], [355, 329], [329, 277], [309, 392], [392, 438], [438, 309], [381, 382], [382, 256], [256, 381], [279, 429], [429, 360], [360, 279], [365, 364], [364, 379], [379, 365], [355, 277], [277, 437], [437, 355], [282, 443], [443, 283], [283, 282], [281, 275], [275, 363], [363, 281], [395, 431], [431, 369], [369, 395], [299, 297], [297, 337], [337, 299], [335, 273], [273, 321], [321, 335], [348, 450], [450, 349], [349, 348], [359, 446], [446, 467], [467, 359], [283, 293], [293, 282], [282, 283], [250, 458], [458, 462], [462, 250], [300, 276], [276, 383], [383, 300], [292, 308], [308, 325], [325, 292], [283, 276], [276, 293], [293, 283], [264, 372], [372, 447], [447, 264], [346, 352], [352, 340], [340, 346], [354, 274], [274, 19], [19, 354], [363, 456], [456, 281], [281, 363], [426, 436], [436, 425], [425, 426], [380, 381], [381, 252], [252, 380], [267, 269], [269, 393], [393, 267], [421, 200], [200, 428], [428, 421], [371, 266], [266, 329], [329, 371], [432, 287], [287, 422], [422, 432], [290, 250], [250, 328], [328, 290], [385, 258], [258, 384], [384, 385], [446, 265], [265, 342], [342, 446], [386, 387], [387, 257], [257, 386], [422, 424], [424, 430], [430, 422], [445, 342], [342, 276], [276, 445], [422, 273], [273, 424], [424, 422], [306, 292], [292, 307], [307, 306], [352, 366], [366, 345], [345, 352], [268, 271], [271, 302], [302, 268], [358, 423], [423, 371], [371, 358], [327, 294], [294, 460], [460, 327], [331, 279], [279, 294], [294, 331], [303, 271], [271, 304], [304, 303], [436, 432], [432, 427], [427, 436], [304, 272], [272, 408], [408, 304], [395, 394], [394, 431], [431, 395], [378, 395], [395, 400], [400, 378], [296, 334], [334, 299], [299, 296], [6, 351], [351, 168], [168, 6], [376, 352], [352, 411], [411, 376], [307, 325], [325, 320], [320, 307], [285, 295], [295, 336], [336, 285], [320, 319], [319, 404], [404, 320], [329, 330], [330, 349], [349, 329], [334, 293], [293, 333], [333, 334], [366, 323], [323, 447], [447, 366], [316, 15], [15, 315], [315, 316], [331, 358], [358, 279], [279, 331], [317, 14], [14, 316], [316, 317], [8, 285], [285, 9], [9, 8], [277, 329], [329, 350], [350, 277], [253, 374], [374, 252], [252, 253], [319, 318], [318, 403], [403, 319], [351, 6], [6, 419], [419, 351], [324, 318], [318, 325], [325, 324], [397, 367], [367, 365], [365, 397], [288, 435], [435, 397], [397, 288], [278, 344], [344, 439], [439, 278], [310, 272], [272, 311], [311, 310], [248, 195], [195, 281], [281, 248], [375, 273], [273, 291], [291, 375], [175, 396], [396, 199], [199, 175], [312, 311], [311, 268], [268, 312], [276, 283], [283, 445], [445, 276], [390, 373], [373, 339], [339, 390], [295, 282], [282, 296], [296, 295], [448, 449], [449, 346], [346, 448], [356, 264], [264, 454], [454, 356], [337, 336], [336, 299], [299, 337], [337, 338], [338, 151], [151, 337], [294, 278], [278, 455], [455, 294], [308, 292], [292, 415], [415, 308], [429, 358], [358, 355], [355, 429], [265, 340], [340, 372], [372, 265], [352, 346], [346, 280], [280, 352], [295, 442], [442, 282], [282, 295], [354, 19], [19, 370], [370, 354], [285, 441], [441, 295], [295, 285], [195, 248], [248, 197], [197, 195], [457, 440], [440, 274], [274, 457], [301, 300], [300, 368], [368, 301], [417, 351], [351, 465], [465, 417], [251, 301], [301, 389], [389, 251], [394, 395], [395, 379], [379, 394], [399, 412], [412, 419], [419, 399], [410, 436], [436, 322], [322, 410], [326, 2], [2, 393], [393, 326], [354, 370], [370, 461], [461, 354], [393, 164], [164, 267], [267, 393], [268, 302], [302, 12], [12, 268], [312, 268], [268, 13], [13, 312], [298, 293], [293, 301], [301, 298], [265, 446], [446, 340], [340, 265], [280, 330], [330, 425], [425, 280], [322, 426], [426, 391], [391, 322], [420, 429], [429, 437], [437, 420], [393, 391], [391, 326], [326, 393], [344, 440], [440, 438], [438, 344], [458, 459], [459, 461], [461, 458], [364, 434], [434, 394], [394, 364], [428, 396], [396, 262], [262, 428], [274, 354], [354, 457], [457, 274], [317, 316], [316, 402], [402, 317], [316, 315], [315, 403], [403, 316], [315, 314], [314, 404], [404, 315], [314, 313], [313, 405], [405, 314], [313, 421], [421, 406], [406, 313], [323, 366], [366, 361], [361, 323], [292, 306], [306, 407], [407, 292], [306, 291], [291, 408], [408, 306], [291, 287], [287, 409], [409, 291], [287, 432], [432, 410], [410, 287], [427, 434], [434, 411], [411, 427], [372, 264], [264, 383], [383, 372], [459, 309], [309, 457], [457, 459], [366, 352], [352, 401], [401, 366], [1, 274], [274, 4], [4, 1], [418, 421], [421, 262], [262, 418], [331, 294], [294, 358], [358, 331], [435, 433], [433, 367], [367, 435], [392, 289], [289, 439], [439, 392], [328, 462], [462, 326], [326, 328], [94, 2], [2, 370], [370, 94], [289, 305], [305, 455], [455, 289], [339, 254], [254, 448], [448, 339], [359, 255], [255, 446], [446, 359], [254, 253], [253, 449], [449, 254], [253, 252], [252, 450], [450, 253], [252, 256], [256, 451], [451, 252], [256, 341], [341, 452], [452, 256], [414, 413], [413, 463], [463, 414], [286, 441], [441, 414], [414, 286], [286, 258], [258, 441], [441, 286], [258, 257], [257, 442], [442, 258], [257, 259], [259, 443], [443, 257], [259, 260], [260, 444], [444, 259], [260, 467], [467, 445], [445, 260], [309, 459], [459, 250], [250, 309], [305, 289], [289, 290], [290, 305], [305, 290], [290, 460], [460, 305], [401, 376], [376, 435], [435, 401], [309, 250], [250, 392], [392, 309], [376, 411], [411, 433], [433, 376], [453, 341], [341, 464], [464, 453], [357, 453], [453, 465], [465, 357], [343, 357], [357, 412], [412, 343], [437, 343], [343, 399], [399, 437], [344, 360], [360, 440], [440, 344], [420, 437], [437, 456], [456, 420], [360, 420], [420, 363], [363, 360], [361, 401], [401, 288], [288, 361], [265, 372], [372, 353], [353, 265], [390, 339], [339, 249], [249, 390], [339, 448], [448, 255], [255, 339]);
  function _c(t2) {
    t2.m = { faceLandmarks: [], faceBlendshapes: [], facialTransformationMatrixes: [] };
  }
  var yc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect", false), this.m = { faceLandmarks: [], faceBlendshapes: [], facialTransformationMatrixes: [] }, this.outputFacialTransformationMatrixes = this.outputFaceBlendshapes = false, Rr(t2 = this.i = new sa(), 0, 1, e2 = new qo()), this.C = new ia(), Rr(this.i, 0, 3, this.C), this.v = new ta(), Rr(this.i, 0, 2, this.v), $r(this.v, 4, 1), jr(this.v, 2, 0.5), jr(this.C, 2, 0.5), jr(this.i, 4, 0.5);
    }
    D() {
      return "FaceLandmarker";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return "numFaces" in t2 && $r(this.v, 4, t2.numFaces ?? 1), "minFaceDetectionConfidence" in t2 && jr(this.v, 2, t2.minFaceDetectionConfidence ?? 0.5), "minTrackingConfidence" in t2 && jr(this.i, 4, t2.minTrackingConfidence ?? 0.5), "minFacePresenceConfidence" in t2 && jr(this.C, 2, t2.minFacePresenceConfidence ?? 0.5), "outputFaceBlendshapes" in t2 && (this.outputFaceBlendshapes = !!t2.outputFaceBlendshapes), "outputFacialTransformationMatrixes" in t2 && (this.outputFacialTransformationMatrixes = !!t2.outputFacialTransformationMatrixes), this.l(t2);
    }
    H(t2, e2) {
      return _c(this), nc(this, t2, e2), this.m;
    }
    I(t2, e2, r2) {
      return _c(this), ic(this, t2, r2, e2), this.m;
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect"), vo(t2, "face_landmarks");
      var e2 = new so();
      ci(e2, aa, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.face_landmarker.FaceLandmarkerGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "NORM_LANDMARKS:face_landmarks"), r2.A(e2), mo(t2, r2), this.h.attachProtoVectorListener("face_landmarks", (t3, e3) => {
        for (let e4 of t3) t3 = Co(e4), this.m.faceLandmarks.push(eh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("face_landmarks", (t3) => {
        nu(this, t3);
      }), this.outputFaceBlendshapes && (vo(t2, "blendshapes"), uo(r2, "BLENDSHAPES:blendshapes"), this.h.attachProtoVectorListener("blendshapes", (t3, e3) => {
        if (this.outputFaceBlendshapes) for (let e4 of t3) t3 = bo(e4), this.m.faceBlendshapes.push(Za(t3.h() ?? []));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("blendshapes", (t3) => {
        nu(this, t3);
      })), this.outputFacialTransformationMatrixes && (vo(t2, "face_geometry"), uo(r2, "FACE_GEOMETRY:face_geometry"), this.h.attachProtoVectorListener("face_geometry", (t3, e3) => {
        if (this.outputFacialTransformationMatrixes) for (let e4 of t3) (t3 = kr(t3 = na(e4), No, 2)) && this.m.facialTransformationMatrixes.push({ rows: Mr(t3, 1) ?? 0 ?? 0, columns: Mr(t3, 2) ?? 0 ?? 0, data: lr(t3, 3, Jt).slice() ?? [] });
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("face_geometry", (t3) => {
        nu(this, t3);
      })), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  yc.prototype.detectForVideo = yc.prototype.I, yc.prototype.detect = yc.prototype.H, yc.prototype.setOptions = yc.prototype.A, yc.createFromModelPath = function(t2, e2) {
    return ec(yc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, yc.createFromModelBuffer = function(t2, e2) {
    return ec(yc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, yc.createFromOptions = function(t2, e2) {
    return ec(yc, t2, e2);
  }, yc.FACE_LANDMARKS_LIPS = hc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LIPS", yc.FACE_LANDMARKS_LIPS), yc.FACE_LANDMARKS_LEFT_EYE = uc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYE", yc.FACE_LANDMARKS_LEFT_EYE), yc.FACE_LANDMARKS_LEFT_EYEBROW = cc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", yc.FACE_LANDMARKS_LEFT_EYEBROW), yc.FACE_LANDMARKS_LEFT_IRIS = lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_LEFT_IRIS", yc.FACE_LANDMARKS_LEFT_IRIS), yc.FACE_LANDMARKS_RIGHT_EYE = dc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYE", yc.FACE_LANDMARKS_RIGHT_EYE), yc.FACE_LANDMARKS_RIGHT_EYEBROW = fc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", yc.FACE_LANDMARKS_RIGHT_EYEBROW), yc.FACE_LANDMARKS_RIGHT_IRIS = pc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_RIGHT_IRIS", yc.FACE_LANDMARKS_RIGHT_IRIS), yc.FACE_LANDMARKS_FACE_OVAL = mc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_FACE_OVAL", yc.FACE_LANDMARKS_FACE_OVAL), yc.FACE_LANDMARKS_CONTOURS = gc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_CONTOURS", yc.FACE_LANDMARKS_CONTOURS), yc.FACE_LANDMARKS_TESSELATION = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$face_landmarker$face_landmarker.FaceLandmarker.FACE_LANDMARKS_TESSELATION", yc.FACE_LANDMARKS_TESSELATION);
  var Ec = Ju([0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11], [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [0, 17], [17, 18], [18, 19], [19, 20]);
  function Ac(t2) {
    t2.gestures = [], t2.landmarks = [], t2.worldLandmarks = [], t2.handedness = [];
  }
  function wc(t2) {
    return 0 === t2.gestures.length ? { gestures: [], landmarks: [], worldLandmarks: [], handedness: [], handednesses: [] } : { gestures: t2.gestures, landmarks: t2.landmarks, worldLandmarks: t2.worldLandmarks, handedness: t2.handedness, handednesses: t2.handedness };
  }
  function Tc(t2, e2 = true) {
    var r2 = [];
    for (let i2 of t2) {
      var n2 = bo(i2);
      t2 = [];
      for (let r3 of n2.h()) n2 = e2 && null != Mr(r3, 1) ? Mr(r3, 1) ?? 0 : -1, t2.push({ score: Or(r3, 2) ?? 0, index: n2, categoryName: _e(sr(r3, 3)) ?? "" ?? "", displayName: _e(sr(r3, 4)) ?? "" ?? "" });
      r2.push(t2);
    }
    return r2;
  }
  var bc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect", false), this.gestures = [], this.landmarks = [], this.worldLandmarks = [], this.handedness = [], Rr(t2 = this.m = new pa(), 0, 1, e2 = new qo()), this.v = new fa(), Rr(this.m, 0, 2, this.v), this.G = new da(), Rr(this.v, 0, 3, this.G), this.C = new la(), Rr(this.v, 0, 2, this.C), this.i = new ca(), Rr(this.m, 0, 3, this.i), jr(this.C, 2, 0.5), jr(this.v, 4, 0.5), jr(this.G, 2, 0.5);
    }
    D() {
      return "GestureRecognizer";
    }
    get baseOptions() {
      return kr(this.m, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.m, 0, 1, t2);
    }
    A(t2) {
      if ($r(this.C, 3, t2.numHands ?? 1), "minHandDetectionConfidence" in t2 && jr(this.C, 2, t2.minHandDetectionConfidence ?? 0.5), "minTrackingConfidence" in t2 && jr(this.v, 4, t2.minTrackingConfidence ?? 0.5), "minHandPresenceConfidence" in t2 && jr(this.G, 2, t2.minHandPresenceConfidence ?? 0.5), t2.cannedGesturesClassifierOptions) {
        var e2 = new ha(), r2 = e2, n2 = qa(t2.cannedGesturesClassifierOptions, kr(this.i, ha, 3)?.l());
        Rr(r2, 0, 2, n2), Rr(this.i, 0, 3, e2);
      } else void 0 === t2.cannedGesturesClassifierOptions && kr(this.i, ha, 3)?.h();
      return t2.customGesturesClassifierOptions ? (Rr(r2 = e2 = new ha(), 0, 2, n2 = qa(t2.customGesturesClassifierOptions, kr(this.i, ha, 4)?.l())), Rr(this.i, 0, 4, e2)) : void 0 === t2.customGesturesClassifierOptions && kr(this.i, ha, 4)?.h(), this.l(t2);
    }
    Ya(t2, e2) {
      return Ac(this), nc(this, t2, e2), wc(this);
    }
    Za(t2, e2, r2) {
      return Ac(this), ic(this, t2, r2, e2), wc(this);
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect"), vo(t2, "hand_gestures"), vo(t2, "hand_landmarks"), vo(t2, "world_hand_landmarks"), vo(t2, "handedness");
      var e2 = new so();
      ci(e2, ya, this.m);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.gesture_recognizer.GestureRecognizerGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "HAND_GESTURES:hand_gestures"), uo(r2, "LANDMARKS:hand_landmarks"), uo(r2, "WORLD_LANDMARKS:world_hand_landmarks"), uo(r2, "HANDEDNESS:handedness"), r2.A(e2), mo(t2, r2), this.h.attachProtoVectorListener("hand_landmarks", (t3, e3) => {
        for (let e4 of t3) t3 = Co(e4), this.landmarks.push(eh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("hand_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoVectorListener("world_hand_landmarks", (t3, e3) => {
        for (let e4 of t3) t3 = Io(e4), this.worldLandmarks.push(rh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("world_hand_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoVectorListener("hand_gestures", (t3, e3) => {
        this.gestures.push(...Tc(t3, false)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("hand_gestures", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoVectorListener("handedness", (t3, e3) => {
        this.handedness.push(...Tc(t3)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("handedness", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  function kc(t2) {
    return { landmarks: t2.landmarks, worldLandmarks: t2.worldLandmarks, handednesses: t2.handedness, handedness: t2.handedness };
  }
  bc.prototype.recognizeForVideo = bc.prototype.Za, bc.prototype.recognize = bc.prototype.Ya, bc.prototype.setOptions = bc.prototype.A, bc.createFromModelPath = function(t2, e2) {
    return ec(bc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, bc.createFromModelBuffer = function(t2, e2) {
    return ec(bc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, bc.createFromOptions = function(t2, e2) {
    return ec(bc, t2, e2);
  }, bc.HAND_CONNECTIONS = Ec, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$gesture_recognizer$gesture_recognizer.GestureRecognizer.HAND_CONNECTIONS", bc.HAND_CONNECTIONS);
  var Sc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect", false), this.landmarks = [], this.worldLandmarks = [], this.handedness = [], Rr(t2 = this.i = new fa(), 0, 1, e2 = new qo()), this.v = new da(), Rr(this.i, 0, 3, this.v), this.m = new la(), Rr(this.i, 0, 2, this.m), $r(this.m, 3, 1), jr(this.m, 2, 0.5), jr(this.v, 2, 0.5), jr(this.i, 4, 0.5);
    }
    D() {
      return "HandLandmarker";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return "numHands" in t2 && $r(this.m, 3, t2.numHands ?? 1), "minHandDetectionConfidence" in t2 && jr(this.m, 2, t2.minHandDetectionConfidence ?? 0.5), "minTrackingConfidence" in t2 && jr(this.i, 4, t2.minTrackingConfidence ?? 0.5), "minHandPresenceConfidence" in t2 && jr(this.v, 2, t2.minHandPresenceConfidence ?? 0.5), this.l(t2);
    }
    H(t2, e2) {
      return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], nc(this, t2, e2), kc(this);
    }
    I(t2, e2, r2) {
      return this.landmarks = [], this.worldLandmarks = [], this.handedness = [], ic(this, t2, r2, e2), kc(this);
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect"), vo(t2, "hand_landmarks"), vo(t2, "world_hand_landmarks"), vo(t2, "handedness");
      var e2 = new so();
      ci(e2, Ea, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.hand_landmarker.HandLandmarkerGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "LANDMARKS:hand_landmarks"), uo(r2, "WORLD_LANDMARKS:world_hand_landmarks"), uo(r2, "HANDEDNESS:handedness"), r2.A(e2), mo(t2, r2), this.h.attachProtoVectorListener("hand_landmarks", (t3, e3) => {
        for (let e4 of t3) t3 = Co(e4), this.landmarks.push(eh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("hand_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoVectorListener("world_hand_landmarks", (t3, e3) => {
        for (let e4 of t3) t3 = Io(e4), this.worldLandmarks.push(rh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("world_hand_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoVectorListener("handedness", (t3, e3) => {
        var r3 = this.handedness, n2 = r3.push, i2 = [];
        for (let e4 of t3) {
          t3 = bo(e4);
          let r4 = [];
          for (let e5 of t3.h()) r4.push({ score: Or(e5, 2) ?? 0, index: Mr(e5, 1) ?? 0 ?? -1, categoryName: _e(sr(e5, 3)) ?? "" ?? "", displayName: _e(sr(e5, 4)) ?? "" ?? "" });
          i2.push(r4);
        }
        n2.call(r3, ...i2), nu(this, e3);
      }), this.h.attachEmptyPacketListener("handedness", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  Sc.prototype.detectForVideo = Sc.prototype.I, Sc.prototype.detect = Sc.prototype.H, Sc.prototype.setOptions = Sc.prototype.A, Sc.createFromModelPath = function(t2, e2) {
    return ec(Sc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, Sc.createFromModelBuffer = function(t2, e2) {
    return ec(Sc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, Sc.createFromOptions = function(t2, e2) {
    return ec(Sc, t2, e2);
  }, Sc.HAND_CONNECTIONS = Ec, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$hand_landmarker$hand_landmarker.HandLandmarker.HAND_CONNECTIONS", Sc.HAND_CONNECTIONS);
  var Lc = Ju([0, 1], [1, 2], [2, 3], [3, 7], [0, 4], [4, 5], [5, 6], [6, 8], [9, 10], [11, 12], [11, 13], [13, 15], [15, 17], [15, 19], [15, 21], [17, 19], [12, 14], [14, 16], [16, 18], [16, 20], [16, 22], [18, 20], [11, 23], [12, 24], [23, 24], [23, 25], [24, 26], [25, 27], [26, 28], [27, 29], [28, 30], [29, 31], [30, 32], [27, 31], [28, 32]);
  function xc(t2) {
    t2.i = { faceLandmarks: [], faceBlendshapes: [], poseLandmarks: [], poseWorldLandmarks: [], poseSegmentationMasks: [], leftHandLandmarks: [], leftHandWorldLandmarks: [], rightHandLandmarks: [], rightHandWorldLandmarks: [] };
  }
  function Rc(t2) {
    try {
      if (!t2.G) return t2.i;
      t2.G(t2.i);
    } finally {
      ou(t2);
    }
  }
  function Ic(t2, e2) {
    t2 = Co(t2), e2.push(eh(t2));
  }
  var Fc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "input_frames_image", null, false), this.i = { faceLandmarks: [], faceBlendshapes: [], poseLandmarks: [], poseWorldLandmarks: [], poseSegmentationMasks: [], leftHandLandmarks: [], leftHandWorldLandmarks: [], rightHandLandmarks: [], rightHandWorldLandmarks: [] }, this.outputPoseSegmentationMasks = this.outputFaceBlendshapes = false, Rr(t2 = this.m = new ba(), 0, 1, e2 = new qo()), this.Z = new da(), Rr(this.m, 0, 2, this.Z), this.Ba = new Aa(), Rr(this.m, 0, 3, this.Ba), this.v = new ta(), Rr(this.m, 0, 4, this.v), this.P = new ia(), Rr(this.m, 0, 5, this.P), this.C = new wa(), Rr(this.m, 0, 6, this.C), this.aa = new Ta(), Rr(this.m, 0, 7, this.aa), jr(this.v, 2, 0.5), jr(this.v, 3, 0.3), jr(this.P, 2, 0.5), jr(this.C, 2, 0.5), jr(this.C, 3, 0.3), jr(this.aa, 2, 0.5), jr(this.Z, 2, 0.5);
    }
    D() {
      return "HolisticLandmarker";
    }
    get baseOptions() {
      return kr(this.m, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.m, 0, 1, t2);
    }
    A(t2) {
      return "minFaceDetectionConfidence" in t2 && jr(this.v, 2, t2.minFaceDetectionConfidence ?? 0.5), "minFaceSuppressionThreshold" in t2 && jr(this.v, 3, t2.minFaceSuppressionThreshold ?? 0.3), "minFacePresenceConfidence" in t2 && jr(this.P, 2, t2.minFacePresenceConfidence ?? 0.5), "outputFaceBlendshapes" in t2 && (this.outputFaceBlendshapes = !!t2.outputFaceBlendshapes), "minPoseDetectionConfidence" in t2 && jr(this.C, 2, t2.minPoseDetectionConfidence ?? 0.5), "minPoseSuppressionThreshold" in t2 && jr(this.C, 3, t2.minPoseSuppressionThreshold ?? 0.3), "minPosePresenceConfidence" in t2 && jr(this.aa, 2, t2.minPosePresenceConfidence ?? 0.5), "outputPoseSegmentationMasks" in t2 && (this.outputPoseSegmentationMasks = !!t2.outputPoseSegmentationMasks), "minHandLandmarksConfidence" in t2 && jr(this.Z, 2, t2.minHandLandmarksConfidence ?? 0.5), this.l(t2);
    }
    H(t2, e2, r2) {
      var n2 = "function" != typeof e2 ? e2 : {};
      return this.G = "function" == typeof e2 ? e2 : r2, xc(this), nc(this, t2, n2), Rc(this);
    }
    I(t2, e2, r2, n2) {
      var i2 = "function" != typeof r2 ? r2 : {};
      return this.G = "function" == typeof r2 ? r2 : n2, xc(this), ic(this, t2, i2, e2), Rc(this);
    }
    u() {
      var t2 = new _o();
      go(t2, "input_frames_image"), vo(t2, "pose_landmarks"), vo(t2, "pose_world_landmarks"), vo(t2, "face_landmarks"), vo(t2, "left_hand_landmarks"), vo(t2, "left_hand_world_landmarks"), vo(t2, "right_hand_landmarks"), vo(t2, "right_hand_world_landmarks");
      var e2 = new so(), r2 = new Us();
      Vr(r2, 1, "type.googleapis.com/mediapipe.tasks.vision.holistic_landmarker.proto.HolisticLandmarkerGraphOptions"), (function(t3, e3) {
        if (null != e3) if (Array.isArray(e3)) ar(t3, 2, je(e3, 0, Ve));
        else {
          if (!("string" == typeof e3 || e3 instanceof N || x(e3))) throw Error("invalid value in Any.value field: " + e3 + " expected a ByteString, a base64 encoded string, a Uint8Array or a jspb array");
          _r(t3, 2, lt(e3, false), I());
        }
      })(r2, this.m.h());
      var n2 = new co();
      Vr(n2, 2, "mediapipe.tasks.vision.holistic_landmarker.HolisticLandmarkerGraph"), Nr(n2, 8, Us, r2), ho(n2, "IMAGE:input_frames_image"), uo(n2, "POSE_LANDMARKS:pose_landmarks"), uo(n2, "POSE_WORLD_LANDMARKS:pose_world_landmarks"), uo(n2, "FACE_LANDMARKS:face_landmarks"), uo(n2, "LEFT_HAND_LANDMARKS:left_hand_landmarks"), uo(n2, "LEFT_HAND_WORLD_LANDMARKS:left_hand_world_landmarks"), uo(n2, "RIGHT_HAND_LANDMARKS:right_hand_landmarks"), uo(n2, "RIGHT_HAND_WORLD_LANDMARKS:right_hand_world_landmarks"), n2.A(e2), mo(t2, n2), iu(this, t2), this.h.attachProtoListener("pose_landmarks", (t3, e3) => {
        Ic(t3, this.i.poseLandmarks), nu(this, e3);
      }), this.h.attachEmptyPacketListener("pose_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoListener("pose_world_landmarks", (t3, e3) => {
        var r3 = this.i.poseWorldLandmarks;
        t3 = Io(t3), r3.push(rh(t3)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("pose_world_landmarks", (t3) => {
        nu(this, t3);
      }), this.outputPoseSegmentationMasks && (uo(n2, "POSE_SEGMENTATION_MASK:pose_segmentation_mask"), su(this, "pose_segmentation_mask"), this.h.ha("pose_segmentation_mask", (t3, e3) => {
        this.i.poseSegmentationMasks = [sc(this, t3, true, !this.G)], nu(this, e3);
      }), this.h.attachEmptyPacketListener("pose_segmentation_mask", (t3) => {
        this.i.poseSegmentationMasks = [], nu(this, t3);
      })), this.h.attachProtoListener("face_landmarks", (t3, e3) => {
        Ic(t3, this.i.faceLandmarks), nu(this, e3);
      }), this.h.attachEmptyPacketListener("face_landmarks", (t3) => {
        nu(this, t3);
      }), this.outputFaceBlendshapes && (vo(t2, "extra_blendshapes"), uo(n2, "FACE_BLENDSHAPES:extra_blendshapes"), this.h.attachProtoListener("extra_blendshapes", (t3, e3) => {
        var r3 = this.i.faceBlendshapes;
        this.outputFaceBlendshapes && (t3 = bo(t3), r3.push(Za(t3.h() ?? []))), nu(this, e3);
      }), this.h.attachEmptyPacketListener("extra_blendshapes", (t3) => {
        nu(this, t3);
      })), this.h.attachProtoListener("left_hand_landmarks", (t3, e3) => {
        Ic(t3, this.i.leftHandLandmarks), nu(this, e3);
      }), this.h.attachEmptyPacketListener("left_hand_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoListener("left_hand_world_landmarks", (t3, e3) => {
        var r3 = this.i.leftHandWorldLandmarks;
        t3 = Io(t3), r3.push(rh(t3)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("left_hand_world_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoListener("right_hand_landmarks", (t3, e3) => {
        Ic(t3, this.i.rightHandLandmarks), nu(this, e3);
      }), this.h.attachEmptyPacketListener("right_hand_landmarks", (t3) => {
        nu(this, t3);
      }), this.h.attachProtoListener("right_hand_world_landmarks", (t3, e3) => {
        var r3 = this.i.rightHandWorldLandmarks;
        t3 = Io(t3), r3.push(rh(t3)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("right_hand_world_landmarks", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  Fc.prototype.detectForVideo = Fc.prototype.I, Fc.prototype.detect = Fc.prototype.H, Fc.prototype.setOptions = Fc.prototype.A, Fc.createFromModelPath = function(t2, e2) {
    return ec(Fc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, Fc.createFromModelBuffer = function(t2, e2) {
    return ec(Fc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, Fc.createFromOptions = function(t2, e2) {
    return ec(Fc, t2, e2);
  }, Fc.HAND_CONNECTIONS = Ec, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.HAND_CONNECTIONS", Fc.HAND_CONNECTIONS), Fc.POSE_CONNECTIONS = Lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.POSE_CONNECTIONS", Fc.POSE_CONNECTIONS), Fc.FACE_LANDMARKS_LIPS = hc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LIPS", Fc.FACE_LANDMARKS_LIPS), Fc.FACE_LANDMARKS_LEFT_EYE = uc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYE", Fc.FACE_LANDMARKS_LEFT_EYE), Fc.FACE_LANDMARKS_LEFT_EYEBROW = cc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_EYEBROW", Fc.FACE_LANDMARKS_LEFT_EYEBROW), Fc.FACE_LANDMARKS_LEFT_IRIS = lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_LEFT_IRIS", Fc.FACE_LANDMARKS_LEFT_IRIS), Fc.FACE_LANDMARKS_RIGHT_EYE = dc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYE", Fc.FACE_LANDMARKS_RIGHT_EYE), Fc.FACE_LANDMARKS_RIGHT_EYEBROW = fc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_EYEBROW", Fc.FACE_LANDMARKS_RIGHT_EYEBROW), Fc.FACE_LANDMARKS_RIGHT_IRIS = pc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_RIGHT_IRIS", Fc.FACE_LANDMARKS_RIGHT_IRIS), Fc.FACE_LANDMARKS_FACE_OVAL = mc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_FACE_OVAL", Fc.FACE_LANDMARKS_FACE_OVAL), Fc.FACE_LANDMARKS_CONTOURS = gc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_CONTOURS", Fc.FACE_LANDMARKS_CONTOURS), Fc.FACE_LANDMARKS_TESSELATION = vc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$holistic_landmarker$holistic_landmarker.HolisticLandmarker.FACE_LANDMARKS_TESSELATION", Fc.FACE_LANDMARKS_TESSELATION);
  var Cc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "input_image", "norm_rect", true), this.m = { classifications: [] }, Rr(t2 = this.i = new La(), 0, 1, e2 = new qo());
    }
    D() {
      return "ImageClassifier";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return Rr(this.i, 0, 2, qa(t2, kr(this.i, Vo, 2))), this.l(t2);
    }
    Ha(t2, e2) {
      return this.m = { classifications: [] }, nc(this, t2, e2), this.m;
    }
    Ia(t2, e2, r2) {
      return this.m = { classifications: [] }, ic(this, t2, r2, e2), this.m;
    }
    u() {
      var t2 = new _o();
      go(t2, "input_image"), go(t2, "norm_rect"), vo(t2, "classifications");
      var e2 = new so();
      ci(e2, xa, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.image_classifier.ImageClassifierGraph"), ho(r2, "IMAGE:input_image"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "CLASSIFICATIONS:classifications"), r2.A(e2), mo(t2, r2), this.h.attachProtoListener("classifications", (t3, e3) => {
        this.m = Qa(Po(t3)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("classifications", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  Cc.prototype.classifyForVideo = Cc.prototype.Ia, Cc.prototype.classify = Cc.prototype.Ha, Cc.prototype.setOptions = Cc.prototype.A, Cc.createFromModelPath = function(t2, e2) {
    return ec(Cc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, Cc.createFromModelBuffer = function(t2, e2) {
    return ec(Cc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, Cc.createFromOptions = function(t2, e2) {
    return ec(Cc, t2, e2);
  };
  var Nc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect", true), this.i = new Ra(), this.embeddings = { embeddings: [] }, Rr(t2 = this.i, 0, 1, e2 = new qo());
    }
    D() {
      return "ImageEmbedder";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      var e2 = this.i, r2 = kr(this.i, Ko, 2);
      if (r2 = r2 ? r2.clone() : new Ko(), void 0 !== t2.l2Normalize) {
        var n2 = t2.l2Normalize;
        ar(r2, 1, null == n2 ? n2 : Zt(n2));
      } else "l2Normalize" in t2 && ar(r2, 1);
      return void 0 !== t2.quantize ? ar(r2, 2, null == (n2 = t2.quantize) ? n2 : Zt(n2)) : "quantize" in t2 && ar(r2, 2), Rr(e2, 0, 2, r2), this.l(t2);
    }
    Oa(t2, e2) {
      return nc(this, t2, e2), this.embeddings;
    }
    Pa(t2, e2, r2) {
      return ic(this, t2, r2, e2), this.embeddings;
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect"), vo(t2, "embeddings_out");
      var e2 = new so();
      ci(e2, Ia, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.image_embedder.ImageEmbedderGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "EMBEDDINGS:embeddings_out"), r2.A(e2), mo(t2, r2), this.h.attachProtoListener("embeddings_out", (t3, e3) => {
        t3 = Go(t3), this.embeddings = (function(t4) {
          return { embeddings: Lr(t4, Bo, 1).map((t5) => {
            var e4 = { headIndex: Mr(t5, 3) ?? 0 ?? -1, headName: _e(sr(t5, 4)) ?? "" ?? "" };
            if (cr(t5, 1, jo)) t5 = lr(t5 = Dr(t5, $o, 1, jo), 1, Jt), e4.floatEmbedding = t5.slice();
            else {
              let r3 = new Uint8Array(0);
              e4.quantizedEmbedding = Dr(t5, Uo, 2, jo)?.h()?.i() ?? r3;
            }
            return e4;
          }), timestampMs: Ja(sr(t4, 2, void 0, fe) ?? nr) };
        })(t3), nu(this, e3);
      }), this.h.attachEmptyPacketListener("embeddings_out", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  Nc.cosineSimilarity = function(t2, e2) {
    if (t2.floatEmbedding && e2.floatEmbedding) t2 = ih(t2.floatEmbedding, e2.floatEmbedding);
    else {
      if (!t2.quantizedEmbedding || !e2.quantizedEmbedding) throw Error("Cannot compute cosine similarity between quantized and float embeddings.");
      t2 = ih(nh(t2.quantizedEmbedding), nh(e2.quantizedEmbedding));
    }
    return t2;
  }, Nc.prototype.embedForVideo = Nc.prototype.Pa, Nc.prototype.embed = Nc.prototype.Oa, Nc.prototype.setOptions = Nc.prototype.A, Nc.createFromModelPath = function(t2, e2) {
    return ec(Nc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, Nc.createFromModelBuffer = function(t2, e2) {
    return ec(Nc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, Nc.createFromOptions = function(t2, e2) {
    return ec(Nc, t2, e2);
  };
  var Mc = class {
    constructor(t2, e2, r2) {
      this.confidenceMasks = t2, this.categoryMask = e2, this.qualityScores = r2;
    }
    close() {
      this.confidenceMasks?.forEach((t2) => {
        t2.close();
      }), this.categoryMask?.close();
    }
  };
  function Oc(t2) {
    var e2 = (function(t3) {
      return Lr(t3, co, 1);
    })(t2.ka()).filter((t3) => (_e(sr(t3, 1)) ?? "").includes("mediapipe.tasks.TensorsToSegmentationCalculator"));
    if (t2.v = [], e2.length > 1) throw Error("The graph has more than one mediapipe.tasks.TensorsToSegmentationCalculator.");
    1 === e2.length && (kr(e2[0], so, 7)?.u()?.h() ?? /* @__PURE__ */ new Map()).forEach((e3, r2) => {
      t2.v[Number(r2)] = _e(sr(e3, 1)) ?? "";
    });
  }
  function Dc(t2) {
    t2.categoryMask = void 0, t2.confidenceMasks = void 0, t2.qualityScores = void 0;
  }
  function Pc(t2) {
    try {
      let e2 = new Mc(t2.confidenceMasks, t2.categoryMask, t2.qualityScores);
      if (!t2.m) return e2;
      t2.m(e2);
    } finally {
      ou(t2);
    }
  }
  Mc.prototype.close = Mc.prototype.close;
  var $c = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect", false), this.v = [], this.outputCategoryMask = false, this.outputConfidenceMasks = true, this.i = new Oa(), this.C = new Fa(), Rr(this.i, 0, 3, this.C), Rr(t2 = this.i, 0, 1, e2 = new qo());
    }
    D() {
      return "ImageSegmenter";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return void 0 !== t2.displayNamesLocale ? ar(this.i, 2, ve(t2.displayNamesLocale)) : "displayNamesLocale" in t2 && ar(this.i, 2), "outputCategoryMask" in t2 && (this.outputCategoryMask = t2.outputCategoryMask ?? false), "outputConfidenceMasks" in t2 && (this.outputConfidenceMasks = t2.outputConfidenceMasks ?? true), super.l(t2);
    }
    M() {
      Oc(this);
    }
    segment(t2, e2, r2) {
      var n2 = "function" != typeof e2 ? e2 : {};
      return this.m = "function" == typeof e2 ? e2 : r2, Dc(this), nc(this, t2, n2), Pc(this);
    }
    fb(t2, e2, r2, n2) {
      var i2 = "function" != typeof r2 ? r2 : {};
      return this.m = "function" == typeof r2 ? r2 : n2, Dc(this), ic(this, t2, i2, e2), Pc(this);
    }
    Sa() {
      return this.v;
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect");
      var e2 = new so();
      ci(e2, Da, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.image_segmenter.ImageSegmenterGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect"), r2.A(e2), mo(t2, r2), iu(this, t2), this.outputConfidenceMasks && (vo(t2, "confidence_masks"), uo(r2, "CONFIDENCE_MASKS:confidence_masks"), su(this, "confidence_masks"), this.h.ia("confidence_masks", (t3, e3) => {
        this.confidenceMasks = t3.map((t4) => sc(this, t4, true, !this.m)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("confidence_masks", (t3) => {
        this.confidenceMasks = [], nu(this, t3);
      })), this.outputCategoryMask && (vo(t2, "category_mask"), uo(r2, "CATEGORY_MASK:category_mask"), su(this, "category_mask"), this.h.ha("category_mask", (t3, e3) => {
        this.categoryMask = sc(this, t3, false, !this.m), nu(this, e3);
      }), this.h.attachEmptyPacketListener("category_mask", (t3) => {
        this.categoryMask = void 0, nu(this, t3);
      })), vo(t2, "quality_scores"), uo(r2, "QUALITY_SCORES:quality_scores"), this.h.attachFloatVectorListener("quality_scores", (t3, e3) => {
        this.qualityScores = t3, nu(this, e3);
      }), this.h.attachEmptyPacketListener("quality_scores", (t3) => {
        this.categoryMask = void 0, nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  $c.prototype.getLabels = $c.prototype.Sa, $c.prototype.segmentForVideo = $c.prototype.fb, $c.prototype.segment = $c.prototype.segment, $c.prototype.setOptions = $c.prototype.A, $c.createFromModelPath = function(t2, e2) {
    return ec($c, t2, { baseOptions: { modelAssetPath: e2 } });
  }, $c.createFromModelBuffer = function(t2, e2) {
    return ec($c, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, $c.createFromOptions = function(t2, e2) {
    return ec($c, t2, e2);
  };
  var Uc = { 0: 0, 1: 1, 2: 2, 3: 3 };
  function Bc() {
    return Uh() ? void 0 : document.createElement("canvas");
  }
  var jc = class extends au {
    constructor(t2, e2) {
      super(new Jh(t2, e2)), this.v = new vu(), this.delegate = "CPU", this.i = 0, this.baseOptions = new qo(), this.C = this.m = 0;
    }
    D() {
      return "InteractiveSegmenter";
    }
    get j() {
      return this.h.j;
    }
    A(t2) {
      return this.delegate = t2.baseOptions?.delegate ?? "CPU", super.l(t2);
    }
    gb(t2) {
      if (0 === this.i) throw Error("Segmenter is not initialized.");
      var e2;
      if (0 !== this.m && (this.j._free(this.m), this.m = 0), !(e2 = "undefined" != typeof ImageData && t2 instanceof ImageData)) if ("object" != typeof t2 || null === t2) e2 = false;
      else {
        e2 = t2.data;
        var r2 = t2.width, n2 = t2.height;
        e2 = Number.isInteger(r2) && r2 > 0 && Number.isInteger(n2) && n2 > 0 && (e2 instanceof Uint8ClampedArray || e2 instanceof Uint8Array);
      }
      if (e2) e2 = t2.width, r2 = t2.height, t2 = t2.data;
      else {
        if ([e2, r2] = jh(t2), "undefined" != typeof OffscreenCanvas) n2 = new OffscreenCanvas(e2, r2);
        else {
          if ("undefined" == typeof document) throw Error("Canvas is not supported in this environment.");
          n2 = document.createElement("canvas");
        }
        if (n2.width = e2, n2.height = r2, !(n2 = n2.getContext("2d"))) throw Error("Canvas 2D context is not supported in this environment.");
        n2.drawImage(t2, 0, 0), t2 = n2.getImageData(0, 0, e2, r2).data;
      }
      if (!t2) throw Error("Unsupported image source or failed to extract image pixels.");
      n2 = (function({ Xa: t3, width: e3, height: r3 }) {
        if (e3 <= 0 || r3 <= 0) throw Error(`Invalid image dimensions: ${e3}x${r3}. Dimensions must be positive.`);
        if (t3 % (e3 * r3) !== 0) throw Error(`Invalid image dimensions or pixel data length. Pixel data length ${t3} is not a multiple of the number of pixels (${e3 * r3}).`);
        if (4 !== (t3 /= e3 * r3) && 3 !== t3 && 1 !== t3) throw Error(`Invalid image dimensions or pixel data length. Calculated channels: ${t3}. Expected 1, 3, or 4.`);
        return t3;
      })({ Xa: t2.length, width: e2, height: r2 });
      var i2 = this.j._malloc(t2.length);
      if (this.j.HEAPU8.set(t2, i2), this.m = i2, !this.j._interactive_segmenter_set_image(this.i, i2, e2, r2, n2)) throw Error("Failed to set image on native engine.");
    }
    segment(t2) {
      if (0 === this.i) throw Error("Segmenter is not initialized.");
      var e2 = (function(t3) {
        t3 = t3.map(({ isCompleted: t4, brushMode: e4, point: r3 }) => {
          e4 = Uc[e4] ?? 0, r3 = r3.map(({ x: t5, y: e5 }) => {
            var r4 = new Pa();
            return Gr(r4, 1, t5), Gr(r4, 2, e5), r4;
          });
          var n3 = new $a();
          return Pr(n3, t4), _r(n3, 1, ee(e4), 0), Fr(n3, 2, r3), n3;
        });
        var e3 = new Ua();
        return Fr(e3, 1, t3), Ba(e3);
      })(t2);
      t2 = this.j._malloc(e2.length), this.j.HEAPU8.set(e2, t2);
      var r2 = this.j._malloc(12), n2 = r2 + 4, i2 = r2 + 8, s2 = 0, o2 = this.C++;
      try {
        if (this.o) if ("GPU" === this.delegate) {
          var a2 = this.o;
          ++a2.h.U, a2.i.set(o2, performance.now());
        } else {
          var h2 = this.o;
          ++h2.h.R, h2.i.set(o2, performance.now());
        }
        if (0 === (s2 = this.j._interactive_segmenter_segment(this.i, t2, e2.length, r2, n2, i2))) throw Error("Segmentation failed.");
        this.o?.Aa(o2);
        let c2 = this.j.HEAPU32[r2 / 4], l2 = this.j.HEAPU32[n2 / 4], d2 = new Float32Array(this.j.HEAPU8.buffer, s2, this.j.HEAPU32[i2 / 4] / 4);
        var u2 = new Float32Array(d2);
        if (a2 = c2 * l2, (u2 instanceof Uint8Array || u2 instanceof Float32Array) && u2.length !== a2) throw Error("Unsupported channel count: " + u2.length / a2);
        return new Ru([u2], true, false, this.h.j.canvas ?? void 0, this.v, c2, l2);
      } finally {
        0 !== t2 && this.j._free(t2), 0 !== r2 && this.j._free(r2), 0 !== s2 && this.j._free(s2);
      }
    }
    u() {
      0 !== this.i && (this.o?.ya(), this.j._interactive_segmenter_close(this.i), this.i = 0), 0 !== this.m && (this.j._free(this.m), this.m = 0);
      var t2 = new Wo();
      if ("GPU" === this.delegate) {
        var e2 = new zs();
        Ir(t2, 2, zo, e2);
      } else $r(e2 = new no(), 1, 4), Ir(t2, 1, zo, e2);
      if (Rr(this.baseOptions, 0, 3, t2), t2 = Qo(this.baseOptions), e2 = this.j._malloc(t2.length), this.j.HEAPU8.set(t2, e2), this.i = this.j._interactive_segmenter_create(e2, t2.length), this.j._free(e2), 0 === this.i) throw Error("Failed to create native InteractiveSegmenter engine.");
      this.o?.za();
    }
    close() {
      0 !== this.i && (this.j._interactive_segmenter_close(this.i), this.i = 0), 0 !== this.m && (this.j._free(this.m), this.m = 0), this.v.close(), super.close();
    }
  };
  jc.prototype.close = jc.prototype.close, jc.prototype.segment = jc.prototype.segment, jc.prototype.setImage = jc.prototype.gb, jc.prototype.setOptions = jc.prototype.A, jc.createFromModelPath = function(t2, e2) {
    return Qh(jc, Bc(), t2, { baseOptions: { modelAssetPath: e2 } });
  }, jc.createFromModelBuffer = function(t2, e2) {
    return Qh(jc, Bc(), t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, jc.createFromOptions = function(t2, e2) {
    var r2 = e2.canvas ?? Bc();
    return Qh(jc, r2, t2, e2);
  };
  var Gc = class {
    constructor(t2, e2, r2) {
      this.confidenceMasks = t2, this.categoryMask = e2, this.qualityScores = r2;
    }
    close() {
      this.confidenceMasks?.forEach((t2) => {
        t2.close();
      }), this.categoryMask?.close();
    }
  };
  Gc.prototype.close = Gc.prototype.close;
  var Vc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect_in", false), this.outputCategoryMask = false, this.outputConfidenceMasks = true, this.i = new Oa(), this.v = new Fa(), Rr(this.i, 0, 3, this.v), Rr(t2 = this.i, 0, 1, e2 = new qo());
    }
    D() {
      return "InteractiveSegmenterLegacy";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return "outputCategoryMask" in t2 && (this.outputCategoryMask = t2.outputCategoryMask ?? false), "outputConfidenceMasks" in t2 && (this.outputConfidenceMasks = t2.outputConfidenceMasks ?? true), super.l(t2);
    }
    segment(t2, e2, r2, n2) {
      var i2 = "function" != typeof r2 ? r2 : {};
      if (this.m = "function" == typeof r2 ? r2 : n2, this.qualityScores = this.categoryMask = this.confidenceMasks = void 0, r2 = this.J + 1, n2 = new Ha(), e2.keypoint && e2.scribble) throw Error("Cannot provide both keypoint and scribble.");
      if (e2.keypoint) {
        var s2 = new ja();
        Pr(s2, true), Gr(s2, 1, e2.keypoint.x), Gr(s2, 2, e2.keypoint.y), Ir(n2, 1, Ka, s2);
      } else {
        if (!e2.scribble) throw Error("Must provide either a keypoint or a scribble.");
        {
          let t3 = new Va();
          for (s2 of e2.scribble) Pr(e2 = new ja(), true), Gr(e2, 1, s2.x), Gr(e2, 2, s2.y), Nr(t3, 1, ja, e2);
          Ir(n2, 2, Ka, t3);
        }
      }
      this.h.addProtoToStream(n2.h(), "mediapipe.tasks.vision.interactive_segmenter_legacy.proto.RegionOfInterest", "roi_in", r2), nc(this, t2, i2);
      t: {
        try {
          let t3 = new Gc(this.confidenceMasks, this.categoryMask, this.qualityScores);
          if (!this.m) {
            var o2 = t3;
            break t;
          }
          this.m(t3);
        } finally {
          ou(this);
        }
        o2 = void 0;
      }
      return o2;
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "roi_in"), go(t2, "norm_rect_in");
      var e2 = new so();
      ci(e2, Da, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.interactive_segmenter_legacy.InteractiveSegmenterLegacyGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "ROI:roi_in"), ho(r2, "NORM_RECT:norm_rect_in"), r2.A(e2), mo(t2, r2), iu(this, t2), this.outputConfidenceMasks && (vo(t2, "confidence_masks"), uo(r2, "CONFIDENCE_MASKS:confidence_masks"), su(this, "confidence_masks"), this.h.ia("confidence_masks", (t3, e3) => {
        this.confidenceMasks = t3.map((t4) => sc(this, t4, true, !this.m)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("confidence_masks", (t3) => {
        this.confidenceMasks = [], nu(this, t3);
      })), this.outputCategoryMask && (vo(t2, "category_mask"), uo(r2, "CATEGORY_MASK:category_mask"), su(this, "category_mask"), this.h.ha("category_mask", (t3, e3) => {
        this.categoryMask = sc(this, t3, false, !this.m), nu(this, e3);
      }), this.h.attachEmptyPacketListener("category_mask", (t3) => {
        this.categoryMask = void 0, nu(this, t3);
      })), vo(t2, "quality_scores"), uo(r2, "QUALITY_SCORES:quality_scores"), this.h.attachFloatVectorListener("quality_scores", (t3, e3) => {
        this.qualityScores = t3, nu(this, e3);
      }), this.h.attachEmptyPacketListener("quality_scores", (t3) => {
        this.categoryMask = void 0, nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  Vc.prototype.segment = Vc.prototype.segment, Vc.prototype.setOptions = Vc.prototype.A, Vc.createFromModelPath = function(t2, e2) {
    return ec(Vc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, Vc.createFromModelBuffer = function(t2, e2) {
    return ec(Vc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, Vc.createFromOptions = function(t2, e2) {
    return ec(Vc, t2, e2);
  };
  var Hc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "input_frame_gpu", "norm_rect", false), this.m = { detections: [] }, Rr(t2 = this.i = new Xa(), 0, 1, e2 = new qo());
    }
    D() {
      return "ObjectDetector";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return void 0 !== t2.displayNamesLocale ? ar(this.i, 2, ve(t2.displayNamesLocale)) : "displayNamesLocale" in t2 && ar(this.i, 2), void 0 !== t2.maxResults ? $r(this.i, 3, t2.maxResults) : "maxResults" in t2 && ar(this.i, 3), void 0 !== t2.scoreThreshold ? jr(this.i, 4, t2.scoreThreshold) : "scoreThreshold" in t2 && ar(this.i, 4), void 0 !== t2.categoryAllowlist ? Hr(this.i, 5, t2.categoryAllowlist) : "categoryAllowlist" in t2 && ar(this.i, 5), void 0 !== t2.categoryDenylist ? Hr(this.i, 6, t2.categoryDenylist) : "categoryDenylist" in t2 && ar(this.i, 6), this.l(t2);
    }
    H(t2, e2) {
      return this.m = { detections: [] }, nc(this, t2, e2), this.m;
    }
    I(t2, e2, r2) {
      return this.m = { detections: [] }, ic(this, t2, r2, e2), this.m;
    }
    u() {
      var t2 = new _o();
      go(t2, "input_frame_gpu"), go(t2, "norm_rect"), vo(t2, "detections");
      var e2 = new so();
      ci(e2, Wa, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.ObjectDetectorGraph"), ho(r2, "IMAGE:input_frame_gpu"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "DETECTIONS:detections"), r2.A(e2), mo(t2, r2), this.h.attachProtoVectorListener("detections", (t3, e3) => {
        for (let e4 of t3) t3 = xo(e4), this.m.detections.push(th(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("detections", (t3) => {
        nu(this, t3);
      }), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  Hc.prototype.detectForVideo = Hc.prototype.I, Hc.prototype.detect = Hc.prototype.H, Hc.prototype.setOptions = Hc.prototype.A, Hc.createFromModelPath = async function(t2, e2) {
    return ec(Hc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, Hc.createFromModelBuffer = function(t2, e2) {
    return ec(Hc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, Hc.createFromOptions = function(t2, e2) {
    return ec(Hc, t2, e2);
  };
  var Kc = class {
    constructor(t2, e2, r2) {
      this.landmarks = t2, this.worldLandmarks = e2, this.segmentationMasks = r2;
    }
    close() {
      this.segmentationMasks?.forEach((t2) => {
        t2.close();
      });
    }
  };
  function Xc(t2) {
    t2.landmarks = [], t2.worldLandmarks = [], t2.segmentationMasks = void 0;
  }
  function Wc(t2) {
    try {
      let e2 = new Kc(t2.landmarks, t2.worldLandmarks, t2.segmentationMasks);
      if (!t2.v) return e2;
      t2.v(e2);
    } finally {
      ou(t2);
    }
  }
  Kc.prototype.close = Kc.prototype.close;
  var zc = class extends oc {
    constructor(t2, e2) {
      super(new tc(t2, e2), "image_in", "norm_rect", false), this.landmarks = [], this.worldLandmarks = [], this.outputSegmentationMasks = false, Rr(t2 = this.i = new za(), 0, 1, e2 = new qo()), this.C = new Ta(), Rr(this.i, 0, 3, this.C), this.m = new wa(), Rr(this.i, 0, 2, this.m), $r(this.m, 4, 1), jr(this.m, 2, 0.5), jr(this.C, 2, 0.5), jr(this.i, 4, 0.5);
    }
    D() {
      return "PoseLandmarker";
    }
    get baseOptions() {
      return kr(this.i, qo, 1);
    }
    set baseOptions(t2) {
      Rr(this.i, 0, 1, t2);
    }
    A(t2) {
      return "numPoses" in t2 && $r(this.m, 4, t2.numPoses ?? 1), "minPoseDetectionConfidence" in t2 && jr(this.m, 2, t2.minPoseDetectionConfidence ?? 0.5), "minTrackingConfidence" in t2 && jr(this.i, 4, t2.minTrackingConfidence ?? 0.5), "minPosePresenceConfidence" in t2 && jr(this.C, 2, t2.minPosePresenceConfidence ?? 0.5), "outputSegmentationMasks" in t2 && (this.outputSegmentationMasks = t2.outputSegmentationMasks ?? false), this.l(t2);
    }
    H(t2, e2, r2) {
      var n2 = "function" != typeof e2 ? e2 : {};
      return this.v = "function" == typeof e2 ? e2 : r2, Xc(this), nc(this, t2, n2), Wc(this);
    }
    I(t2, e2, r2, n2) {
      var i2 = "function" != typeof r2 ? r2 : {};
      return this.v = "function" == typeof r2 ? r2 : n2, Xc(this), ic(this, t2, i2, e2), Wc(this);
    }
    u() {
      var t2 = new _o();
      go(t2, "image_in"), go(t2, "norm_rect"), vo(t2, "normalized_landmarks"), vo(t2, "world_landmarks"), vo(t2, "segmentation_masks");
      var e2 = new so();
      ci(e2, Ya, this.i);
      var r2 = new co();
      Vr(r2, 2, "mediapipe.tasks.vision.pose_landmarker.PoseLandmarkerGraph"), ho(r2, "IMAGE:image_in"), ho(r2, "NORM_RECT:norm_rect"), uo(r2, "NORM_LANDMARKS:normalized_landmarks"), uo(r2, "WORLD_LANDMARKS:world_landmarks"), r2.A(e2), mo(t2, r2), iu(this, t2), this.h.attachProtoVectorListener("normalized_landmarks", (t3, e3) => {
        this.landmarks = [];
        for (let e4 of t3) t3 = Co(e4), this.landmarks.push(eh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("normalized_landmarks", (t3) => {
        this.landmarks = [], nu(this, t3);
      }), this.h.attachProtoVectorListener("world_landmarks", (t3, e3) => {
        this.worldLandmarks = [];
        for (let e4 of t3) t3 = Io(e4), this.worldLandmarks.push(rh(t3));
        nu(this, e3);
      }), this.h.attachEmptyPacketListener("world_landmarks", (t3) => {
        this.worldLandmarks = [], nu(this, t3);
      }), this.outputSegmentationMasks && (uo(r2, "SEGMENTATION_MASK:segmentation_masks"), su(this, "segmentation_masks"), this.h.ia("segmentation_masks", (t3, e3) => {
        this.segmentationMasks = t3.map((t4) => sc(this, t4, true, !this.v)), nu(this, e3);
      }), this.h.attachEmptyPacketListener("segmentation_masks", (t3) => {
        this.segmentationMasks = [], nu(this, t3);
      })), t2 = t2.h(), this.setGraph(new Uint8Array(t2), true);
    }
  };
  zc.prototype.detectForVideo = zc.prototype.I, zc.prototype.detect = zc.prototype.H, zc.prototype.setOptions = zc.prototype.A, zc.createFromModelPath = function(t2, e2) {
    return ec(zc, t2, { baseOptions: { modelAssetPath: e2 } });
  }, zc.createFromModelBuffer = function(t2, e2) {
    return ec(zc, t2, { baseOptions: { modelAssetBuffer: e2 } });
  }, zc.createFromOptions = function(t2, e2) {
    return ec(zc, t2, e2);
  }, zc.POSE_CONNECTIONS = Lc, r("module$exports$google3$third_party$mediapipe$tasks$web$vision$pose_landmarker$pose_landmarker.PoseLandmarker.POSE_CONNECTIONS", zc.POSE_CONNECTIONS);

  // node_modules/onnxruntime-web/dist/ort.wasm.bundle.min.mjs
  var import_meta = {};
  var qt2 = Object.defineProperty;
  var Qa2 = Object.getOwnPropertyDescriptor;
  var Ka2 = Object.getOwnPropertyNames;
  var es2 = Object.prototype.hasOwnProperty;
  var Jt2 = ((n2) => typeof __require < "u" ? __require : typeof Proxy < "u" ? new Proxy(n2, { get: (t2, a2) => (typeof __require < "u" ? __require : t2)[a2] }) : n2)(function(n2) {
    if (typeof __require < "u") return __require.apply(this, arguments);
    throw Error('Dynamic require of "' + n2 + '" is not supported');
  });
  var N2 = (n2, t2, a2) => () => {
    if (a2) throw a2[0];
    try {
      return n2 && (t2 = n2(n2 = 0)), t2;
    } catch (u2) {
      throw a2 = [u2], u2;
    }
  };
  var ut2 = (n2, t2) => {
    for (var a2 in t2) qt2(n2, a2, { get: t2[a2], enumerable: true });
  };
  var ts2 = (n2, t2, a2, u2) => {
    if (t2 && typeof t2 == "object" || typeof t2 == "function") for (let o2 of Ka2(t2)) !es2.call(n2, o2) && o2 !== a2 && qt2(n2, o2, { get: () => t2[o2], enumerable: !(u2 = Qa2(t2, o2)) || u2.enumerable });
    return n2;
  };
  var Xt2 = (n2) => ts2(qt2({}, "__esModule", { value: true }), n2);
  var ft2;
  var Be2;
  var Je2;
  var ns2;
  var pr2;
  var Zt2 = N2(() => {
    "use strict";
    ft2 = /* @__PURE__ */ new Map(), Be2 = [], Je2 = (n2, t2, a2) => {
      if (t2 && typeof t2.init == "function" && typeof t2.createInferenceSessionHandler == "function") {
        let u2 = ft2.get(n2);
        if (u2 === void 0) ft2.set(n2, { backend: t2, priority: a2 });
        else {
          if (u2.priority > a2) return;
          if (u2.priority === a2 && u2.backend !== t2) throw new Error(`cannot register backend "${n2}" using priority ${a2}`);
        }
        if (a2 >= 0) {
          let o2 = Be2.indexOf(n2);
          o2 !== -1 && Be2.splice(o2, 1);
          for (let d2 = 0; d2 < Be2.length; d2++) if (ft2.get(Be2[d2]).priority <= a2) {
            Be2.splice(d2, 0, n2);
            return;
          }
          Be2.push(n2);
        }
        return;
      }
      throw new TypeError("not a valid backend");
    }, ns2 = async (n2) => {
      let t2 = ft2.get(n2);
      if (!t2) return "backend not found.";
      if (t2.initialized) return t2.backend;
      if (t2.aborted) return t2.error;
      {
        let a2 = !!t2.initPromise;
        try {
          return a2 || (t2.initPromise = t2.backend.init(n2)), await t2.initPromise, t2.initialized = true, t2.backend;
        } catch (u2) {
          return a2 || (t2.error = `${u2}`, t2.aborted = true), t2.error;
        } finally {
          delete t2.initPromise;
        }
      }
    }, pr2 = async (n2) => {
      let t2 = n2.executionProviders || [], a2 = t2.map((m2) => typeof m2 == "string" ? m2 : m2.name), u2 = a2.length === 0 ? Be2 : a2, o2, d2 = [], c2 = /* @__PURE__ */ new Set();
      for (let m2 of u2) {
        let h2 = await ns2(m2);
        typeof h2 == "string" ? d2.push({ name: m2, err: h2 }) : (o2 || (o2 = h2), o2 === h2 && c2.add(m2));
      }
      if (!o2) throw new Error(`no available backend found. ERR: ${d2.map((m2) => `[${m2.name}] ${m2.err}`).join(", ")}`);
      for (let { name: m2, err: h2 } of d2) a2.includes(m2) && console.warn(`removing requested execution provider "${m2}" from session options because it is not available: ${h2}`);
      let l2 = t2.filter((m2) => c2.has(typeof m2 == "string" ? m2 : m2.name));
      return [o2, new Proxy(n2, { get: (m2, h2) => h2 === "executionProviders" ? l2 : Reflect.get(m2, h2) })];
    };
  });
  var mr2 = N2(() => {
    "use strict";
    Zt2();
  });
  var hr2;
  var wr2 = N2(() => {
    "use strict";
    hr2 = "1.30.0";
  });
  var br2;
  var q2;
  var Qt2 = N2(() => {
    "use strict";
    wr2();
    br2 = "warning", q2 = { wasm: {}, webgl: {}, webgpu: {}, versions: { common: hr2 }, set logLevel(n2) {
      if (n2 !== void 0) {
        if (typeof n2 != "string" || ["verbose", "info", "warning", "error", "fatal"].indexOf(n2) === -1) throw new Error(`Unsupported logging level: ${n2}`);
        br2 = n2;
      }
    }, get logLevel() {
      return br2;
    } };
    Object.defineProperty(q2, "logLevel", { enumerable: true });
  });
  var Y2;
  var yr2 = N2(() => {
    "use strict";
    Qt2();
    Y2 = q2;
  });
  var gr2;
  var Er2;
  var Tr2 = N2(() => {
    "use strict";
    gr2 = (n2, t2) => {
      let a2 = typeof document < "u" ? document.createElement("canvas") : new OffscreenCanvas(1, 1);
      a2.width = n2.dims[3], a2.height = n2.dims[2];
      let u2 = a2.getContext("2d");
      if (u2 != null) {
        let o2, d2;
        t2?.tensorLayout !== void 0 && t2.tensorLayout === "NHWC" ? (o2 = n2.dims[2], d2 = n2.dims[3]) : (o2 = n2.dims[3], d2 = n2.dims[2]);
        let c2 = t2?.format !== void 0 ? t2.format : "RGB", l2 = t2?.norm, m2, h2;
        l2 === void 0 || l2.mean === void 0 ? m2 = [255, 255, 255, 255] : typeof l2.mean == "number" ? m2 = [l2.mean, l2.mean, l2.mean, l2.mean] : (m2 = [l2.mean[0], l2.mean[1], l2.mean[2], 0], l2.mean[3] !== void 0 && (m2[3] = l2.mean[3])), l2 === void 0 || l2.bias === void 0 ? h2 = [0, 0, 0, 0] : typeof l2.bias == "number" ? h2 = [l2.bias, l2.bias, l2.bias, l2.bias] : (h2 = [l2.bias[0], l2.bias[1], l2.bias[2], 0], l2.bias[3] !== void 0 && (h2[3] = l2.bias[3]));
        let g2 = d2 * o2, b2 = 0, y3 = g2, T2 = g2 * 2, I2 = -1;
        c2 === "RGBA" ? (b2 = 0, y3 = g2, T2 = g2 * 2, I2 = g2 * 3) : c2 === "RGB" ? (b2 = 0, y3 = g2, T2 = g2 * 2) : c2 === "RBG" && (b2 = 0, T2 = g2, y3 = g2 * 2);
        for (let D2 = 0; D2 < d2; D2++) for (let $2 = 0; $2 < o2; $2++) {
          let v2 = (n2.data[b2++] - h2[0]) * m2[0], A2 = (n2.data[y3++] - h2[1]) * m2[1], F2 = (n2.data[T2++] - h2[2]) * m2[2], P2 = I2 === -1 ? 255 : (n2.data[I2++] - h2[3]) * m2[3];
          u2.fillStyle = "rgba(" + v2 + "," + A2 + "," + F2 + "," + P2 + ")", u2.fillRect($2, D2, 1, 1);
        }
        if ("toDataURL" in a2) return a2.toDataURL();
        throw new Error("toDataURL is not supported");
      } else throw new Error("Can not access image data");
    }, Er2 = (n2, t2) => {
      let a2 = typeof document < "u" ? document.createElement("canvas").getContext("2d") : new OffscreenCanvas(1, 1).getContext("2d"), u2;
      if (a2 != null) {
        let o2, d2, c2;
        t2?.tensorLayout !== void 0 && t2.tensorLayout === "NHWC" ? (o2 = n2.dims[2], d2 = n2.dims[1], c2 = n2.dims[3]) : (o2 = n2.dims[3], d2 = n2.dims[2], c2 = n2.dims[1]);
        let l2 = t2 !== void 0 && t2.format !== void 0 ? t2.format : "RGB", m2 = t2?.norm, h2, g2;
        m2 === void 0 || m2.mean === void 0 ? h2 = [255, 255, 255, 255] : typeof m2.mean == "number" ? h2 = [m2.mean, m2.mean, m2.mean, m2.mean] : (h2 = [m2.mean[0], m2.mean[1], m2.mean[2], 255], m2.mean[3] !== void 0 && (h2[3] = m2.mean[3])), m2 === void 0 || m2.bias === void 0 ? g2 = [0, 0, 0, 0] : typeof m2.bias == "number" ? g2 = [m2.bias, m2.bias, m2.bias, m2.bias] : (g2 = [m2.bias[0], m2.bias[1], m2.bias[2], 0], m2.bias[3] !== void 0 && (g2[3] = m2.bias[3]));
        let b2 = d2 * o2;
        if (t2 !== void 0 && (t2.format !== void 0 && c2 === 4 && t2.format !== "RGBA" || c2 === 3 && t2.format !== "RGB" && t2.format !== "BGR")) throw new Error("Tensor format doesn't match input tensor dims");
        let y3 = 4, T2 = 0, I2 = 1, D2 = 2, $2 = 3, v2 = 0, A2 = b2, F2 = b2 * 2, P2 = -1;
        l2 === "RGBA" ? (v2 = 0, A2 = b2, F2 = b2 * 2, P2 = b2 * 3) : l2 === "RGB" ? (v2 = 0, A2 = b2, F2 = b2 * 2) : l2 === "RBG" && (v2 = 0, F2 = b2, A2 = b2 * 2), u2 = a2.createImageData(o2, d2);
        for (let k2 = 0; k2 < d2 * o2; T2 += y3, I2 += y3, D2 += y3, $2 += y3, k2++) u2.data[T2] = (n2.data[v2++] - g2[0]) * h2[0], u2.data[I2] = (n2.data[A2++] - g2[1]) * h2[1], u2.data[D2] = (n2.data[F2++] - g2[2]) * h2[2], u2.data[$2] = P2 === -1 ? 255 : (n2.data[P2++] - g2[3]) * h2[3];
      } else throw new Error("Can not access image data");
      return u2;
    };
  });
  var Kt2;
  var Sr2;
  var vr2;
  var Ar2;
  var Or2;
  var Ir2;
  var Br2 = N2(() => {
    "use strict";
    ct2();
    Kt2 = (n2, t2) => {
      if (n2 === void 0) throw new Error("Image buffer must be defined");
      if (t2.height === void 0 || t2.width === void 0) throw new Error("Image height and width must be defined");
      if (t2.tensorLayout === "NHWC") throw new Error("NHWC Tensor layout is not supported yet");
      let { height: a2, width: u2 } = t2, o2 = t2.norm ?? { mean: 255, bias: 0 }, d2, c2;
      typeof o2.mean == "number" ? d2 = [o2.mean, o2.mean, o2.mean, o2.mean] : d2 = [o2.mean[0], o2.mean[1], o2.mean[2], o2.mean[3] ?? 255], typeof o2.bias == "number" ? c2 = [o2.bias, o2.bias, o2.bias, o2.bias] : c2 = [o2.bias[0], o2.bias[1], o2.bias[2], o2.bias[3] ?? 0];
      let l2 = t2.format !== void 0 ? t2.format : "RGBA", m2 = t2.tensorFormat !== void 0 && t2.tensorFormat !== void 0 ? t2.tensorFormat : "RGB", h2 = a2 * u2, g2 = m2 === "RGBA" ? new Float32Array(h2 * 4) : new Float32Array(h2 * 3), b2 = 4, y3 = 0, T2 = 1, I2 = 2, D2 = 3, $2 = 0, v2 = h2, A2 = h2 * 2, F2 = -1;
      l2 === "RGB" && (b2 = 3, y3 = 0, T2 = 1, I2 = 2, D2 = -1), m2 === "RGBA" ? F2 = h2 * 3 : m2 === "RBG" ? ($2 = 0, A2 = h2, v2 = h2 * 2) : m2 === "BGR" && (A2 = 0, v2 = h2, $2 = h2 * 2);
      for (let k2 = 0; k2 < h2; k2++, y3 += b2, I2 += b2, T2 += b2, D2 += b2) g2[$2++] = (n2[y3] + c2[0]) / d2[0], g2[v2++] = (n2[T2] + c2[1]) / d2[1], g2[A2++] = (n2[I2] + c2[2]) / d2[2], F2 !== -1 && D2 !== -1 && (g2[F2++] = (n2[D2] + c2[3]) / d2[3]);
      return m2 === "RGBA" ? new Z2("float32", g2, [1, 4, a2, u2]) : new Z2("float32", g2, [1, 3, a2, u2]);
    }, Sr2 = async (n2, t2) => {
      let a2 = typeof HTMLImageElement < "u" && n2 instanceof HTMLImageElement, u2 = typeof ImageData < "u" && n2 instanceof ImageData, o2 = typeof ImageBitmap < "u" && n2 instanceof ImageBitmap, d2 = typeof n2 == "string", c2, l2 = t2 ?? {}, m2 = () => {
        if (typeof document < "u") return document.createElement("canvas");
        if (typeof OffscreenCanvas < "u") return new OffscreenCanvas(1, 1);
        throw new Error("Canvas is not supported");
      }, h2 = (g2) => typeof HTMLCanvasElement < "u" && g2 instanceof HTMLCanvasElement || g2 instanceof OffscreenCanvas ? g2.getContext("2d") : null;
      if (a2) {
        let g2 = m2();
        g2.width = n2.width, g2.height = n2.height;
        let b2 = h2(g2);
        if (b2 != null) {
          let y3 = n2.height, T2 = n2.width;
          if (t2 !== void 0 && t2.resizedHeight !== void 0 && t2.resizedWidth !== void 0 && (y3 = t2.resizedHeight, T2 = t2.resizedWidth), t2 !== void 0) {
            if (l2 = t2, t2.tensorFormat !== void 0) throw new Error("Image input config format must be RGBA for HTMLImageElement");
            l2.tensorFormat = "RGBA", l2.height = y3, l2.width = T2;
          } else l2.tensorFormat = "RGBA", l2.height = y3, l2.width = T2;
          b2.drawImage(n2, 0, 0), c2 = b2.getImageData(0, 0, T2, y3).data;
        } else throw new Error("Can not access image data");
      } else if (u2) {
        let g2, b2;
        if (t2 !== void 0 && t2.resizedWidth !== void 0 && t2.resizedHeight !== void 0 ? (g2 = t2.resizedHeight, b2 = t2.resizedWidth) : (g2 = n2.height, b2 = n2.width), t2 !== void 0 && (l2 = t2), l2.format = "RGBA", l2.height = g2, l2.width = b2, t2 !== void 0) {
          let y3 = m2();
          y3.width = b2, y3.height = g2;
          let T2 = h2(y3);
          if (T2 != null) T2.putImageData(n2, 0, 0), c2 = T2.getImageData(0, 0, b2, g2).data;
          else throw new Error("Can not access image data");
        } else c2 = n2.data;
      } else if (o2) {
        if (t2 === void 0) throw new Error("Please provide image config with format for Imagebitmap");
        let g2 = m2();
        g2.width = n2.width, g2.height = n2.height;
        let b2 = h2(g2);
        if (b2 != null) {
          let y3 = n2.height, T2 = n2.width;
          return b2.drawImage(n2, 0, 0, T2, y3), c2 = b2.getImageData(0, 0, T2, y3).data, l2.height = y3, l2.width = T2, Kt2(c2, l2);
        } else throw new Error("Can not access image data");
      } else {
        if (d2) return new Promise((g2, b2) => {
          let y3 = m2(), T2 = h2(y3);
          if (!n2 || !T2) return b2();
          let I2 = new Image();
          I2.crossOrigin = "Anonymous", I2.src = n2, I2.onload = () => {
            y3.width = I2.width, y3.height = I2.height, T2.drawImage(I2, 0, 0, y3.width, y3.height);
            let D2 = T2.getImageData(0, 0, y3.width, y3.height);
            l2.height = y3.height, l2.width = y3.width, g2(Kt2(D2.data, l2));
          };
        });
        throw new Error("Input data provided is not supported - aborted tensor creation");
      }
      if (c2 !== void 0) return Kt2(c2, l2);
      throw new Error("Input data provided is not supported - aborted tensor creation");
    }, vr2 = (n2, t2) => {
      let { width: a2, height: u2, download: o2, dispose: d2 } = t2, c2 = [1, u2, a2, 4];
      return new Z2({ location: "texture", type: "float32", texture: n2, dims: c2, download: o2, dispose: d2 });
    }, Ar2 = (n2, t2) => {
      let { dataType: a2, dims: u2, download: o2, dispose: d2 } = t2;
      return new Z2({ location: "gpu-buffer", type: a2 ?? "float32", gpuBuffer: n2, dims: u2, download: o2, dispose: d2 });
    }, Or2 = (n2, t2) => {
      let { dataType: a2, dims: u2, download: o2, dispose: d2 } = t2;
      return new Z2({ location: "ml-tensor", type: a2 ?? "float32", mlTensor: n2, dims: u2, download: o2, dispose: d2 });
    }, Ir2 = (n2, t2, a2) => new Z2({ location: "cpu-pinned", type: n2, data: t2, dims: a2 ?? [t2.length] });
  });
  var Le2;
  var Xe2;
  var Lr2;
  var _r2;
  var Dr2 = N2(() => {
    "use strict";
    Le2 = /* @__PURE__ */ new Map([["float32", Float32Array], ["uint8", Uint8Array], ["int8", Int8Array], ["uint16", Uint16Array], ["int16", Int16Array], ["int32", Int32Array], ["bool", Uint8Array], ["float64", Float64Array], ["uint32", Uint32Array], ["int4", Uint8Array], ["uint4", Uint8Array]]), Xe2 = /* @__PURE__ */ new Map([[Float32Array, "float32"], [Uint8Array, "uint8"], [Int8Array, "int8"], [Uint16Array, "uint16"], [Int16Array, "int16"], [Int32Array, "int32"], [Float64Array, "float64"], [Uint32Array, "uint32"]]), Lr2 = false, _r2 = () => {
      if (!Lr2) {
        Lr2 = true;
        let n2 = typeof BigInt64Array < "u" && BigInt64Array.from, t2 = typeof BigUint64Array < "u" && BigUint64Array.from, a2 = globalThis.Float16Array, u2 = typeof a2 < "u" && a2.from;
        n2 && (Le2.set("int64", BigInt64Array), Xe2.set(BigInt64Array, "int64")), t2 && (Le2.set("uint64", BigUint64Array), Xe2.set(BigUint64Array, "uint64")), u2 ? (Le2.set("float16", a2), Xe2.set(a2, "float16")) : Le2.set("float16", Uint16Array);
      }
    };
  });
  var Pr2;
  var Ur2;
  var xr2 = N2(() => {
    "use strict";
    ct2();
    Pr2 = (n2) => {
      let t2 = 1;
      for (let a2 = 0; a2 < n2.length; a2++) {
        let u2 = n2[a2];
        if (typeof u2 != "number" || !Number.isSafeInteger(u2)) throw new TypeError(`dims[${a2}] must be an integer, got: ${u2}`);
        if (u2 < 0) throw new RangeError(`dims[${a2}] must be a non-negative integer, got: ${u2}`);
        t2 *= u2;
      }
      return t2;
    }, Ur2 = (n2, t2) => {
      switch (n2.location) {
        case "cpu":
          return new Z2(n2.type, n2.data, t2);
        case "cpu-pinned":
          return new Z2({ location: "cpu-pinned", data: n2.data, type: n2.type, dims: t2 });
        case "texture":
          return new Z2({ location: "texture", texture: n2.texture, type: n2.type, dims: t2 });
        case "gpu-buffer":
          return new Z2({ location: "gpu-buffer", gpuBuffer: n2.gpuBuffer, type: n2.type, dims: t2 });
        case "ml-tensor":
          return new Z2({ location: "ml-tensor", mlTensor: n2.mlTensor, type: n2.type, dims: t2 });
        default:
          throw new Error(`tensorReshape: tensor location ${n2.location} is not supported`);
      }
    };
  });
  var Z2;
  var ct2 = N2(() => {
    "use strict";
    Tr2();
    Br2();
    Dr2();
    xr2();
    Z2 = class {
      constructor(t2, a2, u2) {
        _r2();
        let o2, d2;
        if (typeof t2 == "object" && "location" in t2) switch (this.dataLocation = t2.location, o2 = t2.type, d2 = t2.dims, t2.location) {
          case "cpu-pinned": {
            let l2 = Le2.get(o2);
            if (!l2) throw new TypeError(`unsupported type "${o2}" to create tensor from pinned buffer`);
            if (!(t2.data instanceof l2)) throw new TypeError(`buffer should be of type ${l2.name}`);
            this.cpuData = t2.data;
            break;
          }
          case "texture": {
            if (o2 !== "float32") throw new TypeError(`unsupported type "${o2}" to create tensor from texture`);
            this.gpuTextureData = t2.texture, this.downloader = t2.download, this.disposer = t2.dispose;
            break;
          }
          case "gpu-buffer": {
            if (o2 !== "float32" && o2 !== "float16" && o2 !== "int32" && o2 !== "int64" && o2 !== "uint32" && o2 !== "uint8" && o2 !== "bool" && o2 !== "uint4" && o2 !== "int4") throw new TypeError(`unsupported type "${o2}" to create tensor from gpu buffer`);
            this.gpuBufferData = t2.gpuBuffer, this.downloader = t2.download, this.disposer = t2.dispose;
            break;
          }
          case "ml-tensor": {
            if (o2 !== "float32" && o2 !== "float16" && o2 !== "int32" && o2 !== "int64" && o2 !== "uint32" && o2 !== "uint64" && o2 !== "int8" && o2 !== "uint8" && o2 !== "bool" && o2 !== "uint4" && o2 !== "int4") throw new TypeError(`unsupported type "${o2}" to create tensor from MLTensor`);
            this.mlTensorData = t2.mlTensor, this.downloader = t2.download, this.disposer = t2.dispose;
            break;
          }
          default:
            throw new Error(`Tensor constructor: unsupported location '${this.dataLocation}'`);
        }
        else {
          let l2, m2;
          if (typeof t2 == "string") if (o2 = t2, m2 = u2, t2 === "string") {
            if (!Array.isArray(a2)) throw new TypeError("A string tensor's data must be a string array.");
            l2 = a2;
          } else {
            let h2 = Le2.get(t2);
            if (h2 === void 0) throw new TypeError(`Unsupported tensor type: ${t2}.`);
            if (Array.isArray(a2)) {
              if (t2 === "float16" && h2 === Uint16Array || t2 === "uint4" || t2 === "int4") throw new TypeError(`Creating a ${t2} tensor from number array is not supported. Please use ${h2.name} as data.`);
              t2 === "uint64" || t2 === "int64" ? l2 = h2.from(a2, BigInt) : l2 = h2.from(a2);
            } else if (a2 instanceof h2) l2 = a2;
            else if (a2 instanceof Uint8ClampedArray) if (t2 === "uint8") l2 = Uint8Array.from(a2);
            else throw new TypeError("A Uint8ClampedArray tensor's data must be type of uint8");
            else if (t2 === "float16" && a2 instanceof Uint16Array && h2 !== Uint16Array) l2 = new globalThis.Float16Array(a2.buffer, a2.byteOffset, a2.length);
            else throw new TypeError(`A ${o2} tensor's data must be type of ${h2}`);
          }
          else if (m2 = a2, Array.isArray(t2)) {
            if (t2.length === 0) throw new TypeError("Tensor type cannot be inferred from an empty array.");
            let h2 = typeof t2[0];
            if (h2 === "string") o2 = "string", l2 = t2;
            else if (h2 === "boolean") o2 = "bool", l2 = Uint8Array.from(t2);
            else throw new TypeError(`Invalid element type of data array: ${h2}.`);
          } else if (t2 instanceof Uint8ClampedArray) o2 = "uint8", l2 = Uint8Array.from(t2);
          else {
            let h2 = Xe2.get(t2.constructor);
            if (h2 === void 0) throw new TypeError(`Unsupported type for tensor data: ${t2.constructor}.`);
            o2 = h2, l2 = t2;
          }
          if (m2 === void 0) m2 = [l2.length];
          else if (!Array.isArray(m2)) throw new TypeError("A tensor's dims must be a number array");
          d2 = m2, this.cpuData = l2, this.dataLocation = "cpu";
        }
        let c2 = Pr2(d2);
        if (this.cpuData && c2 !== this.cpuData.length && !((o2 === "uint4" || o2 === "int4") && Math.ceil(c2 / 2) === this.cpuData.length)) throw new Error(`Tensor's size(${c2}) does not match data length(${this.cpuData.length}).`);
        this.type = o2, this.dims = d2, this.size = c2;
      }
      static async fromImage(t2, a2) {
        return Sr2(t2, a2);
      }
      static fromTexture(t2, a2) {
        return vr2(t2, a2);
      }
      static fromGpuBuffer(t2, a2) {
        return Ar2(t2, a2);
      }
      static fromMLTensor(t2, a2) {
        return Or2(t2, a2);
      }
      static fromPinnedBuffer(t2, a2, u2) {
        return Ir2(t2, a2, u2);
      }
      toDataURL(t2) {
        return gr2(this, t2);
      }
      toImageData(t2) {
        return Er2(this, t2);
      }
      get data() {
        if (this.ensureValid(), !this.cpuData) throw new Error("The data is not on CPU. Use `getData()` to download GPU data to CPU, or use `texture` or `gpuBuffer` property to access the GPU data directly.");
        return this.cpuData;
      }
      get location() {
        return this.dataLocation;
      }
      get texture() {
        if (this.ensureValid(), !this.gpuTextureData) throw new Error("The data is not stored as a WebGL texture.");
        return this.gpuTextureData;
      }
      get gpuBuffer() {
        if (this.ensureValid(), !this.gpuBufferData) throw new Error("The data is not stored as a WebGPU buffer.");
        return this.gpuBufferData;
      }
      get mlTensor() {
        if (this.ensureValid(), !this.mlTensorData) throw new Error("The data is not stored as a WebNN MLTensor.");
        return this.mlTensorData;
      }
      async getData(t2) {
        switch (this.ensureValid(), this.dataLocation) {
          case "cpu":
          case "cpu-pinned":
            return this.data;
          case "texture":
          case "gpu-buffer":
          case "ml-tensor": {
            if (!this.downloader) throw new Error("The current tensor is not created with a specified data downloader.");
            if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
            try {
              this.isDownloading = true;
              let a2 = await this.downloader();
              return this.downloader = void 0, this.dataLocation = "cpu", this.cpuData = a2, t2 && this.disposer && (this.disposer(), this.disposer = void 0), a2;
            } finally {
              this.isDownloading = false;
            }
          }
          default:
            throw new Error(`cannot get data from location: ${this.dataLocation}`);
        }
      }
      dispose() {
        if (this.isDownloading) throw new Error("The current tensor is being downloaded.");
        this.disposer && (this.disposer(), this.disposer = void 0), this.cpuData = void 0, this.gpuTextureData = void 0, this.gpuBufferData = void 0, this.mlTensorData = void 0, this.downloader = void 0, this.isDownloading = void 0, this.dataLocation = "none";
      }
      ensureValid() {
        if (this.dataLocation === "none") throw new Error("The tensor is disposed.");
      }
      reshape(t2) {
        if (this.ensureValid(), this.downloader || this.disposer) throw new Error("Cannot reshape a tensor that owns GPU resource.");
        return Ur2(this, t2);
      }
    };
  });
  var de2;
  var en2 = N2(() => {
    "use strict";
    ct2();
    de2 = Z2;
  });
  var Cr2;
  var Mr2;
  var _e2;
  var De2;
  var Pe2;
  var Ue2;
  var tn2 = N2(() => {
    "use strict";
    Qt2();
    Cr2 = (n2, t2) => {
      (typeof q2.trace > "u" ? !q2.wasm.trace : !q2.trace) || console.timeStamp(`${n2}::ORT::${t2}`);
    }, Mr2 = (n2, t2) => {
      let a2 = new Error().stack?.split(/\r\n|\r|\n/g) || [], u2 = false;
      for (let o2 = 0; o2 < a2.length; o2++) {
        if (u2 && !a2[o2].includes("TRACE_FUNC")) {
          let d2 = `FUNC_${n2}::${a2[o2].trim().split(" ")[1]}`;
          t2 && (d2 += `::${t2}`), Cr2("CPU", d2);
          return;
        }
        a2[o2].includes("TRACE_FUNC") && (u2 = true);
      }
    }, _e2 = (n2) => {
      (typeof q2.trace > "u" ? !q2.wasm.trace : !q2.trace) || Mr2("BEGIN", n2);
    }, De2 = (n2) => {
      (typeof q2.trace > "u" ? !q2.wasm.trace : !q2.trace) || Mr2("END", n2);
    }, Pe2 = (n2) => {
      (typeof q2.trace > "u" ? !q2.wasm.trace : !q2.trace) || console.time(`ORT::${n2}`);
    }, Ue2 = (n2) => {
      (typeof q2.trace > "u" ? !q2.wasm.trace : !q2.trace) || console.timeEnd(`ORT::${n2}`);
    };
  });
  var lt2;
  var Rr2 = N2(() => {
    "use strict";
    Zt2();
    en2();
    tn2();
    lt2 = class n2 {
      constructor(t2) {
        this.handler = t2;
      }
      async run(t2, a2, u2) {
        _e2(), Pe2("InferenceSession.run");
        let o2 = {}, d2 = {};
        if (typeof t2 != "object" || t2 === null || t2 instanceof de2 || Array.isArray(t2)) throw new TypeError("'feeds' must be an object that use input names as keys and OnnxValue as corresponding values.");
        let c2 = true;
        if (typeof a2 == "object") {
          if (a2 === null) throw new TypeError("Unexpected argument[1]: cannot be null.");
          if (a2 instanceof de2) throw new TypeError("'fetches' cannot be a Tensor");
          if (Array.isArray(a2)) {
            if (a2.length === 0) throw new TypeError("'fetches' cannot be an empty array.");
            c2 = false;
            for (let h2 of a2) {
              if (typeof h2 != "string") throw new TypeError("'fetches' must be a string array or an object.");
              if (this.outputNames.indexOf(h2) === -1) throw new RangeError(`'fetches' contains invalid output name: ${h2}.`);
              o2[h2] = null;
            }
            if (typeof u2 == "object" && u2 !== null) d2 = u2;
            else if (typeof u2 < "u") throw new TypeError("'options' must be an object.");
          } else {
            let h2 = false, g2 = Object.getOwnPropertyNames(a2);
            for (let b2 of this.outputNames) if (g2.indexOf(b2) !== -1) {
              let y3 = a2[b2];
              (y3 === null || y3 instanceof de2) && (h2 = true, c2 = false, o2[b2] = y3);
            }
            if (h2) {
              if (typeof u2 == "object" && u2 !== null) d2 = u2;
              else if (typeof u2 < "u") throw new TypeError("'options' must be an object.");
            } else d2 = a2;
          }
        } else if (typeof a2 < "u") throw new TypeError("Unexpected argument[1]: must be 'fetches' or 'options'.");
        for (let h2 of this.inputNames) if (typeof t2[h2] > "u") throw new Error(`input '${h2}' is missing in 'feeds'.`);
        if (c2) for (let h2 of this.outputNames) o2[h2] = null;
        let l2 = await this.handler.run(t2, o2, d2), m2 = {};
        for (let h2 in l2) if (Object.hasOwnProperty.call(l2, h2)) {
          let g2 = l2[h2];
          g2 instanceof de2 ? m2[h2] = g2 : m2[h2] = new de2(g2.type, g2.data, g2.dims);
        }
        return Ue2("InferenceSession.run"), De2(), m2;
      }
      async release() {
        return this.handler.dispose();
      }
      static async create(t2, a2, u2, o2) {
        _e2(), Pe2("InferenceSession.create");
        let d2, c2 = {};
        if (typeof t2 == "string") {
          if (d2 = t2, typeof a2 == "object" && a2 !== null) c2 = a2;
          else if (typeof a2 < "u") throw new TypeError("'options' must be an object.");
        } else if (t2 instanceof Uint8Array) {
          if (d2 = t2, typeof a2 == "object" && a2 !== null) c2 = a2;
          else if (typeof a2 < "u") throw new TypeError("'options' must be an object.");
        } else if (t2 instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && t2 instanceof SharedArrayBuffer) {
          let g2 = t2, b2 = 0, y3 = t2.byteLength;
          if (typeof a2 == "object" && a2 !== null) c2 = a2;
          else if (typeof a2 == "number") {
            if (b2 = a2, !Number.isSafeInteger(b2)) throw new RangeError("'byteOffset' must be an integer.");
            if (b2 < 0 || b2 >= g2.byteLength) throw new RangeError(`'byteOffset' is out of range [0, ${g2.byteLength}).`);
            if (y3 = t2.byteLength - b2, typeof u2 == "number") {
              if (y3 = u2, !Number.isSafeInteger(y3)) throw new RangeError("'byteLength' must be an integer.");
              if (y3 <= 0 || b2 + y3 > g2.byteLength) throw new RangeError(`'byteLength' is out of range (0, ${g2.byteLength - b2}].`);
              if (typeof o2 == "object" && o2 !== null) c2 = o2;
              else if (typeof o2 < "u") throw new TypeError("'options' must be an object.");
            } else if (typeof u2 < "u") throw new TypeError("'byteLength' must be a number.");
          } else if (typeof a2 < "u") throw new TypeError("'options' must be an object.");
          d2 = new Uint8Array(g2, b2, y3);
        } else throw new TypeError("Unexpected argument[0]: must be 'path' or 'buffer'.");
        let [l2, m2] = await pr2(c2), h2 = await l2.createInferenceSessionHandler(d2, m2);
        return Ue2("InferenceSession.create"), De2(), new n2(h2);
      }
      startProfiling() {
        this.handler.startProfiling();
      }
      endProfiling() {
        this.handler.endProfiling();
      }
      get inputNames() {
        return this.handler.inputNames;
      }
      get outputNames() {
        return this.handler.outputNames;
      }
      get inputMetadata() {
        return this.handler.inputMetadata;
      }
      get outputMetadata() {
        return this.handler.outputMetadata;
      }
    };
  });
  var rs2;
  var Fr2 = N2(() => {
    "use strict";
    Rr2();
    rs2 = lt2;
  });
  var Nr2 = N2(() => {
    "use strict";
  });
  var kr2 = N2(() => {
    "use strict";
  });
  var Wr2 = N2(() => {
    "use strict";
  });
  var Gr2 = N2(() => {
    "use strict";
  });
  var nn2 = {};
  ut2(nn2, { InferenceSession: () => rs2, TRACE: () => Cr2, TRACE_EVENT_BEGIN: () => Pe2, TRACE_EVENT_END: () => Ue2, TRACE_FUNC_BEGIN: () => _e2, TRACE_FUNC_END: () => De2, Tensor: () => de2, env: () => Y2, registerBackend: () => Je2 });
  var Te2 = N2(() => {
    "use strict";
    mr2();
    yr2();
    Fr2();
    en2();
    Nr2();
    kr2();
    tn2();
    Wr2();
    Gr2();
  });
  var dt2 = N2(() => {
    "use strict";
  });
  var jr2 = {};
  ut2(jr2, { default: () => os2 });
  var zr2;
  var Hr2;
  var os2;
  var Vr2 = N2(() => {
    "use strict";
    rn2();
    xe2();
    pt2();
    zr2 = "ort-wasm-proxy-worker", Hr2 = globalThis.self?.name === zr2;
    Hr2 && (self.onmessage = (n2) => {
      let { type: t2, in: a2 } = n2.data;
      try {
        switch (t2) {
          case "init-wasm":
            mt2(a2.wasm).then(() => {
              ht2(a2).then(() => {
                postMessage({ type: t2 });
              }, (u2) => {
                postMessage({ type: t2, err: u2 });
              });
            }, (u2) => {
              postMessage({ type: t2, err: u2 });
            });
            break;
          case "init-ep": {
            let { epName: u2, env: o2 } = a2;
            wt2(o2, u2).then(() => {
              postMessage({ type: t2 });
            }, (d2) => {
              postMessage({ type: t2, err: d2 });
            });
            break;
          }
          case "copy-from": {
            let { buffer: u2 } = a2, o2 = Ze2(u2);
            postMessage({ type: t2, out: o2 });
            break;
          }
          case "create": {
            let { model: u2, options: o2 } = a2;
            bt2(u2, o2).then((d2) => {
              postMessage({ type: t2, out: d2 });
            }, (d2) => {
              postMessage({ type: t2, err: d2 });
            });
            break;
          }
          case "release":
            yt2(a2), postMessage({ type: t2 });
            break;
          case "run": {
            let { sessionId: u2, inputIndices: o2, inputs: d2, outputIndices: c2, options: l2 } = a2;
            gt2(u2, o2, d2, c2, new Array(c2.length).fill(null), l2).then((m2) => {
              m2.some((h2) => h2[3] !== "cpu") ? postMessage({ type: t2, err: "Proxy does not support non-cpu tensor location." }) : postMessage({ type: t2, out: m2 }, Tt2([...d2, ...m2]));
            }, (m2) => {
              postMessage({ type: t2, err: m2 });
            });
            break;
          }
          case "end-profiling":
            Et2(a2), postMessage({ type: t2 });
            break;
          default:
        }
      } catch (u2) {
        postMessage({ type: t2, err: u2 });
      }
    });
    os2 = Hr2 ? null : (n2) => new Worker(n2 ?? oe2, { type: "module", name: zr2 });
  });
  var qr2 = {};
  ut2(qr2, { default: () => as2 });
  async function Yr2(n2 = {}) {
    var t2 = n2, a2 = !!globalThis.window, u2 = !!globalThis.WorkerGlobalScope, o2 = u2 && self.name?.startsWith("em-pthread");
    t2.mountExternalData = (e2, r2) => {
      e2.startsWith("./") && (e2 = e2.substring(2)), (t2.Tb || (t2.Tb = /* @__PURE__ */ new Map())).set(e2, r2);
    }, t2.unmountExternalData = () => {
      delete t2.Tb, delete t2.mc, delete t2.lc, delete t2.nc;
    }, globalThis.SharedArrayBuffer ?? new WebAssembly.Memory({ initial: 0, maximum: 0, shared: true }).buffer.constructor;
    var d2, c2, l2 = (e2, r2) => {
      throw r2;
    }, m2 = import_meta.url, h2 = "";
    if (a2 || u2) {
      try {
        h2 = new URL(".", m2).href;
      } catch {
      }
      u2 && (c2 = (e2) => {
        var r2 = new XMLHttpRequest();
        return r2.open("GET", e2, false), r2.responseType = "arraybuffer", r2.send(null), new Uint8Array(r2.response);
      }), d2 = async (e2) => {
        if (k2(e2)) return new Promise((i2, s2) => {
          var f2 = new XMLHttpRequest();
          f2.open("GET", e2, true), f2.responseType = "arraybuffer", f2.onload = () => {
            f2.status == 200 || f2.status == 0 && f2.response ? i2(f2.response) : s2(f2.status);
          }, f2.onerror = s2, f2.send(null);
        });
        var r2 = await fetch(e2, { credentials: "same-origin" });
        if (r2.ok) return r2.arrayBuffer();
        throw Error(r2.status + " : " + r2.url);
      };
    }
    var g2, b2, y3, T2, I2, D2, $2 = console.log.bind(console), v2 = console.error.bind(console), A2 = $2, F2 = v2, P2 = false, k2 = (e2) => e2.startsWith("file://");
    function w2() {
      ge2.buffer != H2.buffer && ee2();
    }
    if (o2) {
      let e2 = function(r2) {
        try {
          var i2 = r2.data, s2 = i2.Rb;
          if (s2 === "load") {
            let f2 = [];
            self.onmessage = (p2) => f2.push(p2), D2 = () => {
              postMessage({ Rb: "loaded" });
              for (let p2 of f2) e2(p2);
              self.onmessage = e2;
            };
            for (let p2 of i2.ac) t2[p2] && !t2[p2].proxy || (t2[p2] = (...E2) => {
              postMessage({ Rb: "callHandler", $b: p2, args: E2 });
            }, p2 == "print" && (A2 = t2[p2]), p2 == "printErr" && (F2 = t2[p2]));
            ge2 = i2.fc, ee2(), b2 = i2.hc, Ut2(), it2();
          } else if (s2 === "run") {
            (function(f2) {
              var p2 = (w2(), W2)[f2 + 52 >>> 2 >>> 0];
              f2 = (w2(), W2)[f2 + 56 >>> 2 >>> 0], ir2(p2, p2 - f2), _2(p2);
            })(i2.Qb), zt2(i2.Qb, 0, 0, 1, 0, 0), wn2(), Ft2(i2.Qb), Q2 ||= true;
            try {
              Io2(i2.dc, i2.Vb);
            } catch (f2) {
              if (f2 != "unwind") throw f2;
            }
          } else i2.target !== "setimmediate" && (s2 === "checkMailbox" ? Q2 && rt2() : s2 && (F2(`worker: received unknown command ${s2}`), F2(i2)));
        } catch (f2) {
          throw nr2(), f2;
        }
      };
      var As2 = e2, Q2 = false;
      self.onunhandledrejection = (r2) => {
        throw r2.reason || r2;
      }, self.onmessage = e2;
    }
    var H2, ne2, pe2, B2, W2, re2, me2, O2, K2, je2 = false;
    function ee2() {
      var e2 = ge2.buffer;
      t2.HEAP8 = H2 = new Int8Array(e2), pe2 = new Int16Array(e2), t2.HEAPU8 = ne2 = new Uint8Array(e2), new Uint16Array(e2), t2.HEAP32 = B2 = new Int32Array(e2), t2.HEAPU32 = W2 = new Uint32Array(e2), re2 = new Float32Array(e2), me2 = new Float64Array(e2), O2 = new BigInt64Array(e2), new BigUint64Array(e2);
    }
    function he2() {
      je2 = true, o2 ? D2() : Ee2.Va();
    }
    function j2(e2) {
      throw F2(e2 = "Aborted(" + e2 + ")"), P2 = true, e2 = new WebAssembly.RuntimeError(e2 + ". Build with -sASSERTIONS for more info."), I2?.(e2), e2;
    }
    function J2() {
      return { a: { T: ca2, f: Bo2, w: Lo2, e: _o2, k: Do2, h: Po2, L: Uo2, b: xo2, G: Co2, ua: vn2, j: Mo2, M: In2, La: Bn2, qa: Ln2, sa: _n2, Ma: Dn2, Ja: Pn2, Ca: Un2, Ia: xn2, Z: Cn2, ra: Mn2, oa: Rn2, Ka: Fn2, pa: Nn2, Ra: Ro2, Fa: Fo2, ma: ko2, va: Wo2, ja: Go2, U: $o2, Ea: Ft2, Oa: zo2, za: Ho2, Aa: jo2, Ba: Vo2, xa: $n2, ya: zn2, ka: Hn2, Ta: qo2, Qa: Zo2, W: Qo2, V: Ko2, Pa: Jo2, F: ea2, Na: ta2, na: na2, u: Yo2, H: ra2, S: at2, la: aa2, ba: oa2, Ua: sa2, Ga: Yn2, Ha: qn2, ta: ye2, I: Jn2, wa: Xn2, Y: Zn2, Da: Qn2, X: Kn2, $: Ya2, N: $a2, aa: Va2, O: Ga2, v: Da2, d: ma2, m: da2, n: la2, r: Aa2, ca: Na2, E: Fa2, o: ba2, P: ka2, C: za2, J: Ra2, da: Ma2, ea: Ca2, z: Oa2, fa: Ua2, Q: xa2, ga: Pa2, y: La2, D: Wa2, c: pa2, q: wa2, i: ha2, _: qa2, l: ga2, p: Ea2, s: ya2, t: Ta2, x: Ia2, R: _a2, A: Ha2, K: Ba2, B: ja2, ha: va2, ia: Sa2, g: ua2, a: ge2, Sa: V2 } };
    }
    async function Ut2() {
      function e2(s2, f2) {
        return Ee2 = s2.exports, Ee2 = (function() {
          var p2 = Ee2, E2 = (C2) => () => C2() >>> 0, S2 = (C2) => (R2) => C2(R2) >>> 0;
          return (p2 = Object.assign({}, p2)).ub = E2(p2.ub), p2.wb = S2(p2.wb), p2.Kb = S2(p2.Kb), p2.Lb = E2(p2.Lb), p2.Pb = S2(p2.Pb), p2;
        })(), mn2.push(Ee2.xb), s2 = Ee2, t2._OrtInit = s2.Wa, t2._OrtGetLastError = s2.Xa, t2._OrtCreateSessionOptions = s2.Ya, t2._OrtAppendExecutionProvider = s2.Za, t2._OrtAddFreeDimensionOverride = s2._a, t2._OrtAddSessionConfigEntry = s2.$a, t2._OrtReleaseSessionOptions = s2.ab, t2._OrtCreateSession = s2.bb, t2._OrtReleaseSession = s2.cb, t2._OrtGetInputOutputCount = s2.db, t2._OrtGetInputOutputMetadata = s2.eb, t2._OrtFree = s2.fb, t2._OrtCreateTensor = s2.gb, t2._OrtGetTensorData = s2.hb, t2._OrtReleaseTensor = s2.ib, t2._OrtCreateRunOptions = s2.jb, t2._OrtAddRunConfigEntry = s2.kb, t2._OrtReleaseRunOptions = s2.lb, t2._OrtCreateBinding = s2.mb, t2._OrtBindInput = s2.nb, t2._OrtBindOutput = s2.ob, t2._OrtClearBoundOutputs = s2.pb, t2._OrtReleaseBinding = s2.qb, t2._OrtRunWithBinding = s2.rb, t2._OrtRun = s2.sb, t2._OrtEndProfiling = s2.tb, st2 = s2.ub, er2 = t2._free = s2.vb, tr2 = t2._malloc = s2.wb, zt2 = s2.zb, nr2 = s2.Ab, rr2 = s2.Bb, or2 = s2.Cb, Ht2 = s2.Db, ar2 = s2.Eb, sr2 = s2.Fb, x3 = s2.Gb, qe2 = s2.Hb, ir2 = s2.Ib, _2 = s2.Jb, jt2 = s2.Kb, U2 = s2.Lb, ur2 = s2.Mb, Vt2 = s2.Nb, fr2 = s2.Ob, cr2 = s2.Pb, lr2 = s2.yb, b2 = f2, Ee2;
      }
      var r2, i2 = J2();
      return t2.instantiateWasm ? new Promise((s2) => {
        t2.instantiateWasm(i2, (f2, p2) => {
          s2(e2(f2, p2));
        });
      }) : o2 ? e2(new WebAssembly.Instance(b2, J2()), b2) : (K2 ??= t2.locateFile ? t2.locateFile ? t2.locateFile("ort-wasm-simd-threaded.wasm", h2) : h2 + "ort-wasm-simd-threaded.wasm" : new URL("ort-wasm-simd-threaded.wasm", import_meta.url).href, r2 = await (async function(s2) {
        var f2 = K2;
        if (!g2 && !k2(f2)) try {
          var p2 = fetch(f2, { credentials: "same-origin" });
          return await WebAssembly.instantiateStreaming(p2, s2);
        } catch (E2) {
          F2(`wasm streaming compile failed: ${E2}`), F2("falling back to ArrayBuffer instantiation");
        }
        return (async function(E2, S2) {
          try {
            var C2 = await (async function(R2) {
              if (!g2) try {
                var X2 = await d2(R2);
                return new Uint8Array(X2);
              } catch {
              }
              if (R2 == K2 && g2) R2 = new Uint8Array(g2);
              else {
                if (!c2) throw "both async and sync fetching of the wasm failed";
                R2 = c2(R2);
              }
              return R2;
            })(E2);
            return await WebAssembly.instantiate(C2, S2);
          } catch (R2) {
            F2(`failed to asynchronously prepare wasm: ${R2}`), j2(R2);
          }
        })(f2, s2);
      })(i2), e2(r2.instance, r2.module));
    }
    class Se2 {
      name = "ExitStatus";
      constructor(r2) {
        this.message = `Program terminated with exit(${r2})`, this.status = r2;
      }
    }
    var ve2 = (e2) => {
      e2.terminate(), e2.onmessage = () => {
      };
    }, Ve2 = [], Re2 = 0, te2 = null, ue2 = (e2) => {
      ce2.length == 0 && (yn2(), bn2(ce2[0]));
      var r2 = ce2.pop();
      if (!r2) return 6;
      Fe2.push(r2), Ae2[e2.Qb] = r2, r2.Qb = e2.Qb;
      var i2 = { Rb: "run", dc: e2.cc, Vb: e2.Vb, Qb: e2.Qb };
      return r2.postMessage(i2, e2.Zb), 0;
    }, se2 = 0, L2 = (e2, r2, ...i2) => {
      var s2, f2 = 16 * i2.length, p2 = U2(), E2 = jt2(f2), S2 = E2 >>> 3;
      for (s2 of i2) typeof s2 == "bigint" ? ((w2(), O2)[S2++ >>> 0] = 1n, (w2(), O2)[S2++ >>> 0] = s2) : ((w2(), O2)[S2++ >>> 0] = 0n, (w2(), me2)[S2++ >>> 0] = s2);
      return e2 = rr2(e2, 0, f2, E2, r2), _2(p2), e2;
    };
    function V2(e2) {
      if (o2) return L2(0, 1, e2);
      if (y3 = e2, !(0 < se2)) {
        for (var r2 of Fe2) ve2(r2);
        for (r2 of ce2) ve2(r2);
        ce2 = [], Fe2 = [], Ae2 = {}, P2 = true;
      }
      l2(0, new Se2(e2));
    }
    function fe2(e2) {
      if (o2) return L2(1, 0, e2);
      ye2(e2);
    }
    var ye2 = (e2) => {
      if (y3 = e2, o2) throw fe2(e2), "unwind";
      V2(e2);
    }, ce2 = [], Fe2 = [], mn2 = [], Ae2 = {}, hn2 = (e2) => {
      var r2 = e2.Qb;
      delete Ae2[r2], ce2.push(e2), Fe2.splice(Fe2.indexOf(e2), 1), e2.Qb = 0, or2(r2);
    };
    function wn2() {
      mn2.forEach((e2) => e2());
    }
    var bn2 = (e2) => new Promise((r2) => {
      e2.onmessage = (f2) => {
        var p2 = f2.data;
        if (f2 = p2.Rb, p2.Ub && p2.Ub != st2()) {
          var E2 = Ae2[p2.Ub];
          E2 ? E2.postMessage(p2, p2.Zb) : F2(`Internal error! Worker sent a message "${f2}" to target pthread ${p2.Ub}, but that thread no longer exists!`);
        } else f2 === "checkMailbox" ? rt2() : f2 === "spawnThread" ? ue2(p2) : f2 === "cleanupThread" ? Rt2(() => {
          hn2(Ae2[p2.ec]);
        }) : f2 === "loaded" ? (e2.loaded = true, r2(e2)) : p2.target === "setimmediate" ? e2.postMessage(p2) : f2 === "uncaughtException" ? e2.onerror(p2.error) : f2 === "callHandler" ? t2[p2.$b](...p2.args) : f2 && F2(`worker sent an unknown command ${f2}`);
      }, e2.onerror = (f2) => {
        throw F2(`worker sent an error! ${f2.filename}:${f2.lineno}: ${f2.message}`), f2;
      };
      var i2, s2 = [];
      for (i2 of []) t2.propertyIsEnumerable(i2) && s2.push(i2);
      e2.postMessage({ Rb: "load", ac: s2, fc: ge2, hc: b2 });
    });
    function yn2() {
      var e2 = new Worker((() => {
        let r2 = URL;
        return import_meta.url > "file:" && import_meta.url < "file;" ? new r2("ort.wasm.bundle.min.mjs", import_meta.url) : new URL(import_meta.url);
      })(), { type: "module", workerData: "em-pthread", name: "em-pthread" });
      ce2.push(e2);
    }
    var ge2, gn2 = [], M2 = (e2) => {
      var r2 = gn2[e2];
      return r2 || (gn2[e2] = r2 = lr2.get(e2)), r2;
    }, Io2 = (e2, r2) => {
      se2 = 0, e2 = M2(e2)(r2), 0 < se2 ? y3 = e2 : Ht2(e2);
    }, tt2 = [], nt2 = 0;
    function Bo2(e2) {
      var r2 = new xt2(e2 >>>= 0);
      return (w2(), H2)[r2.Sb + 12 >>> 0] == 0 && (En2(r2, true), nt2--), Tn2(r2, false), tt2.push(r2), cr2(e2);
    }
    var Ne2 = 0, Lo2 = () => {
      x3(0, 0);
      var e2 = tt2.pop();
      ur2(e2.Wb), Ne2 = 0;
    };
    function En2(e2, r2) {
      r2 = r2 ? 1 : 0, (w2(), H2)[e2.Sb + 12 >>> 0] = r2;
    }
    function Tn2(e2, r2) {
      r2 = r2 ? 1 : 0, (w2(), H2)[e2.Sb + 13 >>> 0] = r2;
    }
    class xt2 {
      constructor(r2) {
        this.Wb = r2, this.Sb = r2 - 24;
      }
    }
    var Ct2 = (e2) => {
      var r2 = Ne2;
      if (!r2) return qe2(0), 0;
      var i2 = new xt2(r2);
      (w2(), W2)[i2.Sb + 16 >>> 2 >>> 0] = r2;
      var s2 = (w2(), W2)[i2.Sb + 4 >>> 2 >>> 0];
      if (!s2) return qe2(0), r2;
      for (var f2 of e2) {
        if (f2 === 0 || f2 === s2) break;
        if (fr2(f2, s2, i2.Sb + 16)) return qe2(f2), r2;
      }
      return qe2(s2), r2;
    };
    function _o2() {
      return Ct2([]);
    }
    function Do2(e2) {
      return Ct2([e2 >>> 0]);
    }
    function Po2(e2, r2, i2, s2) {
      return Ct2([e2 >>> 0, r2 >>> 0, i2 >>> 0, s2 >>> 0]);
    }
    var Uo2 = () => {
      var e2 = tt2.pop();
      e2 || j2("no exception to throw");
      var r2 = e2.Wb;
      throw (w2(), H2)[e2.Sb + 13 >>> 0] == 0 && (tt2.push(e2), Tn2(e2, true), En2(e2, false), nt2++), Vt2(r2), Ne2 = r2;
    };
    function xo2(e2, r2, i2) {
      var s2 = new xt2(e2 >>>= 0);
      throw r2 >>>= 0, i2 >>>= 0, (w2(), W2)[s2.Sb + 16 >>> 2 >>> 0] = 0, (w2(), W2)[s2.Sb + 4 >>> 2 >>> 0] = r2, (w2(), W2)[s2.Sb + 8 >>> 2 >>> 0] = i2, Vt2(e2), nt2++, Ne2 = e2;
    }
    var Co2 = () => nt2;
    function Sn2(e2, r2, i2, s2) {
      return o2 ? L2(2, 1, e2, r2, i2, s2) : vn2(e2, r2, i2, s2);
    }
    function vn2(e2, r2, i2, s2) {
      if (e2 >>>= 0, r2 >>>= 0, i2 >>>= 0, s2 >>>= 0, !globalThis.SharedArrayBuffer) return 6;
      var f2 = [];
      return o2 && f2.length === 0 ? Sn2(e2, r2, i2, s2) : (e2 = { cc: i2, Qb: e2, Vb: s2, Zb: f2 }, o2 ? (e2.Rb = "spawnThread", postMessage(e2, f2), 0) : ue2(e2));
    }
    function Mo2(e2) {
      throw Ne2 ||= e2 >>> 0, Ne2;
    }
    var An2 = globalThis.TextDecoder && new TextDecoder(), On2 = (e2, r2 = 0, i2, s2) => {
      var f2 = r2 >>>= 0;
      if (i2 = f2 + i2, s2) s2 = i2;
      else {
        for (; e2[f2] && !(f2 >= i2); ) ++f2;
        s2 = f2;
      }
      if (16 < s2 - r2 && e2.buffer && An2) return An2.decode(e2.buffer instanceof ArrayBuffer ? e2.subarray(r2, s2) : e2.slice(r2, s2));
      for (f2 = ""; r2 < s2; ) if (128 & (i2 = e2[r2++])) {
        var p2 = 63 & e2[r2++];
        if ((224 & i2) == 192) f2 += String.fromCharCode((31 & i2) << 6 | p2);
        else {
          var E2 = 63 & e2[r2++];
          65536 > (i2 = (240 & i2) == 224 ? (15 & i2) << 12 | p2 << 6 | E2 : (7 & i2) << 18 | p2 << 12 | E2 << 6 | 63 & e2[r2++]) ? f2 += String.fromCharCode(i2) : (i2 -= 65536, f2 += String.fromCharCode(55296 | i2 >> 10, 56320 | 1023 & i2));
        }
      } else f2 += String.fromCharCode(i2);
      return f2;
    }, Mt2 = (e2, r2, i2) => (e2 >>>= 0) ? On2((w2(), ne2), e2, r2, i2) : "";
    function In2(e2, r2, i2) {
      return o2 ? L2(3, 1, e2, r2, i2) : 0;
    }
    function Bn2(e2, r2) {
      if (o2) return L2(4, 1, e2, r2);
    }
    function Ln2(e2, r2) {
      if (o2) return L2(5, 1, e2, r2);
    }
    function _n2(e2, r2, i2) {
      if (o2) return L2(6, 1, e2, r2, i2);
    }
    function Dn2(e2, r2, i2) {
      return o2 ? L2(7, 1, e2, r2, i2) : 0;
    }
    function Pn2(e2, r2) {
      if (o2) return L2(8, 1, e2, r2);
    }
    function Un2(e2, r2, i2) {
      if (o2) return L2(9, 1, e2, r2, i2);
    }
    function xn2(e2, r2, i2, s2) {
      if (o2) return L2(10, 1, e2, r2, i2, s2);
    }
    function Cn2(e2, r2, i2, s2) {
      if (o2) return L2(11, 1, e2, r2, i2, s2);
    }
    function Mn2(e2, r2, i2, s2) {
      if (o2) return L2(12, 1, e2, r2, i2, s2);
    }
    function Rn2(e2) {
      if (o2) return L2(13, 1, e2);
    }
    function Fn2(e2, r2) {
      if (o2) return L2(14, 1, e2, r2);
    }
    function Nn2(e2, r2, i2) {
      if (o2) return L2(15, 1, e2, r2, i2);
    }
    var Ro2 = () => j2("");
    function Fo2(e2) {
      zt2(e2 >>> 0, !u2, 1, !a2, 131072, false), wn2();
    }
    var Rt2 = (e2) => {
      if (!P2) try {
        if (e2(), !(0 < se2)) try {
          o2 ? st2() && Ht2(y3) : ye2(y3);
        } catch (r2) {
          r2 instanceof Se2 || r2 == "unwind" || l2(0, r2);
        }
      } catch (r2) {
        r2 instanceof Se2 || r2 == "unwind" || l2(0, r2);
      }
    }, No2 = !Atomics.waitAsync || globalThis.navigator?.userAgent && 91 > Number((navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./) || [])[2]);
    function Ft2(e2) {
      e2 >>>= 0, No2 || (Atomics.waitAsync((w2(), B2), e2 >>> 2, e2).value.then(rt2), e2 += 128, Atomics.store((w2(), B2), e2 >>> 2, 1));
    }
    var rt2 = () => Rt2(() => {
      var e2 = st2();
      e2 && (Ft2(e2), sr2());
    });
    function ko2(e2, r2) {
      (e2 >>>= 0) == r2 >>> 0 ? setTimeout(rt2) : o2 ? postMessage({ Ub: e2, Rb: "checkMailbox" }) : (e2 = Ae2[e2]) && e2.postMessage({ Rb: "checkMailbox" });
    }
    var Nt2 = [];
    function Wo2(e2, r2, i2, s2, f2) {
      for (r2 >>>= 0, f2 >>>= 0, Nt2.length = 0, i2 = f2 >>> 3, s2 = f2 + s2 >>> 3; i2 < s2; ) {
        var p2;
        p2 = (w2(), O2)[i2++ >>> 0] ? (w2(), O2)[i2++ >>> 0] : (w2(), me2)[i2++ >>> 0], Nt2.push(p2);
      }
      return (r2 ? dr2[r2] : fa2[e2])(...Nt2);
    }
    var Go2 = () => {
      se2 = 0;
    };
    function $o2(e2) {
      e2 >>>= 0, o2 ? postMessage({ Rb: "cleanupThread", ec: e2 }) : hn2(Ae2[e2]);
    }
    function zo2(e2) {
    }
    function Ho2(e2, r2) {
      e2 = -9007199254740992 > e2 || 9007199254740992 < e2 ? NaN : Number(e2), r2 >>>= 0, e2 = new Date(1e3 * e2), (w2(), B2)[r2 >>> 2 >>> 0] = e2.getUTCSeconds(), (w2(), B2)[r2 + 4 >>> 2 >>> 0] = e2.getUTCMinutes(), (w2(), B2)[r2 + 8 >>> 2 >>> 0] = e2.getUTCHours(), (w2(), B2)[r2 + 12 >>> 2 >>> 0] = e2.getUTCDate(), (w2(), B2)[r2 + 16 >>> 2 >>> 0] = e2.getUTCMonth(), (w2(), B2)[r2 + 20 >>> 2 >>> 0] = e2.getUTCFullYear() - 1900, (w2(), B2)[r2 + 24 >>> 2 >>> 0] = e2.getUTCDay(), e2 = (e2.getTime() - Date.UTC(e2.getUTCFullYear(), 0, 1, 0, 0, 0, 0)) / 864e5 | 0, (w2(), B2)[r2 + 28 >>> 2 >>> 0] = e2;
    }
    var kn2 = (e2) => e2 % 4 == 0 && (e2 % 100 != 0 || e2 % 400 == 0), Wn2 = [0, 31, 60, 91, 121, 152, 182, 213, 244, 274, 305, 335], Gn2 = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    function jo2(e2, r2) {
      e2 = -9007199254740992 > e2 || 9007199254740992 < e2 ? NaN : Number(e2), r2 >>>= 0, e2 = new Date(1e3 * e2), (w2(), B2)[r2 >>> 2 >>> 0] = e2.getSeconds(), (w2(), B2)[r2 + 4 >>> 2 >>> 0] = e2.getMinutes(), (w2(), B2)[r2 + 8 >>> 2 >>> 0] = e2.getHours(), (w2(), B2)[r2 + 12 >>> 2 >>> 0] = e2.getDate(), (w2(), B2)[r2 + 16 >>> 2 >>> 0] = e2.getMonth(), (w2(), B2)[r2 + 20 >>> 2 >>> 0] = e2.getFullYear() - 1900, (w2(), B2)[r2 + 24 >>> 2 >>> 0] = e2.getDay();
      var i2 = (kn2(e2.getFullYear()) ? Wn2 : Gn2)[e2.getMonth()] + e2.getDate() - 1 | 0;
      (w2(), B2)[r2 + 28 >>> 2 >>> 0] = i2, (w2(), B2)[r2 + 36 >>> 2 >>> 0] = -60 * e2.getTimezoneOffset(), i2 = new Date(e2.getFullYear(), 6, 1).getTimezoneOffset();
      var s2 = new Date(e2.getFullYear(), 0, 1).getTimezoneOffset();
      e2 = 0 | (i2 != s2 && e2.getTimezoneOffset() == Math.min(s2, i2)), (w2(), B2)[r2 + 32 >>> 2 >>> 0] = e2;
    }
    function Vo2(e2) {
      e2 >>>= 0;
      var r2 = new Date((w2(), B2)[e2 + 20 >>> 2 >>> 0] + 1900, (w2(), B2)[e2 + 16 >>> 2 >>> 0], (w2(), B2)[e2 + 12 >>> 2 >>> 0], (w2(), B2)[e2 + 8 >>> 2 >>> 0], (w2(), B2)[e2 + 4 >>> 2 >>> 0], (w2(), B2)[e2 >>> 2 >>> 0], 0), i2 = (w2(), B2)[e2 + 32 >>> 2 >>> 0], s2 = r2.getTimezoneOffset(), f2 = new Date(r2.getFullYear(), 6, 1).getTimezoneOffset(), p2 = new Date(r2.getFullYear(), 0, 1).getTimezoneOffset(), E2 = Math.min(p2, f2);
      return 0 > i2 ? (w2(), B2)[e2 + 32 >>> 2 >>> 0] = +(f2 != p2 && E2 == s2) : 0 < i2 != (E2 == s2) && (f2 = Math.max(p2, f2), r2.setTime(r2.getTime() + 6e4 * ((0 < i2 ? E2 : f2) - s2))), (w2(), B2)[e2 + 24 >>> 2 >>> 0] = r2.getDay(), i2 = (kn2(r2.getFullYear()) ? Wn2 : Gn2)[r2.getMonth()] + r2.getDate() - 1 | 0, (w2(), B2)[e2 + 28 >>> 2 >>> 0] = i2, (w2(), B2)[e2 >>> 2 >>> 0] = r2.getSeconds(), (w2(), B2)[e2 + 4 >>> 2 >>> 0] = r2.getMinutes(), (w2(), B2)[e2 + 8 >>> 2 >>> 0] = r2.getHours(), (w2(), B2)[e2 + 12 >>> 2 >>> 0] = r2.getDate(), (w2(), B2)[e2 + 16 >>> 2 >>> 0] = r2.getMonth(), (w2(), B2)[e2 + 20 >>> 2 >>> 0] = r2.getYear(), e2 = r2.getTime(), BigInt(isNaN(e2) ? -1 : e2 / 1e3);
    }
    function $n2(e2, r2, i2, s2, f2, p2, E2) {
      return o2 ? L2(16, 1, e2, r2, i2, s2, f2, p2, E2) : -52;
    }
    function zn2(e2, r2, i2, s2, f2, p2) {
      if (o2) return L2(17, 1, e2, r2, i2, s2, f2, p2);
    }
    var Ye2 = {}, Yo2 = () => performance.timeOrigin + performance.now();
    function Hn2(e2, r2) {
      if (o2) return L2(18, 1, e2, r2);
      if (Ye2[e2] && (clearTimeout(Ye2[e2].id), delete Ye2[e2]), !r2) return 0;
      var i2 = setTimeout(() => {
        delete Ye2[e2], Rt2(() => ar2(e2, performance.timeOrigin + performance.now()));
      }, r2);
      return Ye2[e2] = { id: i2, oc: r2 }, 0;
    }
    var Oe2 = (e2, r2, i2) => {
      var s2 = (w2(), ne2);
      if (r2 >>>= 0, 0 < i2) {
        var f2 = r2;
        i2 = r2 + i2 - 1;
        for (var p2 = 0; p2 < e2.length; ++p2) {
          var E2 = e2.codePointAt(p2);
          if (127 >= E2) {
            if (r2 >= i2) break;
            s2[r2++ >>> 0] = E2;
          } else if (2047 >= E2) {
            if (r2 + 1 >= i2) break;
            s2[r2++ >>> 0] = 192 | E2 >> 6, s2[r2++ >>> 0] = 128 | 63 & E2;
          } else if (65535 >= E2) {
            if (r2 + 2 >= i2) break;
            s2[r2++ >>> 0] = 224 | E2 >> 12, s2[r2++ >>> 0] = 128 | E2 >> 6 & 63, s2[r2++ >>> 0] = 128 | 63 & E2;
          } else {
            if (r2 + 3 >= i2) break;
            s2[r2++ >>> 0] = 240 | E2 >> 18, s2[r2++ >>> 0] = 128 | E2 >> 12 & 63, s2[r2++ >>> 0] = 128 | E2 >> 6 & 63, s2[r2++ >>> 0] = 128 | 63 & E2, p2++;
          }
        }
        s2[r2 >>> 0] = 0, e2 = r2 - f2;
      } else e2 = 0;
      return e2;
    };
    function qo2(e2, r2, i2, s2) {
      e2 >>>= 0, r2 >>>= 0, i2 >>>= 0, s2 >>>= 0;
      var f2 = (/* @__PURE__ */ new Date()).getFullYear(), p2 = new Date(f2, 0, 1).getTimezoneOffset();
      f2 = new Date(f2, 6, 1).getTimezoneOffset();
      var E2 = Math.max(p2, f2);
      (w2(), W2)[e2 >>> 2 >>> 0] = 60 * E2, (w2(), B2)[r2 >>> 2 >>> 0] = +(p2 != f2), e2 = (r2 = (S2) => {
        var C2 = Math.abs(S2);
        return `UTC${0 <= S2 ? "-" : "+"}${String(Math.floor(C2 / 60)).padStart(2, "0")}${String(C2 % 60).padStart(2, "0")}`;
      })(p2), r2 = r2(f2), f2 < p2 ? (Oe2(e2, i2, 17), Oe2(r2, s2, 17)) : (Oe2(e2, s2, 17), Oe2(r2, i2, 17));
    }
    var Jo2 = () => Date.now(), Xo2 = 1;
    function Zo2(e2, r2, i2) {
      if (i2 >>>= 0, !(0 <= e2 && 3 >= e2)) return 28;
      if (e2 === 0) e2 = Date.now();
      else {
        if (!Xo2) return 52;
        e2 = performance.timeOrigin + performance.now();
      }
      return e2 = Math.round(1e6 * e2), (w2(), O2)[i2 >>> 3 >>> 0] = BigInt(e2), 0;
    }
    var kt2 = [];
    function Qo2(e2, r2, i2) {
      e2 >>>= 0, r2 >>>= 0, i2 >>>= 0, kt2.length = 0;
      for (var s2; s2 = (w2(), ne2)[r2++ >>> 0]; ) {
        var f2 = s2 != 105;
        i2 += (f2 &= s2 != 112) && i2 % 8 ? 4 : 0, kt2.push(s2 == 112 ? (w2(), W2)[i2 >>> 2 >>> 0] : s2 == 106 ? (w2(), O2)[i2 >>> 3 >>> 0] : s2 == 105 ? (w2(), B2)[i2 >>> 2 >>> 0] : (w2(), me2)[i2 >>> 3 >>> 0]), i2 += f2 ? 8 : 4;
      }
      return dr2[e2](...kt2);
    }
    var Ko2 = () => {
    };
    function ea2(e2, r2) {
      return F2(Mt2(e2 >>> 0, r2 >>> 0));
    }
    var ta2 = () => {
      throw se2 += 1, "unwind";
    };
    function na2() {
      return 4294901760;
    }
    var ra2 = () => navigator.hardwareConcurrency, Ie2 = {}, Wt2 = (e2) => {
      for (var r2 = 0, i2 = 0; i2 < e2.length; ++i2) {
        var s2 = e2.charCodeAt(i2);
        127 >= s2 ? r2++ : 2047 >= s2 ? r2 += 2 : 55296 <= s2 && 57343 >= s2 ? (r2 += 4, ++i2) : r2 += 3;
      }
      return r2;
    }, ot2 = (e2) => {
      var r2;
      return (r2 = /\bwasm-function\[\d+\]:(0x[0-9a-f]+)/.exec(e2)) ? +r2[1] : (r2 = /:(\d+):\d+(?:\)|$)/.exec(e2)) ? 2147483648 | +r2[1] : 0;
    }, jn2 = (e2) => {
      for (var r2 of e2) (e2 = ot2(r2)) && (Ie2[e2] = r2);
    };
    function oa2() {
      var e2 = Error().stack.toString().split(`
`);
      return e2[0] == "Error" && e2.shift(), jn2(e2), Ie2.Xb = ot2(e2[3]), Ie2.bc = e2, Ie2.Xb;
    }
    function at2(e2) {
      if (!(e2 = Ie2[e2 >>> 0])) return 0;
      var r2;
      if (r2 = /^\s+at .*\.wasm\.(.*) \(.*\)$/.exec(e2)) e2 = r2[1];
      else if (r2 = /^\s+at (.*) \(.*\)$/.exec(e2)) e2 = r2[1];
      else {
        if (!(r2 = /^(.+?)@/.exec(e2))) return 0;
        e2 = r2[1];
      }
      er2(at2.Yb ?? 0), r2 = Wt2(e2) + 1;
      var i2 = tr2(r2);
      return i2 && Oe2(e2, i2, r2), at2.Yb = i2, at2.Yb;
    }
    function aa2(e2) {
      e2 >>>= 0;
      var r2 = (w2(), ne2).length;
      if (e2 <= r2 || 4294901760 < e2) return false;
      for (var i2 = 1; 4 >= i2; i2 *= 2) {
        var s2 = r2 * (1 + 0.2 / i2);
        s2 = Math.min(s2, e2 + 100663296);
        e: {
          s2 = (Math.min(4294901760, 65536 * Math.ceil(Math.max(e2, s2) / 65536)) - ge2.buffer.byteLength + 65535) / 65536 | 0;
          try {
            ge2.grow(s2), ee2();
            var f2 = 1;
            break e;
          } catch {
          }
          f2 = void 0;
        }
        if (f2) return true;
      }
      return false;
    }
    function sa2(e2, r2, i2) {
      if (e2 >>>= 0, r2 >>>= 0, Ie2.Xb == e2) var s2 = Ie2.bc;
      else (s2 = Error().stack.toString().split(`
`))[0] == "Error" && s2.shift(), jn2(s2);
      for (var f2 = 3; s2[f2] && ot2(s2[f2]) != e2; ) ++f2;
      for (e2 = 0; e2 < i2 && s2[e2 + f2]; ++e2) (w2(), B2)[r2 + 4 * e2 >>> 2 >>> 0] = ot2(s2[e2 + f2]);
      return e2;
    }
    var Gt2, $t2 = {}, Vn2 = () => {
      if (!Gt2) {
        var e2, r2 = { USER: "web_user", LOGNAME: "web_user", PATH: "/", PWD: "/", HOME: "/home/web_user", LANG: (globalThis.navigator?.language ?? "C").replace("-", "_") + ".UTF-8", _: "./this.program" };
        for (e2 in $t2) $t2[e2] === void 0 ? delete r2[e2] : r2[e2] = $t2[e2];
        var i2 = [];
        for (e2 in r2) i2.push(`${e2}=${r2[e2]}`);
        Gt2 = i2;
      }
      return Gt2;
    };
    function Yn2(e2, r2) {
      if (o2) return L2(19, 1, e2, r2);
      e2 >>>= 0, r2 >>>= 0;
      var i2, s2 = 0, f2 = 0;
      for (i2 of Vn2()) {
        var p2 = r2 + s2;
        (w2(), W2)[e2 + f2 >>> 2 >>> 0] = p2, s2 += Oe2(i2, p2, 1 / 0) + 1, f2 += 4;
      }
      return 0;
    }
    function qn2(e2, r2) {
      if (o2) return L2(20, 1, e2, r2);
      e2 >>>= 0, r2 >>>= 0;
      var i2 = Vn2();
      for (var s2 of ((w2(), W2)[e2 >>> 2 >>> 0] = i2.length, e2 = 0, i2)) e2 += Wt2(s2) + 1;
      return (w2(), W2)[r2 >>> 2 >>> 0] = e2, 0;
    }
    function Jn2(e2) {
      return o2 ? L2(21, 1, e2) : 52;
    }
    function Xn2(e2, r2, i2, s2, f2) {
      return o2 ? L2(22, 1, e2, r2, i2, s2, f2) : 52;
    }
    function Zn2(e2, r2, i2, s2) {
      return o2 ? L2(23, 1, e2, r2, i2, s2) : 52;
    }
    function Qn2(e2, r2, i2, s2) {
      return o2 ? L2(24, 1, e2, r2, i2, s2) : 70;
    }
    var ia2 = [null, [], []];
    function Kn2(e2, r2, i2, s2) {
      if (o2) return L2(25, 1, e2, r2, i2, s2);
      r2 >>>= 0, i2 >>>= 0, s2 >>>= 0;
      for (var f2 = 0, p2 = 0; p2 < i2; p2++) {
        var E2 = (w2(), W2)[r2 >>> 2 >>> 0], S2 = (w2(), W2)[r2 + 4 >>> 2 >>> 0];
        r2 += 8;
        for (var C2 = 0; C2 < S2; C2++) {
          var R2 = e2, X2 = (w2(), ne2)[E2 + C2 >>> 0], le2 = ia2[R2];
          X2 === 0 || X2 === 10 ? ((R2 === 1 ? A2 : F2)(On2(le2)), le2.length = 0) : le2.push(X2);
        }
        f2 += S2;
      }
      return (w2(), W2)[s2 >>> 2 >>> 0] = f2, 0;
    }
    function ua2(e2) {
      return e2 >>> 0;
    }
    o2 || (function() {
      for (var e2 = t2.numThreads - 1; e2--; ) yn2();
      Ve2.push(async () => {
        var r2 = (async function() {
          if (!o2) return Promise.all(ce2.map(bn2));
        })();
        Re2++, await r2, --Re2 == 0 && te2 && (r2 = te2, te2 = null, r2());
      });
    })(), o2 || (ge2 = new WebAssembly.Memory({ initial: 256, maximum: 65536, shared: true }), ee2()), t2.wasmBinary && (g2 = t2.wasmBinary), t2.stackSave = () => U2(), t2.stackRestore = (e2) => _2(e2), t2.stackAlloc = (e2) => jt2(e2), t2.setValue = function(e2, r2, i2 = "i8") {
      switch (i2.endsWith("*") && (i2 = "*"), i2) {
        case "i1":
        case "i8":
          (w2(), H2)[e2 >>> 0] = r2;
          break;
        case "i16":
          (w2(), pe2)[e2 >>> 1 >>> 0] = r2;
          break;
        case "i32":
          (w2(), B2)[e2 >>> 2 >>> 0] = r2;
          break;
        case "i64":
          (w2(), O2)[e2 >>> 3 >>> 0] = BigInt(r2);
          break;
        case "float":
          (w2(), re2)[e2 >>> 2 >>> 0] = r2;
          break;
        case "double":
          (w2(), me2)[e2 >>> 3 >>> 0] = r2;
          break;
        case "*":
          (w2(), W2)[e2 >>> 2 >>> 0] = r2;
          break;
        default:
          j2(`invalid type for setValue: ${i2}`);
      }
    }, t2.getValue = function(e2, r2 = "i8") {
      switch (r2.endsWith("*") && (r2 = "*"), r2) {
        case "i1":
        case "i8":
          return (w2(), H2)[e2 >>> 0];
        case "i16":
          return (w2(), pe2)[e2 >>> 1 >>> 0];
        case "i32":
          return (w2(), B2)[e2 >>> 2 >>> 0];
        case "i64":
          return (w2(), O2)[e2 >>> 3 >>> 0];
        case "float":
          return (w2(), re2)[e2 >>> 2 >>> 0];
        case "double":
          return (w2(), me2)[e2 >>> 3 >>> 0];
        case "*":
          return (w2(), W2)[e2 >>> 2 >>> 0];
        default:
          j2(`invalid type for getValue: ${r2}`);
      }
    }, t2.UTF8ToString = Mt2, t2.stringToUTF8 = Oe2, t2.lengthBytesUTF8 = Wt2;
    var st2, er2, tr2, zt2, nr2, rr2, or2, Ht2, ar2, sr2, x3, qe2, ir2, _2, jt2, U2, ur2, Vt2, fr2, cr2, lr2, Ee2, fa2 = [V2, fe2, Sn2, In2, Bn2, Ln2, _n2, Dn2, Pn2, Un2, xn2, Cn2, Mn2, Rn2, Fn2, Nn2, $n2, zn2, Hn2, Yn2, qn2, Jn2, Xn2, Zn2, Qn2, Kn2], dr2 = { 1042604: (e2, r2, i2, s2, f2) => {
      if (t2 === void 0 || !t2.Tb) return 1;
      if ((e2 = Mt2(Number(e2 >>> 0))).startsWith("./") && (e2 = e2.substring(2)), !(e2 = t2.Tb.get(e2))) return 2;
      if (r2 = Number(r2 >>> 0), i2 = Number(i2 >>> 0), s2 = Number(s2 >>> 0), r2 + i2 > e2.byteLength) return 3;
      try {
        let p2 = e2.subarray(r2, r2 + i2);
        switch (f2) {
          case 0:
            (w2(), ne2).set(p2, s2 >>> 0);
            break;
          case 1:
            t2.ic ? t2.ic(s2, p2) : t2.kc(s2, p2);
            break;
          default:
            return 4;
        }
        return 0;
      } catch {
        return 4;
      }
    }, 1043428: () => typeof wasmOffsetConverter < "u" };
    function ca2() {
      return typeof wasmOffsetConverter < "u";
    }
    function la2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        return M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function da2(e2, r2, i2) {
      var s2 = U2();
      try {
        return M2(e2)(r2, i2);
      } catch (f2) {
        if (_2(s2), f2 !== f2 + 0) throw f2;
        x3(1, 0);
      }
    }
    function pa2(e2) {
      var r2 = U2();
      try {
        M2(e2)();
      } catch (i2) {
        if (_2(r2), i2 !== i2 + 0) throw i2;
        x3(1, 0);
      }
    }
    function ma2(e2, r2) {
      var i2 = U2();
      try {
        return M2(e2)(r2);
      } catch (s2) {
        if (_2(i2), s2 !== s2 + 0) throw s2;
        x3(1, 0);
      }
    }
    function ha2(e2, r2, i2) {
      var s2 = U2();
      try {
        M2(e2)(r2, i2);
      } catch (f2) {
        if (_2(s2), f2 !== f2 + 0) throw f2;
        x3(1, 0);
      }
    }
    function wa2(e2, r2) {
      var i2 = U2();
      try {
        M2(e2)(r2);
      } catch (s2) {
        if (_2(i2), s2 !== s2 + 0) throw s2;
        x3(1, 0);
      }
    }
    function ba2(e2, r2, i2, s2, f2, p2, E2) {
      var S2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2, p2, E2);
      } catch (C2) {
        if (_2(S2), C2 !== C2 + 0) throw C2;
        x3(1, 0);
      }
    }
    function ya2(e2, r2, i2, s2, f2, p2) {
      var E2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2);
      } catch (S2) {
        if (_2(E2), S2 !== S2 + 0) throw S2;
        x3(1, 0);
      }
    }
    function ga2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function Ea2(e2, r2, i2, s2, f2) {
      var p2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2);
      } catch (E2) {
        if (_2(p2), E2 !== E2 + 0) throw E2;
        x3(1, 0);
      }
    }
    function Ta2(e2, r2, i2, s2, f2, p2, E2) {
      var S2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2);
      } catch (C2) {
        if (_2(S2), C2 !== C2 + 0) throw C2;
        x3(1, 0);
      }
    }
    function Sa2(e2, r2, i2, s2, f2, p2, E2) {
      var S2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2);
      } catch (C2) {
        if (_2(S2), C2 !== C2 + 0) throw C2;
        x3(1, 0);
      }
    }
    function va2(e2, r2, i2, s2, f2, p2, E2, S2) {
      var C2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2, S2);
      } catch (R2) {
        if (_2(C2), R2 !== R2 + 0) throw R2;
        x3(1, 0);
      }
    }
    function Aa2(e2, r2, i2, s2, f2) {
      var p2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2);
      } catch (E2) {
        if (_2(p2), E2 !== E2 + 0) throw E2;
        x3(1, 0);
      }
    }
    function Oa2(e2, r2, i2) {
      var s2 = U2();
      try {
        return M2(e2)(r2, i2);
      } catch (f2) {
        if (_2(s2), f2 !== f2 + 0) throw f2;
        x3(1, 0);
      }
    }
    function Ia2(e2, r2, i2, s2, f2, p2, E2, S2) {
      var C2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2, S2);
      } catch (R2) {
        if (_2(C2), R2 !== R2 + 0) throw R2;
        x3(1, 0);
      }
    }
    function Ba2(e2, r2, i2, s2, f2, p2, E2, S2, C2, R2, X2, le2) {
      var we2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2, S2, C2, R2, X2, le2);
      } catch (be2) {
        if (_2(we2), be2 !== be2 + 0) throw be2;
        x3(1, 0);
      }
    }
    function La2(e2, r2, i2) {
      var s2 = U2();
      try {
        return M2(e2)(r2, i2);
      } catch (f2) {
        if (_2(s2), f2 !== f2 + 0) throw f2;
        return x3(1, 0), 0n;
      }
    }
    function _a2(e2, r2, i2, s2, f2, p2, E2, S2, C2) {
      var R2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2, S2, C2);
      } catch (X2) {
        if (_2(R2), X2 !== X2 + 0) throw X2;
        x3(1, 0);
      }
    }
    function Da2(e2) {
      var r2 = U2();
      try {
        return M2(e2)();
      } catch (i2) {
        if (_2(r2), i2 !== i2 + 0) throw i2;
        x3(1, 0);
      }
    }
    function Pa2(e2, r2) {
      var i2 = U2();
      try {
        return M2(e2)(r2);
      } catch (s2) {
        if (_2(i2), s2 !== s2 + 0) throw s2;
        return x3(1, 0), 0n;
      }
    }
    function Ua2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        return M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function xa2(e2) {
      var r2 = U2();
      try {
        return M2(e2)();
      } catch (i2) {
        if (_2(r2), i2 !== i2 + 0) throw i2;
        return x3(1, 0), 0n;
      }
    }
    function Ca2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        return M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function Ma2(e2, r2, i2, s2, f2) {
      var p2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2);
      } catch (E2) {
        if (_2(p2), E2 !== E2 + 0) throw E2;
        x3(1, 0);
      }
    }
    function Ra2(e2, r2, i2, s2, f2, p2) {
      var E2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2, p2);
      } catch (S2) {
        if (_2(E2), S2 !== S2 + 0) throw S2;
        x3(1, 0);
      }
    }
    function Fa2(e2, r2, i2, s2, f2, p2) {
      var E2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2, p2);
      } catch (S2) {
        if (_2(E2), S2 !== S2 + 0) throw S2;
        x3(1, 0);
      }
    }
    function Na2(e2, r2, i2, s2, f2, p2) {
      var E2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2, p2);
      } catch (S2) {
        if (_2(E2), S2 !== S2 + 0) throw S2;
        x3(1, 0);
      }
    }
    function ka2(e2, r2, i2, s2, f2, p2, E2, S2) {
      var C2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2, p2, E2, S2);
      } catch (R2) {
        if (_2(C2), R2 !== R2 + 0) throw R2;
        x3(1, 0);
      }
    }
    function Wa2(e2, r2, i2, s2, f2) {
      var p2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2);
      } catch (E2) {
        if (_2(p2), E2 !== E2 + 0) throw E2;
        return x3(1, 0), 0n;
      }
    }
    function Ga2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        return M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function $a2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        return M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function za2(e2, r2, i2, s2, f2, p2, E2, S2, C2, R2, X2, le2) {
      var we2 = U2();
      try {
        return M2(e2)(r2, i2, s2, f2, p2, E2, S2, C2, R2, X2, le2);
      } catch (be2) {
        if (_2(we2), be2 !== be2 + 0) throw be2;
        x3(1, 0);
      }
    }
    function Ha2(e2, r2, i2, s2, f2, p2, E2, S2, C2, R2, X2) {
      var le2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2, S2, C2, R2, X2);
      } catch (we2) {
        if (_2(le2), we2 !== we2 + 0) throw we2;
        x3(1, 0);
      }
    }
    function ja2(e2, r2, i2, s2, f2, p2, E2, S2, C2, R2, X2, le2, we2, be2, Ja2, Xa2) {
      var Za2 = U2();
      try {
        M2(e2)(r2, i2, s2, f2, p2, E2, S2, C2, R2, X2, le2, we2, be2, Ja2, Xa2);
      } catch (Yt2) {
        if (_2(Za2), Yt2 !== Yt2 + 0) throw Yt2;
        x3(1, 0);
      }
    }
    function Va2(e2, r2, i2) {
      var s2 = U2();
      try {
        return M2(e2)(r2, i2);
      } catch (f2) {
        if (_2(s2), f2 !== f2 + 0) throw f2;
        x3(1, 0);
      }
    }
    function Ya2(e2, r2, i2) {
      var s2 = U2();
      try {
        return M2(e2)(r2, i2);
      } catch (f2) {
        if (_2(s2), f2 !== f2 + 0) throw f2;
        x3(1, 0);
      }
    }
    function qa2(e2, r2, i2, s2) {
      var f2 = U2();
      try {
        M2(e2)(r2, i2, s2);
      } catch (p2) {
        if (_2(f2), p2 !== p2 + 0) throw p2;
        x3(1, 0);
      }
    }
    function it2() {
      if (0 < Re2) te2 = it2;
      else if (o2) T2?.(t2), he2();
      else {
        for (var e2 = Ve2; 0 < e2.length; ) e2.shift()(t2);
        0 < Re2 ? te2 = it2 : (t2.calledRun = true, P2 || (he2(), T2?.(t2)));
      }
    }
    return o2 || (Ee2 = await Ut2(), it2()), t2.PTR_SIZE = 4, je2 ? t2 : new Promise((e2, r2) => {
      T2 = e2, I2 = r2;
    });
  }
  var as2;
  var ss2;
  var Jr2 = N2(() => {
    "use strict";
    as2 = Yr2, ss2 = globalThis.self?.name?.startsWith("em-pthread");
    ss2 && Yr2();
  });
  var Qr2;
  var an2;
  var is2;
  var oe2;
  var Kr2;
  var on2;
  var us2;
  var fs2;
  var eo2;
  var cs2;
  var Xr2;
  var to2;
  var Zr2;
  var no2;
  var pt2 = N2(() => {
    "use strict";
    dt2();
    Qr2 = typeof location > "u" ? void 0 : location.origin, an2 = import_meta.url > "file:" && import_meta.url < "file;", is2 = () => {
      if (true) {
        if (an2) {
          let n2 = URL;
          return new URL(new n2("ort.wasm.bundle.min.mjs", import_meta.url).href, Qr2).href;
        }
        return import_meta.url;
      }
    }, oe2 = is2(), Kr2 = () => {
      if (oe2 && !oe2.startsWith("blob:")) return oe2.substring(0, oe2.lastIndexOf("/") + 1);
    }, on2 = (n2, t2) => {
      try {
        let a2 = t2 ?? oe2;
        return (a2 ? new URL(n2, a2) : new URL(n2)).origin === Qr2;
      } catch {
        return false;
      }
    }, us2 = (n2, t2) => {
      let a2 = t2 ?? oe2;
      try {
        return (a2 ? new URL(n2, a2) : new URL(n2)).href;
      } catch {
        return;
      }
    }, fs2 = (n2, t2) => `${t2 ?? "./"}${n2}`, eo2 = async (n2) => {
      let a2 = await (await fetch(n2, { credentials: "same-origin" })).blob();
      return URL.createObjectURL(a2);
    }, cs2 = async (n2) => (await import(
      /*webpackIgnore:true*/
      /*@vite-ignore*/
      n2
    )).default, Xr2 = (Vr2(), Xt2(jr2)).default, to2 = async () => {
      if (!oe2) throw new Error("Failed to load proxy worker: cannot determine the script source URL.");
      if (on2(oe2)) return [void 0, Xr2()];
      let n2 = await eo2(oe2);
      return [n2, Xr2(n2)];
    }, Zr2 = (Jr2(), Xt2(qr2)).default, no2 = async (n2, t2, a2, u2) => {
      let o2 = Zr2 && !(n2 || t2);
      if (o2) if (oe2) o2 = on2(oe2) || u2 && !a2;
      else if (u2 && !a2) o2 = true;
      else throw new Error("cannot determine the script source URL.");
      if (o2) return [void 0, Zr2];
      {
        let d2 = "ort-wasm-simd-threaded.mjs", c2 = n2 ?? us2(d2, t2), l2 = a2 && c2 && !on2(c2, t2), m2 = l2 ? await eo2(c2) : c2 ?? fs2(d2, t2);
        return [l2 ? m2 : void 0, await cs2(m2)];
      }
    };
  });
  var sn2;
  var un2;
  var St2;
  var ro2;
  var ls2;
  var ds2;
  var ps2;
  var mt2;
  var z2;
  var xe2 = N2(() => {
    "use strict";
    pt2();
    un2 = false, St2 = false, ro2 = false, ls2 = () => {
      if (typeof SharedArrayBuffer > "u") return false;
      try {
        return typeof MessageChannel < "u" && new MessageChannel().port1.postMessage(new SharedArrayBuffer(1)), WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 5, 4, 1, 3, 1, 1, 10, 11, 1, 9, 0, 65, 0, 254, 16, 2, 0, 26, 11]));
      } catch {
        return false;
      }
    }, ds2 = () => {
      try {
        return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 4, 1, 96, 0, 0, 3, 2, 1, 0, 10, 30, 1, 28, 0, 65, 0, 253, 15, 253, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 253, 186, 1, 26, 11]));
      } catch {
        return false;
      }
    }, ps2 = () => {
      try {
        return WebAssembly.validate(new Uint8Array([0, 97, 115, 109, 1, 0, 0, 0, 1, 5, 1, 96, 0, 1, 123, 3, 2, 1, 0, 10, 19, 1, 17, 0, 65, 1, 253, 15, 65, 2, 253, 15, 65, 3, 253, 15, 253, 147, 2, 11]));
      } catch {
        return false;
      }
    }, mt2 = async (n2) => {
      if (un2) return Promise.resolve();
      if (St2) throw new Error("multiple calls to 'initializeWebAssembly()' detected.");
      if (ro2) throw new Error("previous call to 'initializeWebAssembly()' failed.");
      St2 = true;
      let t2 = n2.initTimeout, a2 = n2.numThreads;
      if (n2.simd !== false) {
        if (n2.simd === "relaxed") {
          if (!ps2()) throw new Error("Relaxed WebAssembly SIMD is not supported in the current environment.");
        } else if (!ds2()) throw new Error("WebAssembly SIMD is not supported in the current environment.");
      }
      let u2 = ls2();
      a2 > 1 && !u2 && (typeof self < "u" && !self.crossOriginIsolated && console.warn("env.wasm.numThreads is set to " + a2 + ", but this will not work unless you enable crossOriginIsolated mode. See https://web.dev/cross-origin-isolation-guide/ for more info."), console.warn("WebAssembly multi-threading is not supported in the current environment. Falling back to single-threading."), n2.numThreads = a2 = 1);
      let o2 = n2.wasmPaths, d2 = typeof o2 == "string" ? o2 : void 0, c2 = o2?.mjs, l2 = c2?.href ?? c2, m2 = o2?.wasm, h2 = m2?.href ?? m2, g2 = n2.wasmBinary, [b2, y3] = await no2(l2, d2, a2 > 1, !!g2 || !!h2), T2 = false, I2 = [];
      if (t2 > 0 && I2.push(new Promise((D2) => {
        setTimeout(() => {
          T2 = true, D2();
        }, t2);
      })), I2.push(new Promise((D2, $2) => {
        let v2 = { numThreads: a2 };
        if (g2) v2.wasmBinary = g2, v2.locateFile = (A2) => A2;
        else if (h2 || d2) v2.locateFile = (A2) => h2 ?? d2 + A2;
        else if (l2 && l2.indexOf("blob:") !== 0) v2.locateFile = (A2) => new URL(A2, l2).href;
        else if (b2) {
          let A2 = Kr2();
          A2 && (v2.locateFile = (F2) => A2 + F2);
        }
        y3(v2).then((A2) => {
          St2 = false, un2 = true, sn2 = A2, D2(), b2 && URL.revokeObjectURL(b2);
        }, (A2) => {
          St2 = false, ro2 = true, $2(A2);
        });
      })), await Promise.race(I2), T2) throw new Error(`WebAssembly backend initializing failed due to timeout: ${t2}ms`);
    }, z2 = () => {
      if (un2 && sn2) return sn2;
      throw new Error("WebAssembly is not initialized yet.");
    };
  });
  var ae2;
  var Qe2;
  var G2;
  var vt2 = N2(() => {
    "use strict";
    xe2();
    ae2 = (n2, t2) => {
      let a2 = z2(), u2 = a2.lengthBytesUTF8(n2) + 1, o2 = a2._malloc(u2);
      return a2.stringToUTF8(n2, o2, u2), t2.push(o2), o2;
    }, Qe2 = (n2, t2, a2, u2) => {
      if (typeof n2 == "object" && n2 !== null) {
        if (a2.has(n2)) throw new Error("Circular reference in options");
        a2.add(n2);
      }
      Object.entries(n2).forEach(([o2, d2]) => {
        let c2 = t2 ? t2 + o2 : o2;
        if (typeof d2 == "object") Qe2(d2, c2 + ".", a2, u2);
        else if (typeof d2 == "string" || typeof d2 == "number") u2(c2, d2.toString());
        else if (typeof d2 == "boolean") u2(c2, d2 ? "1" : "0");
        else throw new Error(`Can't handle extra config type: ${typeof d2}`);
      });
    }, G2 = (n2) => {
      let t2 = z2(), a2 = t2.stackSave();
      try {
        let u2 = t2.PTR_SIZE, o2 = t2.stackAlloc(2 * u2);
        t2._OrtGetLastError(o2, o2 + u2);
        let d2 = Number(t2.getValue(o2, u2 === 4 ? "i32" : "i64")), c2 = t2.getValue(o2 + u2, "*"), l2 = c2 ? t2.UTF8ToString(c2) : "";
        throw new Error(`${n2} ERROR_CODE: ${d2}, ERROR_MESSAGE: ${l2}`);
      } finally {
        t2.stackRestore(a2);
      }
    };
  });
  var oo2;
  var ao2 = N2(() => {
    "use strict";
    xe2();
    vt2();
    oo2 = (n2) => {
      let t2 = z2(), a2 = 0, u2 = [], o2 = n2 || {};
      try {
        if (n2?.logSeverityLevel === void 0) o2.logSeverityLevel = 2;
        else if (typeof n2.logSeverityLevel != "number" || !Number.isInteger(n2.logSeverityLevel) || n2.logSeverityLevel < 0 || n2.logSeverityLevel > 4) throw new Error(`log severity level is not valid: ${n2.logSeverityLevel}`);
        if (n2?.logVerbosityLevel === void 0) o2.logVerbosityLevel = 0;
        else if (typeof n2.logVerbosityLevel != "number" || !Number.isInteger(n2.logVerbosityLevel)) throw new Error(`log verbosity level is not valid: ${n2.logVerbosityLevel}`);
        n2?.terminate === void 0 && (o2.terminate = false);
        let d2 = 0;
        return n2?.tag !== void 0 && (d2 = ae2(n2.tag, u2)), a2 = t2._OrtCreateRunOptions(o2.logSeverityLevel, o2.logVerbosityLevel, !!o2.terminate, d2), a2 === 0 && G2("Can't create run options."), n2?.extra !== void 0 && Qe2(n2.extra, "", /* @__PURE__ */ new WeakSet(), (c2, l2) => {
          let m2 = ae2(c2, u2), h2 = ae2(l2, u2);
          t2._OrtAddRunConfigEntry(a2, m2, h2) !== 0 && G2(`Can't set a run config entry: ${c2} - ${l2}.`);
        }), [a2, u2];
      } catch (d2) {
        throw a2 !== 0 && t2._OrtReleaseRunOptions(a2), u2.forEach((c2) => t2._free(c2)), d2;
      }
    };
  });
  var ms2;
  var hs2;
  var ws2;
  var ke2;
  var bs2;
  var so2;
  var io2 = N2(() => {
    "use strict";
    xe2();
    vt2();
    ms2 = (n2) => {
      switch (n2) {
        case "disabled":
          return 0;
        case "basic":
          return 1;
        case "extended":
          return 2;
        case "layout":
          return 3;
        case "all":
          return 99;
        default:
          throw new Error(`unsupported graph optimization level: ${n2}`);
      }
    }, hs2 = (n2) => {
      switch (n2) {
        case "sequential":
          return 0;
        case "parallel":
          return 1;
        default:
          throw new Error(`unsupported execution mode: ${n2}`);
      }
    }, ws2 = (n2) => {
      n2.extra || (n2.extra = {}), n2.extra.session || (n2.extra.session = {});
      let t2 = n2.extra.session;
      t2.use_ort_model_bytes_directly || (t2.use_ort_model_bytes_directly = "1"), n2.executionProviders && n2.executionProviders.some((a2) => (typeof a2 == "string" ? a2 : a2.name) === "webgpu") && (n2.enableMemPattern = false);
    }, ke2 = (n2, t2, a2, u2) => {
      let o2 = ae2(t2, u2), d2 = ae2(a2, u2);
      z2()._OrtAddSessionConfigEntry(n2, o2, d2) !== 0 && G2(`Can't set a session config entry: ${t2} - ${a2}.`);
    }, bs2 = async (n2, t2, a2) => {
      let u2 = t2.executionProviders;
      for (let o2 of u2) {
        let d2 = typeof o2 == "string" ? o2 : o2.name, c2 = [];
        switch (d2) {
          case "webnn":
            if (d2 = "WEBNN", ke2(n2, "session.disable_quant_qdq", "1", a2), ke2(n2, "session.disable_qdq_constant_folding", "1", a2), typeof o2 != "string") {
              let y3 = o2?.deviceType;
              y3 && ke2(n2, "deviceType", y3, a2);
            }
            break;
          case "webgpu":
            if (d2 = "JS", typeof o2 != "string") {
              let b2 = o2;
              if (b2?.preferredLayout) {
                if (b2.preferredLayout !== "NCHW" && b2.preferredLayout !== "NHWC") throw new Error(`preferredLayout must be either 'NCHW' or 'NHWC': ${b2.preferredLayout}`);
                ke2(n2, "preferredLayout", b2.preferredLayout, a2);
              }
            }
            break;
          case "wasm":
          case "cpu":
            continue;
          default:
            throw new Error(`not supported execution provider: ${d2}`);
        }
        let l2 = ae2(d2, a2), m2 = c2.length, h2 = 0, g2 = 0;
        if (m2 > 0) {
          h2 = z2()._malloc(m2 * z2().PTR_SIZE), a2.push(h2), g2 = z2()._malloc(m2 * z2().PTR_SIZE), a2.push(g2);
          for (let b2 = 0; b2 < m2; b2++) z2().setValue(h2 + b2 * z2().PTR_SIZE, c2[b2][0], "*"), z2().setValue(g2 + b2 * z2().PTR_SIZE, c2[b2][1], "*");
        }
        await z2()._OrtAppendExecutionProvider(n2, l2, h2, g2, m2) !== 0 && G2(`Can't append execution provider: ${d2}.`);
      }
    }, so2 = async (n2) => {
      let t2 = z2(), a2 = 0, u2 = [], o2 = n2 || {};
      ws2(o2);
      try {
        let d2 = ms2(o2.graphOptimizationLevel ?? "all"), c2 = hs2(o2.executionMode ?? "sequential"), l2 = typeof o2.logId == "string" ? ae2(o2.logId, u2) : 0, m2 = o2.logSeverityLevel ?? 2;
        if (!Number.isInteger(m2) || m2 < 0 || m2 > 4) throw new Error(`log severity level is not valid: ${m2}`);
        let h2 = o2.logVerbosityLevel ?? 0;
        if (!Number.isInteger(h2) || h2 < 0 || h2 > 4) throw new Error(`log verbosity level is not valid: ${h2}`);
        let g2 = typeof o2.optimizedModelFilePath == "string" ? ae2(o2.optimizedModelFilePath, u2) : 0;
        if (a2 = t2._OrtCreateSessionOptions(d2, !!o2.enableCpuMemArena, !!o2.enableMemPattern, c2, !!o2.enableProfiling, 0, l2, m2, h2, g2), a2 === 0 && G2("Can't create session options."), o2.executionProviders && await bs2(a2, o2, u2), o2.enableGraphCapture !== void 0) {
          if (typeof o2.enableGraphCapture != "boolean") throw new Error(`enableGraphCapture must be a boolean value: ${o2.enableGraphCapture}`);
          ke2(a2, "enableGraphCapture", o2.enableGraphCapture.toString(), u2);
        }
        if (o2.freeDimensionOverrides) for (let [b2, y3] of Object.entries(o2.freeDimensionOverrides)) {
          if (typeof b2 != "string") throw new Error(`free dimension override name must be a string: ${b2}`);
          if (typeof y3 != "number" || !Number.isInteger(y3) || y3 < 0) throw new Error(`free dimension override value must be a non-negative integer: ${y3}`);
          let T2 = ae2(b2, u2);
          t2._OrtAddFreeDimensionOverride(a2, T2, y3) !== 0 && G2(`Can't set a free dimension override: ${b2} - ${y3}.`);
        }
        return o2.extra !== void 0 && Qe2(o2.extra, "", /* @__PURE__ */ new WeakSet(), (b2, y3) => {
          ke2(a2, b2, y3, u2);
        }), [a2, u2];
      } catch (d2) {
        throw a2 !== 0 && t2._OrtReleaseSessionOptions(a2) !== 0 && G2("Can't release session options."), u2.forEach((c2) => t2._free(c2)), d2;
      }
    };
  });
  var We2;
  var At2;
  var Ge2;
  var uo2;
  var fo2;
  var Ot2;
  var It2;
  var co2;
  var fn2 = N2(() => {
    "use strict";
    We2 = (n2) => {
      switch (n2) {
        case "int8":
          return 3;
        case "uint8":
          return 2;
        case "bool":
          return 9;
        case "int16":
          return 5;
        case "uint16":
          return 4;
        case "int32":
          return 6;
        case "uint32":
          return 12;
        case "float16":
          return 10;
        case "float32":
          return 1;
        case "float64":
          return 11;
        case "string":
          return 8;
        case "int64":
          return 7;
        case "uint64":
          return 13;
        case "int4":
          return 22;
        case "uint4":
          return 21;
        default:
          throw new Error(`unsupported data type: ${n2}`);
      }
    }, At2 = (n2) => {
      switch (n2) {
        case 3:
          return "int8";
        case 2:
          return "uint8";
        case 9:
          return "bool";
        case 5:
          return "int16";
        case 4:
          return "uint16";
        case 6:
          return "int32";
        case 12:
          return "uint32";
        case 10:
          return "float16";
        case 1:
          return "float32";
        case 11:
          return "float64";
        case 8:
          return "string";
        case 7:
          return "int64";
        case 13:
          return "uint64";
        case 22:
          return "int4";
        case 21:
          return "uint4";
        default:
          throw new Error(`unsupported data type: ${n2}`);
      }
    }, Ge2 = (n2, t2) => {
      let a2 = [-1, 4, 1, 1, 2, 2, 4, 8, -1, 1, 2, 8, 4, 8, -1, -1, -1, -1, -1, -1, -1, 0.5, 0.5][n2], u2 = typeof t2 == "number" ? t2 : t2.reduce((o2, d2) => o2 * d2, 1);
      return a2 > 0 ? Math.ceil(u2 * a2) : void 0;
    }, uo2 = (n2) => {
      switch (n2) {
        case "float16":
          return typeof Float16Array < "u" ? Float16Array : Uint16Array;
        case "float32":
          return Float32Array;
        case "uint8":
          return Uint8Array;
        case "int8":
          return Int8Array;
        case "uint16":
          return Uint16Array;
        case "int16":
          return Int16Array;
        case "int32":
          return Int32Array;
        case "bool":
          return Uint8Array;
        case "float64":
          return Float64Array;
        case "uint32":
          return Uint32Array;
        case "int64":
          return BigInt64Array;
        case "uint64":
          return BigUint64Array;
        default:
          throw new Error(`unsupported type: ${n2}`);
      }
    }, fo2 = (n2) => {
      switch (n2) {
        case "verbose":
          return 0;
        case "info":
          return 1;
        case "warning":
          return 2;
        case "error":
          return 3;
        case "fatal":
          return 4;
        default:
          throw new Error(`unsupported logging level: ${n2}`);
      }
    }, Ot2 = (n2) => n2 === "float32" || n2 === "float16" || n2 === "int32" || n2 === "int64" || n2 === "uint32" || n2 === "uint8" || n2 === "bool" || n2 === "uint4" || n2 === "int4", It2 = (n2) => n2 === "float32" || n2 === "float16" || n2 === "int32" || n2 === "int64" || n2 === "uint32" || n2 === "uint64" || n2 === "int8" || n2 === "uint8" || n2 === "bool" || n2 === "uint4" || n2 === "int4", co2 = (n2) => {
      switch (n2) {
        case "none":
          return 0;
        case "cpu":
          return 1;
        case "cpu-pinned":
          return 2;
        case "texture":
          return 3;
        case "gpu-buffer":
          return 4;
        case "ml-tensor":
          return 5;
        default:
          throw new Error(`unsupported data location: ${n2}`);
      }
    };
  });
  var Ke2;
  var cn2 = N2(() => {
    "use strict";
    dt2();
    Ke2 = async (n2) => {
      if (typeof n2 == "string") if (false) try {
        let { readFile: t2 } = Jt2("node:fs/promises");
        return new Uint8Array(await t2(n2));
      } catch (t2) {
        if (t2.code === "ERR_FS_FILE_TOO_LARGE") {
          let { createReadStream: a2 } = Jt2("node:fs"), u2 = a2(n2), o2 = [];
          for await (let d2 of u2) o2.push(d2);
          return new Uint8Array(Buffer.concat(o2));
        }
        throw t2;
      }
      else {
        let t2 = await fetch(n2);
        if (!t2.ok) throw new Error(`failed to load external data file: ${n2}`);
        let a2 = t2.headers.get("Content-Length"), u2 = a2 ? parseInt(a2, 10) : 0;
        if (u2 < 1073741824) return new Uint8Array(await t2.arrayBuffer());
        {
          if (!t2.body) throw new Error(`failed to load external data file: ${n2}, no response body.`);
          let o2 = t2.body.getReader(), d2;
          try {
            d2 = new ArrayBuffer(u2);
          } catch (l2) {
            if (l2 instanceof RangeError) {
              let m2 = Math.ceil(u2 / 65536);
              d2 = new WebAssembly.Memory({ initial: m2, maximum: m2 }).buffer;
            } else throw l2;
          }
          let c2 = 0;
          for (; ; ) {
            let { done: l2, value: m2 } = await o2.read();
            if (l2) break;
            let h2 = m2.byteLength;
            new Uint8Array(d2, c2, h2).set(m2), c2 += h2;
          }
          return new Uint8Array(d2, 0, u2);
        }
      }
      else return n2 instanceof Blob ? new Uint8Array(await n2.arrayBuffer()) : n2 instanceof Uint8Array ? n2 : new Uint8Array(n2);
    };
  });
  var ys2;
  var ht2;
  var wt2;
  var $e2;
  var gs2;
  var lo2;
  var Ze2;
  var bt2;
  var yt2;
  var po2;
  var gt2;
  var Et2;
  var Tt2;
  var rn2 = N2(() => {
    "use strict";
    Te2();
    ao2();
    io2();
    fn2();
    xe2();
    vt2();
    cn2();
    ys2 = (n2, t2) => {
      z2()._OrtInit(n2, t2) !== 0 && G2("Can't initialize onnxruntime.");
    }, ht2 = async (n2) => {
      ys2(n2.wasm.numThreads, fo2(n2.logLevel));
    }, wt2 = async (n2, t2) => {
      z2().asyncInit?.();
      let a2 = n2.webgpu.adapter;
      if (t2 === "webgpu") {
        if (typeof navigator > "u" || !navigator.gpu) throw new Error("WebGPU is not supported in current environment");
        if (a2) {
          if (typeof a2.limits != "object" || typeof a2.features != "object" || typeof a2.requestDevice != "function") throw new Error("Invalid GPU adapter set in `env.webgpu.adapter`. It must be a GPUAdapter object.");
        } else {
          let u2 = n2.webgpu.powerPreference;
          if (u2 !== void 0 && u2 !== "low-power" && u2 !== "high-performance") throw new Error(`Invalid powerPreference setting: "${u2}"`);
          let o2 = n2.webgpu.forceFallbackAdapter;
          if (o2 !== void 0 && typeof o2 != "boolean") throw new Error(`Invalid forceFallbackAdapter setting: "${o2}"`);
          if (a2 = await navigator.gpu.requestAdapter({ powerPreference: u2, forceFallbackAdapter: o2 }), !a2) throw new Error('Failed to get GPU adapter. You may need to enable flag "--enable-unsafe-webgpu" if you are using Chrome.');
        }
      }
      if (t2 === "webnn" && (typeof navigator > "u" || !navigator.ml)) throw new Error("WebNN is not supported in current environment");
    }, $e2 = /* @__PURE__ */ new Map(), gs2 = (n2) => {
      let t2 = z2(), a2 = t2.stackSave();
      try {
        let u2 = t2.PTR_SIZE, o2 = t2.stackAlloc(2 * u2);
        t2._OrtGetInputOutputCount(n2, o2, o2 + u2) !== 0 && G2("Can't get session input/output count.");
        let c2 = u2 === 4 ? "i32" : "i64";
        return [Number(t2.getValue(o2, c2)), Number(t2.getValue(o2 + u2, c2))];
      } finally {
        t2.stackRestore(a2);
      }
    }, lo2 = (n2, t2) => {
      let a2 = z2(), u2 = a2.stackSave(), o2 = 0;
      try {
        let d2 = a2.PTR_SIZE, c2 = a2.stackAlloc(2 * d2);
        a2._OrtGetInputOutputMetadata(n2, t2, c2, c2 + d2) !== 0 && G2("Can't get session input/output metadata.");
        let m2 = Number(a2.getValue(c2, "*"));
        o2 = Number(a2.getValue(c2 + d2, "*"));
        let h2 = a2.HEAP32[o2 / 4];
        if (h2 === 0) return [m2, 0];
        let g2 = a2.HEAPU32[o2 / 4 + 1], b2 = [];
        for (let y3 = 0; y3 < g2; y3++) {
          let T2 = Number(a2.getValue(o2 + 8 + y3 * d2, "*"));
          b2.push(T2 !== 0 ? a2.UTF8ToString(T2) : Number(a2.getValue(o2 + 8 + (y3 + g2) * d2, "*")));
        }
        return [m2, h2, b2];
      } finally {
        a2.stackRestore(u2), o2 !== 0 && a2._OrtFree(o2);
      }
    }, Ze2 = (n2) => {
      let t2 = z2(), a2 = t2._malloc(n2.byteLength);
      if (a2 === 0) throw new Error(`Can't create a session. failed to allocate a buffer of size ${n2.byteLength}.`);
      return t2.HEAPU8.set(n2, a2), [a2, n2.byteLength];
    }, bt2 = async (n2, t2) => {
      let a2, u2, o2 = z2();
      Array.isArray(n2) ? [a2, u2] = n2 : n2.buffer === o2.HEAPU8.buffer ? [a2, u2] = [n2.byteOffset, n2.byteLength] : [a2, u2] = Ze2(n2);
      let d2 = 0, c2 = 0, l2 = 0, m2 = [], h2 = [], g2 = [];
      try {
        if ([c2, m2] = await so2(t2), t2?.externalData && o2.mountExternalData) {
          let P2 = [];
          for (let k2 of t2.externalData) {
            let w2 = typeof k2 == "string" ? k2 : k2.path, Q2 = typeof k2 == "string" ? k2 : k2.data;
            P2.push(Ke2(Q2).then((H2) => {
              o2.mountExternalData(w2, H2);
            }));
          }
          await Promise.all(P2);
        }
        for (let P2 of t2?.executionProviders ?? []) if ((typeof P2 == "string" ? P2 : P2.name) === "webnn") {
          if (o2.shouldTransferToMLTensor = false, typeof P2 != "string") {
            let w2 = P2, Q2 = w2?.context, H2 = w2?.gpuDevice, ne2 = w2?.deviceType, pe2 = w2?.powerPreference;
            Q2 ? o2.currentContext = Q2 : H2 ? o2.currentContext = await o2.webnnCreateMLContext(H2) : o2.currentContext = await o2.webnnCreateMLContext({ deviceType: ne2, powerPreference: pe2 });
          } else o2.currentContext = await o2.webnnCreateMLContext();
          break;
        }
        d2 = await o2._OrtCreateSession(a2, u2, c2), o2.webgpuOnCreateSession?.(d2), d2 === 0 && G2("Can't create a session."), o2.jsepOnCreateSession?.(), o2.currentContext && (o2.webnnRegisterMLContext(d2, o2.currentContext), o2.currentContext = void 0, o2.shouldTransferToMLTensor = true);
        let [b2, y3] = gs2(d2), T2 = !!t2?.enableGraphCapture, I2 = [], D2 = [], $2 = [], v2 = [], A2 = [];
        for (let P2 = 0; P2 < b2; P2++) {
          let [k2, w2, Q2] = lo2(d2, P2);
          k2 === 0 && G2("Can't get an input name."), h2.push(k2);
          let H2 = o2.UTF8ToString(k2);
          I2.push(H2), $2.push(w2 === 0 ? { name: H2, isTensor: false } : { name: H2, isTensor: true, type: At2(w2), shape: Q2 });
        }
        for (let P2 = 0; P2 < y3; P2++) {
          let [k2, w2, Q2] = lo2(d2, P2 + b2);
          k2 === 0 && G2("Can't get an output name."), g2.push(k2);
          let H2 = o2.UTF8ToString(k2);
          D2.push(H2), v2.push(w2 === 0 ? { name: H2, isTensor: false } : { name: H2, isTensor: true, type: At2(w2), shape: Q2 });
        }
        return $e2.set(d2, [d2, h2, g2, null, T2, false]), [d2, I2, D2, $2, v2];
      } catch (b2) {
        throw h2.forEach((y3) => o2._OrtFree(y3)), g2.forEach((y3) => o2._OrtFree(y3)), l2 !== 0 && o2._OrtReleaseBinding(l2) !== 0 && G2("Can't release IO binding."), d2 !== 0 && o2._OrtReleaseSession(d2) !== 0 && G2("Can't release session."), b2;
      } finally {
        o2._free(a2), c2 !== 0 && o2._OrtReleaseSessionOptions(c2) !== 0 && G2("Can't release session options."), m2.forEach((b2) => o2._free(b2)), o2.unmountExternalData?.();
      }
    }, yt2 = (n2) => {
      let t2 = z2(), a2 = $e2.get(n2);
      if (!a2) throw new Error(`cannot release session. invalid session id: ${n2}`);
      let [u2, o2, d2, c2, l2] = a2;
      c2 && (l2 && t2._OrtClearBoundOutputs(c2.handle) !== 0 && G2("Can't clear bound outputs."), t2._OrtReleaseBinding(c2.handle) !== 0 && G2("Can't release IO binding.")), t2.jsepOnReleaseSession?.(n2), t2.webnnOnReleaseSession?.(n2), t2.webgpuOnReleaseSession?.(n2), o2.forEach((m2) => t2._OrtFree(m2)), d2.forEach((m2) => t2._OrtFree(m2)), t2._OrtReleaseSession(u2) !== 0 && G2("Can't release session."), $e2.delete(n2);
    }, po2 = async (n2, t2, a2, u2, o2, d2, c2 = false) => {
      if (!n2) {
        t2.push(0);
        return;
      }
      let l2 = z2(), m2 = l2.PTR_SIZE, h2 = n2[0], g2 = n2[1], b2 = n2[3], y3 = b2, T2, I2;
      if (h2 === "string" && (b2 === "gpu-buffer" || b2 === "ml-tensor")) throw new Error("String tensor is not supported on GPU.");
      if (c2 && b2 !== "gpu-buffer") throw new Error(`External buffer must be provided for input/output index ${d2} when enableGraphCapture is true.`);
      if (b2 === "gpu-buffer") {
        let v2 = n2[2].gpuBuffer;
        I2 = Ge2(We2(h2), g2);
        {
          let A2 = l2.jsepRegisterBuffer;
          if (!A2) throw new Error('Tensor location "gpu-buffer" is not supported without using WebGPU.');
          T2 = A2(u2, d2, v2, I2);
        }
      } else if (b2 === "ml-tensor") {
        let v2 = n2[2].mlTensor;
        I2 = Ge2(We2(h2), g2);
        let A2 = l2.webnnRegisterMLTensor;
        if (!A2) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
        T2 = A2(u2, v2, We2(h2), g2);
      } else {
        let v2 = n2[2];
        if (Array.isArray(v2)) {
          I2 = m2 * v2.length, T2 = l2._malloc(I2), a2.push(T2);
          for (let A2 = 0; A2 < v2.length; A2++) {
            if (typeof v2[A2] != "string") throw new TypeError(`tensor data at index ${A2} is not a string`);
            l2.setValue(T2 + A2 * m2, ae2(v2[A2], a2), "*");
          }
        } else {
          let A2 = l2.webnnIsGraphInput, F2 = l2.webnnIsGraphOutput;
          if (h2 !== "string" && A2 && F2) {
            let P2 = l2.UTF8ToString(o2);
            if (A2(u2, P2) || F2(u2, P2)) {
              let k2 = We2(h2);
              I2 = Ge2(k2, g2), y3 = "ml-tensor";
              let w2 = l2.webnnCreateTemporaryTensor, Q2 = l2.webnnUploadTensor;
              if (!w2 || !Q2) throw new Error('Tensor location "ml-tensor" is not supported without using WebNN.');
              let H2 = await w2(u2, k2, g2);
              Q2(H2, new Uint8Array(v2.buffer, v2.byteOffset, v2.byteLength)), T2 = H2;
            } else I2 = v2.byteLength, T2 = l2._malloc(I2), a2.push(T2), l2.HEAPU8.set(new Uint8Array(v2.buffer, v2.byteOffset, I2), T2);
          } else I2 = v2.byteLength, T2 = l2._malloc(I2), a2.push(T2), l2.HEAPU8.set(new Uint8Array(v2.buffer, v2.byteOffset, I2), T2);
        }
      }
      let D2 = l2.stackSave(), $2 = l2.stackAlloc(4 * g2.length);
      try {
        g2.forEach((A2, F2) => l2.setValue($2 + F2 * m2, A2, m2 === 4 ? "i32" : "i64"));
        let v2 = l2._OrtCreateTensor(We2(h2), T2, I2, $2, g2.length, co2(y3));
        v2 === 0 && G2(`Can't create tensor for input/output. session=${u2}, index=${d2}.`), t2.push(v2);
      } finally {
        l2.stackRestore(D2);
      }
    }, gt2 = async (n2, t2, a2, u2, o2, d2) => {
      let c2 = z2(), l2 = c2.PTR_SIZE, m2 = $e2.get(n2);
      if (!m2) throw new Error(`cannot run inference. invalid session id: ${n2}`);
      let h2 = m2[0], g2 = m2[1], b2 = m2[2], y3 = m2[3], T2 = m2[4], I2 = m2[5], D2 = t2.length, $2 = u2.length, v2 = 0, A2 = [], F2 = [], P2 = [], k2 = [], w2 = [], Q2 = c2.stackSave(), H2 = c2.stackAlloc(D2 * l2), ne2 = c2.stackAlloc(D2 * l2), pe2 = c2.stackAlloc($2 * l2), B2 = c2.stackAlloc($2 * l2);
      try {
        [v2, A2] = oo2(d2), Pe2("wasm prepareInputOutputTensor");
        for (let O2 = 0; O2 < D2; O2++) await po2(a2[O2], F2, k2, n2, g2[t2[O2]], t2[O2], T2);
        for (let O2 = 0; O2 < $2; O2++) await po2(o2[O2], P2, k2, n2, b2[u2[O2]], D2 + u2[O2], T2);
        Ue2("wasm prepareInputOutputTensor");
        for (let O2 = 0; O2 < D2; O2++) c2.setValue(H2 + O2 * l2, F2[O2], "*"), c2.setValue(ne2 + O2 * l2, g2[t2[O2]], "*");
        for (let O2 = 0; O2 < $2; O2++) c2.setValue(pe2 + O2 * l2, P2[O2], "*"), c2.setValue(B2 + O2 * l2, b2[u2[O2]], "*");
        c2.jsepOnRunStart?.(h2), c2.webnnOnRunStart?.(h2);
        let W2;
        W2 = await c2._OrtRun(h2, ne2, H2, D2, B2, $2, pe2, v2), W2 !== 0 && G2("failed to call OrtRun().");
        let re2 = [], me2 = [];
        Pe2("wasm ProcessOutputTensor");
        for (let O2 = 0; O2 < $2; O2++) {
          let K2 = Number(c2.getValue(pe2 + O2 * l2, "*"));
          if (K2 === P2[O2] || w2.includes(P2[O2])) {
            re2.push(o2[O2]), K2 !== P2[O2] && c2._OrtReleaseTensor(K2) !== 0 && G2("Can't release tensor.");
            continue;
          }
          let je2 = c2.stackSave(), ee2 = c2.stackAlloc(4 * l2), he2 = false, j2, J2 = 0;
          try {
            c2._OrtGetTensorData(K2, ee2, ee2 + l2, ee2 + 2 * l2, ee2 + 3 * l2) !== 0 && G2(`Can't access output tensor data on index ${O2}.`);
            let Se2 = l2 === 4 ? "i32" : "i64", ve2 = Number(c2.getValue(ee2, Se2));
            J2 = c2.getValue(ee2 + l2, "*");
            let Ve2 = c2.getValue(ee2 + l2 * 2, "*"), Re2 = Number(c2.getValue(ee2 + l2 * 3, Se2)), te2 = [];
            for (let L2 = 0; L2 < Re2; L2++) te2.push(Number(c2.getValue(Ve2 + L2 * l2, Se2)));
            c2._OrtFree(Ve2) !== 0 && G2("Can't free memory for tensor dims.");
            let ue2 = te2.reduce((L2, V2) => L2 * V2, 1);
            j2 = At2(ve2);
            let se2 = y3?.outputPreferredLocations[u2[O2]];
            if (j2 === "string") {
              if (se2 === "gpu-buffer" || se2 === "ml-tensor") throw new Error("String tensor is not supported on GPU.");
              let L2 = [];
              for (let V2 = 0; V2 < ue2; V2++) {
                let fe2 = c2.getValue(J2 + V2 * l2, "*"), ye2 = c2.getValue(J2 + (V2 + 1) * l2, "*"), ce2 = V2 === ue2 - 1 ? void 0 : ye2 - fe2;
                L2.push(c2.UTF8ToString(fe2, ce2));
              }
              re2.push([j2, te2, L2, "cpu"]);
            } else if (se2 === "gpu-buffer" && ue2 > 0) {
              let L2 = c2.jsepGetBuffer;
              if (!L2) throw new Error('preferredLocation "gpu-buffer" is not supported without using WebGPU.');
              let V2 = L2(J2), fe2 = Ge2(ve2, ue2);
              if (fe2 === void 0 || !Ot2(j2)) throw new Error(`Unsupported data type: ${j2}`);
              he2 = true, re2.push([j2, te2, { gpuBuffer: V2, download: c2.jsepCreateDownloader(V2, fe2, j2), dispose: () => {
                c2._OrtReleaseTensor(K2) !== 0 && G2("Can't release tensor.");
              } }, "gpu-buffer"]);
            } else if (se2 === "ml-tensor" && ue2 > 0) {
              let L2 = c2.webnnEnsureTensor, V2 = c2.webnnIsGraphInputOutputTypeSupported;
              if (!L2 || !V2) throw new Error('preferredLocation "ml-tensor" is not supported without using WebNN.');
              if (Ge2(ve2, ue2) === void 0 || !It2(j2)) throw new Error(`Unsupported data type: ${j2}`);
              if (!V2(n2, j2, false)) throw new Error(`preferredLocation "ml-tensor" for ${j2} output is not supported by current WebNN Context.`);
              let ye2 = await L2(n2, J2, ve2, te2, false);
              he2 = true, re2.push([j2, te2, { mlTensor: ye2, download: c2.webnnCreateMLTensorDownloader(J2, j2), dispose: () => {
                c2.webnnReleaseTensorId(J2), c2._OrtReleaseTensor(K2);
              } }, "ml-tensor"]);
            } else if (se2 === "ml-tensor-cpu-output" && ue2 > 0) {
              let L2 = c2.webnnCreateMLTensorDownloader(J2, j2)(), V2 = re2.length;
              he2 = true, me2.push((async () => {
                let fe2 = [V2, await L2];
                return c2.webnnReleaseTensorId(J2), c2._OrtReleaseTensor(K2), fe2;
              })()), re2.push([j2, te2, [], "cpu"]);
            } else {
              let L2 = uo2(j2), V2 = new L2(ue2);
              new Uint8Array(V2.buffer, V2.byteOffset, V2.byteLength).set(c2.HEAPU8.subarray(J2, J2 + V2.byteLength)), re2.push([j2, te2, V2, "cpu"]);
            }
          } finally {
            c2.stackRestore(je2), j2 === "string" && J2 && c2._free(J2), he2 || c2._OrtReleaseTensor(K2);
          }
        }
        y3 && !T2 && (c2._OrtClearBoundOutputs(y3.handle) !== 0 && G2("Can't clear bound outputs."), $e2.set(n2, [h2, g2, b2, y3, T2, false]));
        for (let [O2, K2] of await Promise.all(me2)) re2[O2][2] = K2;
        return Ue2("wasm ProcessOutputTensor"), re2;
      } finally {
        c2.webnnOnRunEnd?.(h2), c2.stackRestore(Q2), F2.forEach((W2) => c2._OrtReleaseTensor(W2)), P2.forEach((W2) => c2._OrtReleaseTensor(W2)), k2.forEach((W2) => c2._free(W2)), v2 !== 0 && c2._OrtReleaseRunOptions(v2), A2.forEach((W2) => c2._free(W2));
      }
    }, Et2 = (n2) => {
      let t2 = z2(), a2 = $e2.get(n2);
      if (!a2) throw new Error("invalid session id");
      let u2 = a2[0], o2 = t2._OrtEndProfiling(u2);
      o2 === 0 && G2("Can't get an profile file name."), t2._OrtFree(o2);
    }, Tt2 = (n2) => {
      let t2 = [];
      for (let a2 of n2) {
        let u2 = a2[2];
        !Array.isArray(u2) && "buffer" in u2 && t2.push(u2.buffer);
      }
      return t2;
    };
  });
  var Me2;
  var ie2;
  var et2;
  var Lt2;
  var _t2;
  var Bt2;
  var ln2;
  var dn2;
  var ze2;
  var He2;
  var Ts2;
  var mo2;
  var ho2;
  var wo2;
  var bo2;
  var yo2;
  var go2;
  var Eo2;
  var pn2 = N2(() => {
    "use strict";
    Te2();
    rn2();
    xe2();
    pt2();
    Me2 = () => !!Y2.wasm.proxy && typeof document < "u", et2 = false, Lt2 = false, _t2 = false, dn2 = /* @__PURE__ */ new Map(), ze2 = (n2, t2) => {
      let a2 = dn2.get(n2);
      a2 ? a2.push(t2) : dn2.set(n2, [t2]);
    }, He2 = () => {
      if (et2 || !Lt2 || _t2 || !ie2) throw new Error("worker not ready");
    }, Ts2 = (n2) => {
      switch (n2.data.type) {
        case "init-wasm":
          et2 = false, n2.data.err ? (_t2 = true, ln2[1](n2.data.err)) : (Lt2 = true, ln2[0]()), Bt2 && (URL.revokeObjectURL(Bt2), Bt2 = void 0);
          break;
        case "init-ep":
        case "copy-from":
        case "create":
        case "release":
        case "run":
        case "end-profiling": {
          let t2 = dn2.get(n2.data.type);
          n2.data.err ? t2.shift()[1](n2.data.err) : t2.shift()[0](n2.data.out);
          break;
        }
        default:
      }
    }, mo2 = async () => {
      if (!Lt2) {
        if (et2) throw new Error("multiple calls to 'initWasm()' detected.");
        if (_t2) throw new Error("previous call to 'initWasm()' failed.");
        if (et2 = true, Me2()) return new Promise((n2, t2) => {
          ie2?.terminate(), to2().then(([a2, u2]) => {
            try {
              ie2 = u2, ie2.onerror = (d2) => t2(d2), ie2.onmessage = Ts2, ln2 = [n2, t2];
              let o2 = { type: "init-wasm", in: Y2 };
              !o2.in.wasm.wasmPaths && (a2 || an2) && (o2.in.wasm.wasmPaths = { wasm: new URL("ort-wasm-simd-threaded.wasm", import_meta.url).href }), ie2.postMessage(o2), Bt2 = a2;
            } catch (o2) {
              t2(o2);
            }
          }, t2);
        });
        try {
          await mt2(Y2.wasm), await ht2(Y2), Lt2 = true;
        } catch (n2) {
          throw _t2 = true, n2;
        } finally {
          et2 = false;
        }
      }
    }, ho2 = async (n2) => {
      if (Me2()) return He2(), new Promise((t2, a2) => {
        ze2("init-ep", [t2, a2]);
        let u2 = { type: "init-ep", in: { epName: n2, env: Y2 } };
        ie2.postMessage(u2);
      });
      await wt2(Y2, n2);
    }, wo2 = async (n2) => Me2() ? (He2(), new Promise((t2, a2) => {
      ze2("copy-from", [t2, a2]);
      let u2 = { type: "copy-from", in: { buffer: n2 } };
      ie2.postMessage(u2, [n2.buffer]);
    })) : Ze2(n2), bo2 = async (n2, t2) => {
      if (Me2()) {
        if (t2?.preferredOutputLocation) throw new Error('session option "preferredOutputLocation" is not supported for proxy.');
        return He2(), new Promise((a2, u2) => {
          ze2("create", [a2, u2]);
          let o2 = { type: "create", in: { model: n2, options: { ...t2 } } }, d2 = [];
          n2 instanceof Uint8Array && d2.push(n2.buffer), ie2.postMessage(o2, d2);
        });
      } else return bt2(n2, t2);
    }, yo2 = async (n2) => {
      if (Me2()) return He2(), new Promise((t2, a2) => {
        ze2("release", [t2, a2]);
        let u2 = { type: "release", in: n2 };
        ie2.postMessage(u2);
      });
      yt2(n2);
    }, go2 = async (n2, t2, a2, u2, o2, d2) => {
      if (Me2()) {
        if (a2.some((c2) => c2[3] !== "cpu")) throw new Error("input tensor on GPU is not supported for proxy.");
        if (o2.some((c2) => c2)) throw new Error("pre-allocated output tensor is not supported for proxy.");
        return He2(), new Promise((c2, l2) => {
          ze2("run", [c2, l2]);
          let m2 = a2, h2 = { type: "run", in: { sessionId: n2, inputIndices: t2, inputs: m2, outputIndices: u2, options: d2 } };
          ie2.postMessage(h2, Tt2(m2));
        });
      } else return gt2(n2, t2, a2, u2, o2, d2);
    }, Eo2 = async (n2) => {
      if (Me2()) return He2(), new Promise((t2, a2) => {
        ze2("end-profiling", [t2, a2]);
        let u2 = { type: "end-profiling", in: n2 };
        ie2.postMessage(u2);
      });
      Et2(n2);
    };
  });
  var To2;
  var Ss2;
  var Dt2;
  var So2 = N2(() => {
    "use strict";
    Te2();
    pn2();
    fn2();
    dt2();
    cn2();
    To2 = (n2, t2) => {
      switch (n2.location) {
        case "cpu":
          return [n2.type, n2.dims, n2.data, "cpu"];
        case "gpu-buffer":
          return [n2.type, n2.dims, { gpuBuffer: n2.gpuBuffer }, "gpu-buffer"];
        case "ml-tensor":
          return [n2.type, n2.dims, { mlTensor: n2.mlTensor }, "ml-tensor"];
        default:
          throw new Error(`invalid data location: ${n2.location} for ${t2()}`);
      }
    }, Ss2 = (n2) => {
      switch (n2[3]) {
        case "cpu":
          return new de2(n2[0], n2[2], n2[1]);
        case "gpu-buffer": {
          let t2 = n2[0];
          if (!Ot2(t2)) throw new Error(`not supported data type: ${t2} for deserializing GPU tensor`);
          let { gpuBuffer: a2, download: u2, dispose: o2 } = n2[2];
          return de2.fromGpuBuffer(a2, { dataType: t2, dims: n2[1], download: u2, dispose: o2 });
        }
        case "ml-tensor": {
          let t2 = n2[0];
          if (!It2(t2)) throw new Error(`not supported data type: ${t2} for deserializing MLTensor tensor`);
          let { mlTensor: a2, download: u2, dispose: o2 } = n2[2];
          return de2.fromMLTensor(a2, { dataType: t2, dims: n2[1], download: u2, dispose: o2 });
        }
        default:
          throw new Error(`invalid data location: ${n2[3]}`);
      }
    }, Dt2 = class {
      async fetchModelAndCopyToWasmMemory(t2) {
        return wo2(await Ke2(t2));
      }
      async loadModel(t2, a2) {
        _e2();
        let u2;
        typeof t2 == "string" ? u2 = await this.fetchModelAndCopyToWasmMemory(t2) : u2 = t2, [this.sessionId, this.inputNames, this.outputNames, this.inputMetadata, this.outputMetadata] = await bo2(u2, a2), De2();
      }
      async dispose() {
        return yo2(this.sessionId);
      }
      async run(t2, a2, u2) {
        _e2();
        let o2 = [], d2 = [];
        Object.entries(t2).forEach((y3) => {
          let T2 = y3[0], I2 = y3[1], D2 = this.inputNames.indexOf(T2);
          if (D2 === -1) throw new Error(`invalid input '${T2}'`);
          o2.push(I2), d2.push(D2);
        });
        let c2 = [], l2 = [];
        Object.entries(a2).forEach((y3) => {
          let T2 = y3[0], I2 = y3[1], D2 = this.outputNames.indexOf(T2);
          if (D2 === -1) throw new Error(`invalid output '${T2}'`);
          c2.push(I2), l2.push(D2);
        });
        let m2 = o2.map((y3, T2) => To2(y3, () => `input "${this.inputNames[d2[T2]]}"`)), h2 = c2.map((y3, T2) => y3 ? To2(y3, () => `output "${this.outputNames[l2[T2]]}"`) : null), g2 = await go2(this.sessionId, d2, m2, l2, h2, u2), b2 = {};
        for (let y3 = 0; y3 < g2.length; y3++) b2[this.outputNames[l2[y3]]] = c2[y3] ?? Ss2(g2[y3]);
        return De2(), b2;
      }
      startProfiling() {
      }
      endProfiling() {
        Eo2(this.sessionId);
      }
    };
  });
  var Ao2 = {};
  ut2(Ao2, { OnnxruntimeWebAssemblyBackend: () => Pt2, initializeFlags: () => vo2, wasmBackend: () => vs2 });
  var vo2;
  var Pt2;
  var vs2;
  var Oo2 = N2(() => {
    "use strict";
    Te2();
    pn2();
    So2();
    vo2 = () => {
      (typeof Y2.wasm.initTimeout != "number" || Y2.wasm.initTimeout < 0) && (Y2.wasm.initTimeout = 0);
      let n2 = Y2.wasm.simd;
      if (typeof n2 != "boolean" && n2 !== void 0 && n2 !== "fixed" && n2 !== "relaxed" && (console.warn(`Property "env.wasm.simd" is set to unknown value "${n2}". Reset it to \`false\` and ignore SIMD feature checking.`), Y2.wasm.simd = false), typeof Y2.wasm.proxy != "boolean" && (Y2.wasm.proxy = false), typeof Y2.wasm.trace != "boolean" && (Y2.wasm.trace = false), typeof Y2.wasm.numThreads != "number" || !Number.isInteger(Y2.wasm.numThreads) || Y2.wasm.numThreads <= 0) if (typeof self < "u" && !self.crossOriginIsolated) Y2.wasm.numThreads = 1;
      else {
        let t2 = typeof navigator > "u" ? Jt2("node:os").cpus().length : navigator.hardwareConcurrency;
        Y2.wasm.numThreads = Math.min(4, Math.ceil((t2 || 1) / 2));
      }
    }, Pt2 = class {
      async init(t2) {
        vo2(), await mo2(), await ho2(t2);
      }
      async createInferenceSessionHandler(t2, a2) {
        let u2 = new Dt2();
        return await u2.loadModel(t2, a2), u2;
      }
    }, vs2 = new Pt2();
  });
  Te2();
  Te2();
  Te2();
  var $r2 = "1.30.0";
  {
    let n2 = (Oo2(), Xt2(Ao2)).wasmBackend;
    Je2("cpu", n2, 10), Je2("wasm", n2, 10);
  }
  Object.defineProperty(Y2.versions, "web", { value: $r2, enumerable: true });

  // src/asl/landmarks.ts
  var N_FACE = 468;
  var N_HAND = 21;
  var N_POSE = 33;
  var N_POINTS = N_FACE + N_HAND + N_POSE + N_HAND;
  var FRAME_LENGTH = N_POINTS * 3;
  var LEFT_HAND_START = N_FACE;
  var POSE_START = LEFT_HAND_START + N_HAND;
  var RIGHT_HAND_START = POSE_START + N_POSE;
  var POSE_UPPER = [0, 2, 5, 7, 8, 11, 12, 13, 14, 15, 16];
  var POSE_UPPER_MIRROR = [0, 5, 2, 8, 7, 12, 11, 14, 13, 16, 15];
  var POSE_LEFT_SHOULDER = 11;
  var POSE_RIGHT_SHOULDER = 12;
  var POSE_LEFT_WRIST = 15;
  var POSE_RIGHT_WRIST = 16;
  var LIP_RUNS = [
    [61, 146, 91, 181, 84, 17, 314, 405, 321, 375, 291],
    [185, 40, 39, 37, 0, 267, 269, 270, 409],
    [78, 95, 88, 178, 87, 14, 317, 402, 318, 324, 308],
    [191, 80, 81, 82, 13, 312, 311, 310, 415]
  ];
  var LIPS = LIP_RUNS.flat();
  var LIPS_MIRROR = LIP_RUNS.flatMap((run) => [...run].reverse());
  var HAND_WRIST = 0;
  var HAND_MIDDLE_MCP = 9;
  function handsMissing(frame) {
    return Number.isNaN(frame[LEFT_HAND_START * 3] ?? Number.NaN) && Number.isNaN(frame[RIGHT_HAND_START * 3] ?? Number.NaN);
  }

  // src/asl/assemble.ts
  function write(frame, start, points2, count) {
    for (let i2 = 0; i2 < count; i2++) {
      const p2 = points2[i2];
      if (!p2) continue;
      frame[(start + i2) * 3] = p2.x;
      frame[(start + i2) * 3 + 1] = p2.y;
      frame[(start + i2) * 3 + 2] = p2.z;
    }
  }
  function dist(a2, b2) {
    if (!a2 || !b2) return Number.POSITIVE_INFINITY;
    return Math.hypot(a2.x - b2.x, a2.y - b2.y);
  }
  function assignSides(hands, pose) {
    if (hands.every((h2) => h2.side)) return hands.map((h2) => h2.side ?? "right");
    if (pose && pose.length >= N_POSE) {
      const left = pose[POSE_LEFT_WRIST];
      const right = pose[POSE_RIGHT_WRIST];
      const toLeft = hands.map((h2) => dist(h2.points[0], left));
      const toRight = hands.map((h2) => dist(h2.points[0], right));
      if (hands.length === 1) return [(toLeft[0] ?? 0) < (toRight[0] ?? 0) ? "left" : "right"];
      const straight = (toRight[0] ?? 0) + (toLeft[1] ?? 0);
      const swapped = (toLeft[0] ?? 0) + (toRight[1] ?? 0);
      return straight <= swapped ? ["right", "left"] : ["left", "right"];
    }
    return hands.map((h2) => h2.side ?? (h2.label === "Left" ? "right" : "left"));
  }
  function assembleFrame(detection) {
    const frame = new Float32Array(FRAME_LENGTH).fill(Number.NaN);
    if (detection.face && detection.face.length >= N_FACE) write(frame, 0, detection.face, N_FACE);
    if (detection.pose && detection.pose.length >= N_POSE) {
      write(frame, POSE_START, detection.pose, N_POSE);
    }
    const hands = detection.hands.slice(0, 2);
    const sides = assignSides(hands, detection.pose);
    const used = /* @__PURE__ */ new Set();
    hands.forEach((hand, i2) => {
      const side = sides[i2] ?? "right";
      if (used.has(side)) return;
      used.add(side);
      write(frame, side === "left" ? LEFT_HAND_START : RIGHT_HAND_START, hand.points, N_HAND);
    });
    return frame;
  }

  // src/asl/features.ts
  var DEFAULT_ANCHOR = { cx: 0.5, cy: 0.5, scale: 0.25, yScale: 0.25 };
  var MIN_SCALE = 1e-3;
  var FACE_RATIO_REF = 0.43;
  var FACE_RATIO_MIN = 0.2;
  var FACE_RATIO_MAX = 1.2;
  function featureLayout(featureSet) {
    const hand = N_HAND * 2;
    const pose = POSE_UPPER.length * 2;
    const lips = featureSet === "hands_pose_lips" ? LIPS.length * 2 : 0;
    const positions = 2 * hand + pose + lips;
    const parts = lips ? 4 : 3;
    const frameDim = positions + 2 * hand + parts;
    return { frameDim, sequenceDim: frameDim + positions, positions };
  }
  var x2 = (f2, point) => f2[point * 3] ?? Number.NaN;
  var y2 = (f2, point) => f2[point * 3 + 1] ?? Number.NaN;
  function median(values) {
    const sorted = [...values].sort((a2, b2) => a2 - b2);
    const mid = sorted.length >> 1;
    if (sorted.length % 2) return sorted[mid] ?? Number.NaN;
    return ((sorted[mid - 1] ?? Number.NaN) + (sorted[mid] ?? Number.NaN)) / 2;
  }
  function faceRatio(frames) {
    const ratios = [];
    const p2 = (i2) => POSE_START + i2;
    for (const f2 of frames) {
      const eyeX = (x2(f2, p2(2)) + x2(f2, p2(5))) / 2;
      const eyeY = (y2(f2, p2(2)) + y2(f2, p2(5))) / 2;
      const mouthX = (x2(f2, p2(9)) + x2(f2, p2(10))) / 2;
      const mouthY = (y2(f2, p2(9)) + y2(f2, p2(10))) / 2;
      const vertical = Math.hypot(eyeX - mouthX, eyeY - mouthY);
      const horizontal = Math.hypot(x2(f2, p2(7)) - x2(f2, p2(8)), y2(f2, p2(7)) - y2(f2, p2(8)));
      if (Number.isFinite(vertical) && Number.isFinite(horizontal) && horizontal > 1e-4) {
        ratios.push(vertical / horizontal);
      }
    }
    if (ratios.length === 0) return null;
    return Math.min(Math.max(median(ratios), FACE_RATIO_MIN), FACE_RATIO_MAX);
  }
  function computeAnchor(frames) {
    const cxs = [];
    const cys = [];
    const widths = [];
    const l2 = POSE_START + POSE_LEFT_SHOULDER;
    const r2 = POSE_START + POSE_RIGHT_SHOULDER;
    for (const f2 of frames) {
      const lx = x2(f2, l2);
      const ly = y2(f2, l2);
      const rx = x2(f2, r2);
      const ry = y2(f2, r2);
      if (![lx, ly, rx, ry].every(Number.isFinite)) continue;
      cxs.push((lx + rx) / 2);
      cys.push((ly + ry) / 2);
      widths.push(Math.hypot(lx - rx, ly - ry));
    }
    let cx = DEFAULT_ANCHOR.cx;
    let cy = DEFAULT_ANCHOR.cy;
    let scale = DEFAULT_ANCHOR.scale;
    if (cxs.length > 0) {
      scale = median(widths);
      if (!(scale > MIN_SCALE)) scale = DEFAULT_ANCHOR.scale;
      cx = median(cxs);
      cy = median(cys);
    }
    const ratio = faceRatio(frames);
    return { cx, cy, scale, yScale: ratio === null ? scale : scale * ratio / FACE_RATIO_REF };
  }
  function handSeen(f2, start) {
    for (let i2 = 0; i2 < N_HAND; i2++) if (Number.isFinite(x2(f2, start + i2))) return true;
    return false;
  }
  function wristTravel(frames, start) {
    let total = 0;
    for (let t2 = 1; t2 < frames.length; t2++) {
      const a2 = frames[t2 - 1];
      const b2 = frames[t2];
      if (!a2 || !b2) continue;
      const step = Math.abs(x2(b2, start + HAND_WRIST) - x2(a2, start + HAND_WRIST)) + Math.abs(y2(b2, start + HAND_WRIST) - y2(a2, start + HAND_WRIST));
      if (Number.isFinite(step)) total += step;
    }
    return total;
  }
  function leftIsDominant(frames) {
    let left = 0;
    let right = 0;
    for (const f2 of frames) {
      if (handSeen(f2, LEFT_HAND_START)) left++;
      if (handSeen(f2, RIGHT_HAND_START)) right++;
    }
    if (left !== right) return left > right;
    return wristTravel(frames, LEFT_HAND_START) > wristTravel(frames, RIGHT_HAND_START);
  }
  function range(start, n2) {
    return Array.from({ length: n2 }, (_2, i2) => start + i2);
  }
  function indices(featureSet, mirror) {
    const left = range(LEFT_HAND_START, N_HAND);
    const right = range(RIGHT_HAND_START, N_HAND);
    const pose = (mirror ? POSE_UPPER_MIRROR : POSE_UPPER).map((i2) => POSE_START + i2);
    const lips = featureSet === "hands_pose_lips" ? [...mirror ? LIPS_MIRROR : LIPS] : [];
    return {
      dominant: mirror ? left : right,
      other: mirror ? right : left,
      body: [...pose, ...lips],
      nPose: POSE_UPPER.length
    };
  }
  function frameBlock(f2, featureSet, anchor, mirror) {
    const idx = indices(featureSet, mirror);
    const layout = featureLayout(featureSet);
    const sign = mirror ? -1 : 1;
    const positions = new Float64Array(layout.positions);
    let p2 = 0;
    for (const point of [...idx.dominant, ...idx.other, ...idx.body]) {
      positions[p2++] = (x2(f2, point) - anchor.cx) / anchor.scale * sign;
      positions[p2++] = (y2(f2, point) - anchor.cy) / anchor.yScale;
    }
    const features = new Float64Array(layout.frameDim);
    features.set(positions, 0);
    let o2 = layout.positions;
    for (const handOffset of [0, N_HAND * 2]) {
      const wx = positions[handOffset + HAND_WRIST * 2] ?? Number.NaN;
      const wy = positions[handOffset + HAND_WRIST * 2 + 1] ?? Number.NaN;
      const refX = (positions[handOffset + HAND_MIDDLE_MCP * 2] ?? Number.NaN) - wx;
      const refY = (positions[handOffset + HAND_MIDDLE_MCP * 2 + 1] ?? Number.NaN) - wy;
      let size = Math.hypot(refX, refY);
      if (!(Number.isFinite(size) && size > 1e-6)) size = 1;
      for (let i2 = 0; i2 < N_HAND; i2++) {
        features[o2++] = ((positions[handOffset + i2 * 2] ?? Number.NaN) - wx) / size;
        features[o2++] = ((positions[handOffset + i2 * 2 + 1] ?? Number.NaN) - wy) / size;
      }
    }
    const anyX = (from, count) => {
      for (let i2 = 0; i2 < count; i2++) {
        if (Number.isFinite(positions[(from + i2) * 2] ?? Number.NaN)) return 1;
      }
      return 0;
    };
    features[o2++] = anyX(0, N_HAND);
    features[o2++] = anyX(N_HAND, N_HAND);
    features[o2++] = anyX(2 * N_HAND, idx.nPose);
    if (featureSet === "hands_pose_lips") features[o2] = anyX(2 * N_HAND + idx.nPose, LIPS.length);
    for (let i2 = 0; i2 < features.length; i2++) {
      if (!Number.isFinite(features[i2] ?? Number.NaN)) features[i2] = 0;
    }
    return { features, positions };
  }
  function sequenceFeatures(frames, featureSet) {
    const layout = featureLayout(featureSet);
    const out = new Float32Array(frames.length * layout.sequenceDim);
    if (frames.length === 0) return out;
    const anchor = computeAnchor(frames);
    const mirror = leftIsDominant(frames);
    let previous = null;
    frames.forEach((f2, t2) => {
      const { features, positions } = frameBlock(f2, featureSet, anchor, mirror);
      const row = t2 * layout.sequenceDim;
      out.set(features, row);
      if (previous) {
        for (let i2 = 0; i2 < layout.positions; i2++) {
          const now = positions[i2] ?? Number.NaN;
          const before = previous[i2] ?? Number.NaN;
          out[row + layout.frameDim + i2] = Number.isFinite(now) && Number.isFinite(before) ? now - before : 0;
        }
      }
      previous = positions;
    });
    return out;
  }
  function resampledLength(T2, srcFps, dstFps) {
    if (T2 <= 1) return T2;
    return Math.floor((T2 - 1) * dstFps / srcFps + 1e-9) + 1;
  }
  function interpolate(seq, positions) {
    const T2 = seq.length;
    return positions.map((u2) => {
      const i0 = Math.min(Math.floor(u2), T2 - 1);
      const i1 = Math.min(i0 + 1, T2 - 1);
      const w2 = u2 - i0;
      const a2 = seq[i0];
      const b2 = seq[i1];
      if (!a2 || !b2) throw new Error("interpolate: index out of range");
      const out = new Float32Array(a2.length);
      for (let k2 = 0; k2 < a2.length; k2++) {
        const va2 = a2[k2] ?? Number.NaN;
        const vb = b2[k2] ?? Number.NaN;
        out[k2] = Number.isFinite(va2) && Number.isFinite(vb) ? va2 + (vb - va2) * w2 : w2 < 0.5 ? va2 : vb;
      }
      return out;
    });
  }
  function resample(seq, srcFps, dstFps) {
    const T2 = seq.length;
    const n2 = resampledLength(T2, srcFps, dstFps);
    if (n2 === T2 && srcFps === dstFps || T2 <= 1) return [...seq];
    return interpolate(
      seq,
      Array.from({ length: n2 }, (_2, k2) => k2 * srcFps / dstFps)
    );
  }
  function fitLength(seq, maxLen) {
    const T2 = seq.length;
    if (maxLen >= T2) return [...seq];
    return interpolate(
      seq,
      Array.from({ length: maxLen }, (_2, k2) => k2 * (T2 - 1) / (maxLen - 1))
    );
  }
  function modelInput(frames, srcFps, cfg) {
    const fitted = fitLength(resample(frames, srcFps, cfg.fps), cfg.maxFrames);
    const dim = featureLayout(cfg.featureSet).sequenceDim;
    return { data: sequenceFeatures(fitted, cfg.featureSet), frames: fitted.length, dim };
  }

  // src/asl/segmenter.ts
  var DEFAULT_SEGMENTER = {
    gapMs: 300,
    moveSpeed: 0.6,
    minFrames: 8,
    maxMs: 4e3,
    prerollMs: 200,
    leaveMs: 500
  };
  var HAND_STARTS = [LEFT_HAND_START, RIGHT_HAND_START];
  function handSpeed(prev, next) {
    const dt3 = (next.t - prev.t) / 1e3;
    if (!(dt3 > 0)) return 0;
    const { scale } = computeAnchor([next.frame]);
    let total = 0;
    let count = 0;
    for (const start of HAND_STARTS) {
      for (let i2 = 0; i2 < N_HAND; i2++) {
        const k2 = (start + i2) * 3;
        const dx = (next.frame[k2] ?? Number.NaN) - (prev.frame[k2] ?? Number.NaN);
        const dy = (next.frame[k2 + 1] ?? Number.NaN) - (prev.frame[k2 + 1] ?? Number.NaN);
        const d2 = Math.hypot(dx, dy);
        if (Number.isFinite(d2)) {
          total += d2;
          count++;
        }
      }
    }
    return count ? total / count / scale / dt3 : 0;
  }
  var Segmenter = class {
    opts;
    samples = [];
    recent = [];
    last = null;
    speed = 0;
    quietSince = null;
    quietReason = "absent";
    /** The open segment started from a still hold (state 'resting'). */
    fromRest = false;
    fromAppearance = false;
    state = "idle";
    constructor(options = {}) {
      this.opts = { ...DEFAULT_SEGMENTER, ...options };
    }
    reset() {
      this.samples = [];
      this.recent = [];
      this.last = null;
      this.speed = 0;
      this.quietSince = null;
      this.fromRest = false;
      this.fromAppearance = false;
      this.state = "idle";
    }
    /** Feed one frame; returns an event when a segment starts, ends or is discarded. */
    push(frame, t2, flags = {}) {
      const sample = { frame, t: t2 };
      const present = !flags.crowded && !handsMissing(frame);
      const appeared = present && (!this.last || handsMissing(this.last.frame));
      if (present && this.last && !handsMissing(this.last.frame)) {
        this.speed = 0.5 * this.speed + 0.5 * handSpeed(this.last, sample);
      } else if (!present) {
        this.speed = 0;
      }
      this.last = present ? sample : { frame, t: t2 };
      const moving = present && this.speed >= this.opts.moveSpeed;
      if (this.state !== "signing") {
        if (!present) this.state = "idle";
        this.recent = present ? [...this.recent, sample].filter((s2) => t2 - s2.t <= this.opts.prerollMs) : [];
        if (!moving && !appeared) return null;
        this.fromRest = this.state === "resting";
        this.fromAppearance = appeared;
        this.state = "signing";
        this.samples = [...this.recent];
        this.quietSince = null;
        return { type: "start", t: t2 };
      }
      this.samples.push(sample);
      const first = this.samples[0];
      if (first && t2 - first.t >= this.opts.maxMs) {
        const event2 = this.finish("max", this.samples.length);
        this.recent = [];
        return event2;
      }
      if (moving) {
        this.quietSince = null;
        return null;
      }
      if (this.quietSince === null) {
        this.quietSince = t2;
        this.quietReason = present ? "still" : "absent";
      }
      const requiredGap = this.quietReason === "absent" ? Math.min(this.opts.gapMs, 320) : this.opts.gapMs;
      if (t2 - this.quietSince < requiredGap) return null;
      const quietStart = this.quietSince;
      const keep = this.samples.filter((s2) => s2.t < quietStart).length;
      const reason = this.quietReason;
      if (reason === "absent" && this.fromRest) {
        const kept = this.samples.slice(0, keep);
        const span = (kept[kept.length - 1]?.t ?? 0) - (kept[0]?.t ?? 0);
        if (span < this.opts.leaveMs) {
          this.finish(reason, 0);
          return { type: "discard", reason: "hands-leaving" };
        }
      }
      const event = this.finish(reason, reason === "still" ? this.fromAppearance ? this.samples.length : keep + 1 : keep);
      this.state = present ? "resting" : "idle";
      return event;
    }
    /** End any open segment now (e.g. when a replay clip finishes). */
    flush() {
      if (this.state !== "signing") return null;
      const keep = this.quietSince === null ? this.samples.length : this.samples.filter((s2) => s2.t < (this.quietSince ?? 0)).length;
      return this.finish("flush", keep);
    }
    finish(reason, keep) {
      const kept = this.samples.slice(0, Math.max(0, keep));
      this.samples = [];
      this.quietSince = null;
      this.fromAppearance = false;
      this.state = "idle";
      if (kept.length < this.opts.minFrames) return { type: "discard", reason: "too-short" };
      const first = kept[0]?.t ?? 0;
      const lastT = kept[kept.length - 1]?.t ?? first;
      const durationMs = lastT - first;
      const fps = durationMs > 0 ? (kept.length - 1) * 1e3 / durationMs : 30;
      return {
        type: "end",
        reason,
        segment: {
          frames: kept.map((s2) => s2.frame),
          timestamps: kept.map((s2) => s2.t),
          fps,
          durationMs
        }
      };
    }
  };
  function shoulderInView(frame, index) {
    const k2 = (POSE_START + index) * 3;
    const x3 = frame[k2] ?? Number.NaN;
    const y3 = frame[k2 + 1] ?? Number.NaN;
    return x3 >= -0.02 && x3 <= 1.02 && y3 >= -0.02 && y3 <= 1.02;
  }
  function frameStatus(frame, poses) {
    if (poses > 1) return "crowded";
    const noHands = handsMissing(frame);
    if (noHands && poses === 0) return "nothing";
    if (noHands) return "no-hands";
    if (!shoulderInView(frame, POSE_LEFT_SHOULDER) || !shoulderInView(frame, POSE_RIGHT_SHOULDER)) {
      return "partial";
    }
    return "ok";
  }

  // src/asl/alphabet.js
  function normalizeAslHand(hand) {
    if (!hand || hand.points.length !== 21) return null;
    const p2 = hand.points;
    const wrist = p2[0];
    const mcp = p2[9];
    const size = Math.hypot(mcp.x - wrist.x, mcp.y - wrist.y, mcp.z - wrist.z);
    const scale = size > 1e-6 ? size : 1;
    const mirror = hand.side === "right" ? -1 : 1;
    return p2.flatMap((point) => [
      (point.x - wrist.x) / scale * mirror,
      (point.y - wrist.y) / scale,
      (point.z - wrist.z) / scale
    ]);
  }
  function dense(input, kernel, bias, relu) {
    const out = new Float64Array(bias.length);
    for (let j2 = 0; j2 < bias.length; j2++) {
      let sum = bias[j2];
      for (let i2 = 0; i2 < input.length; i2++) sum += input[i2] * kernel[i2][j2];
      out[j2] = relu ? Math.max(0, sum) : sum;
    }
    return out;
  }
  function classifyAslLetter(vector, model) {
    if (!vector || !model || vector.length !== model.featureSize) return null;
    const w2 = model.weights;
    const first = dense(vector, w2[0], w2[1], true);
    const second = dense(first, w2[2], w2[3], true);
    const logits = dense(second, w2[4], w2[5], false);
    const max = Math.max(...logits);
    const probabilities = Array.from(logits, (value) => Math.exp(value - max));
    const total = probabilities.reduce((sum, value) => sum + value, 0);
    let index = 0;
    for (let i2 = 1; i2 < probabilities.length; i2++) {
      if (probabilities[i2] > probabilities[index]) index = i2;
    }
    return { gloss: model.labels[index], score: probabilities[index] / total };
  }

  // src/vision-frame.js
  var landmarker;
  var session;
  var labels = [];
  var alphabet;
  var busy = false;
  var segmenter = new Segmenter({ gapMs: 850, minFrames: 8 });
  var lastLetter = "";
  var letterSince = 0;
  var lastAcceptedLetter = "";
  var lastAcceptedAt = 0;
  var suppressLettersUntilHandsLeave = false;
  var frameStatuses = [];
  var generation = 0;
  function reply(message) {
    window.parent.postMessage(message, "*");
  }
  function url(path) {
    return chrome.runtime.getURL(path);
  }
  function points(list) {
    return (list || []).map(({ x: x3, y: y3, z: z3 }) => ({ x: x3, y: y3, z: z3 }));
  }
  async function initialize() {
    try {
      const [labelData, alphabetData] = await Promise.all([
        fetch(url("assets/asl/labels.json")).then((r2) => r2.json()),
        fetch(url("assets/asl/alphabet-model.json")).then((r2) => r2.json())
      ]);
      labels = labelData.signs;
      alphabet = alphabetData;
      const fileset = await uh.forVisionTasks(url("vendor/mediapipe"));
      try {
        landmarker = await createHolistic(fileset, "GPU");
      } catch {
        landmarker = await createHolistic(fileset, "CPU");
      }
      Y2.wasm.wasmPaths = url("vendor/ort/");
      Y2.wasm.numThreads = 1;
      session = await rs2.create(url("assets/asl/model.onnx"), {
        executionProviders: ["wasm"],
        graphOptimizationLevel: "all"
      });
      globalThis.__signbridgeVisionReady = true;
      reply({ type: "SIGNBRIDGE_VISION_READY", words: labels.filter((item) => item.shipped).length, letters: alphabet.labels.length });
    } catch (error) {
      reply({ type: "SIGNBRIDGE_VISION_ERROR", message: error?.message || String(error) });
    }
  }
  function createHolistic(fileset, delegate) {
    return Fc.createFromOptions(fileset, {
      baseOptions: { modelAssetPath: url("models/holistic_landmarker.task"), delegate },
      runningMode: "VIDEO"
    });
  }
  function softmaxBest(logits) {
    const shipped = labels.filter((item) => item.shipped);
    const max = Math.max(...shipped.map((item) => logits[item.index] / 0.8826538438450513));
    const scores = shipped.map((item) => ({ item, score: Math.exp(logits[item.index] / 0.8826538438450513 - max) }));
    const total = scores.reduce((sum, value) => sum + value.score, 0);
    scores.sort((a2, b2) => b2.score - a2.score);
    const best = scores[0];
    return {
      gloss: best?.item.label?.toUpperCase(),
      score: best?.score / total || 0,
      candidates: scores.slice(0, 3).map(({ item, score }) => ({
        gloss: item.label.toUpperCase(),
        score: score / total
      }))
    };
  }
  async function inferWord(segment) {
    if (busy || !session) return;
    busy = true;
    const startedGeneration = generation;
    try {
      const input = modelInput(segment.frames, segment.fps, { fps: 30, maxFrames: 64, featureSet: "hands_pose_lips" });
      if (input.frames < 8 || input.dim !== 460) return;
      const result = await session.run({ frames: new de2("float32", input.data, [1, input.frames, input.dim]) });
      if (startedGeneration !== generation) return;
      const prediction = softmaxBest(result.logits.data);
      if (prediction.score >= 0.45) {
        lastLetter = "";
        letterSince = 0;
        suppressLettersUntilHandsLeave = true;
        reply({ type: "SIGNBRIDGE_WORD_RESULT", ...prediction });
      } else {
        suppressLettersUntilHandsLeave = true;
        reply({ type: "SIGNBRIDGE_WORD_UNCERTAIN", ...prediction });
      }
    } catch (error) {
      reply({ type: "SIGNBRIDGE_VISION_ERROR", message: `ASL model: ${error?.message || error}` });
    } finally {
      busy = false;
    }
  }
  function handleLetter(hand, now, signing) {
    if (!hand) {
      lastLetter = "";
      letterSince = 0;
      lastAcceptedLetter = "";
      suppressLettersUntilHandsLeave = false;
      return;
    }
    if (signing || suppressLettersUntilHandsLeave) {
      lastLetter = "";
      letterSince = 0;
      return;
    }
    const candidate = classifyAslLetter(normalizeAslHand(hand), alphabet);
    if (!candidate || candidate.score < 0.78) {
      lastLetter = "";
      letterSince = 0;
      return;
    }
    if (candidate.gloss !== lastLetter) {
      lastLetter = candidate.gloss;
      letterSince = now;
      return;
    }
    if (now - letterSince < 1500 || lastAcceptedLetter === candidate.gloss && now - lastAcceptedAt < 4e3) return;
    lastAcceptedLetter = candidate.gloss;
    lastAcceptedAt = now;
    letterSince = now;
    suppressLettersUntilHandsLeave = true;
    reply({ type: "SIGNBRIDGE_LETTER_RESULT", ...candidate });
  }
  window.addEventListener("message", (event) => {
    if (event.source !== window.parent) return;
    if (event.data?.type === "SIGNBRIDGE_VISION_RESET") {
      generation++;
      segmenter.reset();
      frameStatuses = [];
      lastLetter = "";
      letterSince = 0;
      suppressLettersUntilHandsLeave = false;
      return;
    }
    if (event.data?.type !== "SIGNBRIDGE_VISION_FRAME" || !landmarker) return;
    const { bitmap, timestamp } = event.data;
    try {
      const result = landmarker.detectForVideo(bitmap, timestamp);
      const hands = [];
      if (result.leftHandLandmarks?.[0]) hands.push({ points: points(result.leftHandLandmarks[0]), side: "left" });
      if (result.rightHandLandmarks?.[0]) hands.push({ points: points(result.rightHandLandmarks[0]), side: "right" });
      const pose = result.poseLandmarks?.[0];
      const face = result.faceLandmarks?.[0];
      const frame = assembleFrame({ hands, pose: pose ? points(pose) : null, face: face ? points(face) : null });
      const status = frameStatus(frame, result.poseLandmarks?.length || 0);
      const segmentEvent = segmenter.push(frame, timestamp, { crowded: status === "crowded" });
      if (segmenter.state === "signing") frameStatuses.push(status);
      if (segmentEvent?.type === "start") {
        lastLetter = "";
        letterSince = 0;
        frameStatuses = [status];
      }
      if (segmentEvent?.type === "end") {
        const partial = frameStatuses.filter((value) => value === "partial").length;
        const framed = frameStatuses.filter((value) => value === "ok").length + partial;
        if (partial <= framed / 2) inferWord(segmentEvent.segment);
        else reply({ type: "SIGNBRIDGE_WORD_UNCERTAIN", gloss: "", score: 0, reason: "partial" });
        frameStatuses = [];
      }
      if (segmentEvent?.type === "discard") frameStatuses = [];
      handleLetter(hands[0], timestamp, segmenter.state === "signing" || busy);
      reply({
        type: "SIGNBRIDGE_VISION_RESULT",
        timestamp,
        status,
        landmarks: hands.map((hand) => hand.points),
        handedness: hands.map((hand) => [{ categoryName: hand.side === "left" ? "Left" : "Right", score: 1 }])
      });
    } catch (error) {
      reply({ type: "SIGNBRIDGE_VISION_ERROR", message: error?.message || String(error) });
    } finally {
      bitmap?.close?.();
    }
  });
  initialize();
})();
/*! Bundled license information:

onnxruntime-web/dist/ort.wasm.bundle.min.mjs:
  (*!
   * ONNX Runtime Web v1.30.0
   * Copyright (c) Microsoft Corporation. All rights reserved.
   * Licensed under the MIT License.
   *)
*/
