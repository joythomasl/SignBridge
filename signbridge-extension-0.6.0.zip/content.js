(() => {
  // src/vision.js
  var CONNECTIONS = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 4],
    [0, 5],
    [5, 6],
    [6, 7],
    [7, 8],
    [5, 9],
    [9, 10],
    [10, 11],
    [11, 12],
    [9, 13],
    [13, 14],
    [14, 15],
    [15, 16],
    [13, 17],
    [17, 18],
    [18, 19],
    [19, 20],
    [0, 17]
  ];
  var FINGER_COLORS = ["#ffb45f", "#55e6d5", "#78a9ff", "#d68cff", "#ff7ca8"];
  function colorForPoint(index) {
    if (index === 0) return "#ffffff";
    if (index <= 4) return FINGER_COLORS[0];
    if (index <= 8) return FINGER_COLORS[1];
    if (index <= 12) return FINGER_COLORS[2];
    if (index <= 16) return FINGER_COLORS[3];
    return FINGER_COLORS[4];
  }
  var VisionController = class {
    constructor({ video, canvas, fps = 15, onVector, onLetter, onPreview, onTranscript, onModelStatus, onError }) {
      this.video = video;
      this.canvas = canvas;
      this.context = canvas.getContext("2d");
      this.fps = fps;
      this.onVector = onVector;
      this.onLetter = onLetter;
      this.onPreview = onPreview;
      this.onTranscript = onTranscript;
      this.onModelStatus = onModelStatus;
      this.onError = onError;
      this.frame = null;
      this.stream = null;
      this.running = false;
      this.frameRequest = null;
      this.lastInferenceAt = 0;
      this.inFlight = false;
      this.ready = false;
      this.initializePromise = null;
      this.messageHandler = (event) => this.handleMessage(event);
    }
    async initialize() {
      if (this.ready) return;
      if (this.initializePromise) return this.initializePromise;
      this.initializePromise = new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error("MediaPipe runtime timed out")), 2e4);
        this.resolveInitialize = () => {
          clearTimeout(timeout);
          this.ready = true;
          resolve();
        };
        this.rejectInitialize = (error) => {
          clearTimeout(timeout);
          reject(error);
        };
      });
      window.addEventListener("message", this.messageHandler);
      this.frame = document.createElement("iframe");
      this.frame.src = chrome.runtime.getURL("vision.html");
      this.frame.title = "SignBridge vision runtime";
      this.frame.hidden = true;
      this.frame.setAttribute("aria-hidden", "true");
      document.documentElement.appendChild(this.frame);
      return this.initializePromise;
    }
    async start() {
      if (this.running) return this.stream;
      await this.initialize();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 24, max: 30 },
          facingMode: "user"
        },
        audio: false
      });
      this.video.srcObject = this.stream;
      await this.video.play();
      this.running = true;
      this.loop();
      return this.stream;
    }
    stop() {
      this.running = false;
      this.frame?.contentWindow?.postMessage({ type: "SIGNBRIDGE_VISION_RESET" }, "*");
      this.inFlight = false;
      if (this.frameRequest) cancelAnimationFrame(this.frameRequest);
      this.stream?.getTracks().forEach((track) => track.stop());
      this.stream = null;
      this.video.srcObject = null;
      this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    getStream() {
      return this.stream;
    }
    loop = () => {
      if (!this.running) return;
      const now = performance.now();
      const interval = 1e3 / this.fps;
      if (!this.inFlight && this.video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && now - this.lastInferenceAt >= interval) {
        this.lastInferenceAt = now;
        this.sendFrame(now);
      }
      this.frameRequest = requestAnimationFrame(this.loop);
    };
    async sendFrame(timestamp) {
      this.inFlight = true;
      try {
        const bitmap = await createImageBitmap(this.video);
        this.frame.contentWindow.postMessage({ type: "SIGNBRIDGE_VISION_FRAME", timestamp, bitmap }, "*", [bitmap]);
      } catch (error) {
        this.inFlight = false;
        this.onError?.(error);
      }
    }
    handleMessage(event) {
      if (event.source !== this.frame?.contentWindow) return;
      const message = event.data || {};
      if (message.type === "SIGNBRIDGE_VISION_READY") {
        this.modelInfo = { letters: message.letters };
        this.resolveInitialize?.();
        return;
      }
      if (message.type === "SIGNBRIDGE_KAGGLE_READY") {
        this.modelInfo.kaggleReady = true;
        this.onModelStatus?.(true);
        return;
      }
      if (message.type === "SIGNBRIDGE_KAGGLE_ERROR") {
        this.modelInfo.kaggleReady = false;
        this.onModelStatus?.(false, message.message);
        return;
      }
      if (!this.running && message.type !== "SIGNBRIDGE_VISION_ERROR") return;
      if (message.type === "SIGNBRIDGE_LETTER_RESULT") {
        this.onLetter?.(message);
        return;
      }
      if (message.type === "SIGNBRIDGE_LETTER_PREVIEW") {
        this.onPreview?.(message);
        return;
      }
      if (message.type === "SIGNBRIDGE_TRANSCRIPT") {
        this.onTranscript?.(message);
        return;
      }
      if (message.type === "SIGNBRIDGE_VISION_ERROR") {
        this.inFlight = false;
        const error = new Error(message.message || "MediaPipe failed");
        if (!this.ready) this.rejectInitialize?.(error);
        else this.onError?.(error);
        return;
      }
      if (message.type !== "SIGNBRIDGE_VISION_RESULT") return;
      this.inFlight = false;
      const result = {
        landmarks: Array.isArray(message.landmarks) ? message.landmarks : [],
        handedness: Array.isArray(message.handedness) ? message.handedness : []
      };
      this.draw(result);
      if (result.landmarks.length) this.onVector?.(true, result);
      else this.onVector?.(null, result);
    }
    draw(result) {
      const width = this.video.videoWidth || 640;
      const height = this.video.videoHeight || 480;
      if (this.canvas.width !== width) this.canvas.width = width;
      if (this.canvas.height !== height) this.canvas.height = height;
      const context = this.context;
      context.clearRect(0, 0, width, height);
      context.save();
      context.translate(width, 0);
      context.scale(-1, 1);
      context.lineWidth = 3;
      for (const hand of result.landmarks) {
        for (const [start, end] of CONNECTIONS) {
          context.strokeStyle = colorForPoint(end);
          context.beginPath();
          context.moveTo(hand[start].x * width, hand[start].y * height);
          context.lineTo(hand[end].x * width, hand[end].y * height);
          context.stroke();
        }
        hand.forEach((point, index) => {
          context.fillStyle = colorForPoint(index);
          context.beginPath();
          context.arc(point.x * width, point.y * height, 4, 0, Math.PI * 2);
          context.fill();
          if ([0, 4, 8, 12, 16, 20].includes(index)) {
            context.save();
            context.scale(-1, 1);
            context.fillStyle = "#ffffff";
            context.font = "bold 11px system-ui";
            context.fillText(String(index), -point.x * width + 6, point.y * height - 6);
            context.restore();
          }
        });
      }
      context.restore();
    }
  };

  // src/hud.js
  var SignBridgeHud = class {
    constructor(handlers, vocabulary = []) {
      this.handlers = handlers;
      this.vocabulary = vocabulary;
      this.host = document.createElement("div");
      this.host.id = "signbridge-root";
      this.host.dataset.signbridge = "true";
      this.shadow = this.host.attachShadow({ mode: "open" });
      this.shadow.innerHTML = this.template();
      document.documentElement.appendChild(this.host);
      this.bind();
    }
    template() {
      const glossOptions = this.vocabulary.map((item) => `<option value="${item}">${item}</option>`).join("");
      return `
      <link rel="stylesheet" href="${chrome.runtime.getURL("hud.css")}">
      <aside class="sb-shell" aria-label="SignBridge AI">
        <header class="sb-header">
          <div>
            <strong>SignBridge AI</strong>
            <small>Gemma 4 \xB7 ASL fingerspelling A\u2013Z</small>
          </div>
          <div class="sb-header-actions">
            <span id="sb-mode-badge" class="sb-badge">Checking\u2026</span>
            <button id="sb-collapse" class="sb-icon" title="Collapse">\u2212</button>
          </div>
        </header>
        <div id="sb-body" class="sb-body">
          <div id="sb-status" class="sb-status" data-kind="info">Ready to configure</div>

          <section class="sb-section">
            <div class="sb-section-title"><span>1</span> Interviewer question</div>
            <textarea id="sb-question" rows="2" placeholder="Meet captions are detected and translated automatically\u2026"></textarea>
            <small id="sb-caption-state" class="sb-muted">Live caption detection is active</small>
          </section>

          <section class="sb-section sb-sign-output">
            <div class="sb-section-title"><span>2</span> Live interviewer captions</div>
            <div id="sb-interviewer-caption" class="sb-interviewer-caption" aria-live="polite">Waiting for Meet captions\u2026</div>
          </section>

          <section class="sb-section">
            <div class="sb-section-title"><span>3</span> Candidate fingerspelling</div>
            <div class="sb-camera-stage">
              <video id="sb-camera" muted playsinline></video>
              <canvas id="sb-canvas"></canvas>
              <div id="sb-detected" class="sb-detected">No gesture</div>
            </div>
            <div class="sb-row">
              <button id="sb-start-camera" class="sb-primary">Start camera</button>
              <button id="sb-stop-camera" disabled>Stop</button>
            </div>
            <div class="sb-live-banner"><strong>ASL fingerspelling \u2192 local speech + Meet chat</strong><small>The first-place sequence model checks the completed spelling. Hold each letter, then lower your hand to speak.</small></div>
            <div id="sb-live-state" class="sb-muted" data-active="true">Waiting for camera and signs</div>
            <div id="sb-gloss-buffer" class="sb-spelling" aria-live="polite">Spelled letters appear here</div>
            <div class="sb-row"><button id="sb-space">Space</button><button id="sb-backspace">Backspace</button><button id="sb-clear-glosses">Clear</button></div>
            <details class="sb-details">
              <summary>Recognition and manual correction</summary>
              <p class="sb-muted">All 26 letters are available. The live preview uses static handshapes and J/Z motion checks; the sequence model checks the completed spelling. Repeat a letter by briefly releasing your hand. Correct uncertain results below.</p>
              <div class="sb-calibration">
                <select id="sb-calibration-gloss">${glossOptions}</select>
              </div>
              <button id="sb-add-gloss" class="sb-full-button">Add selected letter manually</button>
            </details>
          </section>

          <section class="sb-section">
            <div class="sb-section-title"><span>4</span> Candidate review</div>
            <textarea id="sb-answer" rows="3" placeholder="Spelled text appears here for review\u2026"></textarea>
            <label class="sb-check"><input id="sb-approved" type="checkbox"> I reviewed and approve this wording</label>
            <div class="sb-row sb-wrap">
              <button id="sb-speak" disabled>Speak</button>
              <button id="sb-copy" disabled>Copy</button>
              <button id="sb-chat" disabled>Insert in Meet chat</button>
            </div>
            <div id="sb-metrics" class="sb-muted"></div>
          </section>

          <details class="sb-section sb-details" open>
            <summary>Gemma 4 settings</summary>
            <label>Endpoint<input id="sb-endpoint" type="url" placeholder="http://localhost:11434"></label>
            <label>Model<input id="sb-model" type="text" placeholder="gemma4:e2b-it-q4_K_M"></label>
            <label>API key (optional)<input id="sb-api-key" type="password" autocomplete="off"></label>
            <div class="sb-row">
              <button id="sb-save-settings">Save</button>
              <button id="sb-check-gemma" class="sb-primary">Check Gemma</button>
            </div>
          </details>
        </div>
      </aside>
      <div id="sb-caption-overlay" class="sb-caption-overlay" aria-live="polite" hidden>
        <span>Interviewer</span>
        <strong id="sb-caption-overlay-text"></strong>
      </div>`;
    }
    $(selector) {
      return this.shadow.querySelector(selector);
    }
    bind() {
      const actions = {
        "#sb-start-camera": "startCamera",
        "#sb-stop-camera": "stopCamera",
        "#sb-add-gloss": "addLetter",
        "#sb-space": "addSpace",
        "#sb-backspace": "backspace",
        "#sb-clear-glosses": "clearLetters",
        "#sb-speak": "speak",
        "#sb-copy": "copy",
        "#sb-chat": "insertChat",
        "#sb-save-settings": "saveSettings",
        "#sb-check-gemma": "checkGemma"
      };
      for (const [selector, handler] of Object.entries(actions)) {
        this.$(selector).addEventListener("click", () => this.handlers[handler]?.());
      }
      this.$("#sb-approved").addEventListener("change", (event) => this.setApproved(event.target.checked));
      this.$("#sb-question").addEventListener("input", (event) => this.handlers.questionChanged?.(event.target.value.trim()));
      this.$("#sb-answer").addEventListener("input", () => {
        this.$("#sb-approved").checked = false;
        this.setApproved(false);
      });
      this.$("#sb-collapse").addEventListener("click", () => {
        const body = this.$("#sb-body");
        body.hidden = !body.hidden;
        this.$("#sb-collapse").textContent = body.hidden ? "+" : "\u2212";
      });
    }
    get video() {
      return this.$("#sb-camera");
    }
    get canvas() {
      return this.$("#sb-canvas");
    }
    getQuestion() {
      return this.$("#sb-question").value.trim();
    }
    getAnswer() {
      return this.$("#sb-answer").value.trim();
    }
    getCalibrationGloss() {
      return this.$("#sb-calibration-gloss").value;
    }
    getSettingsForm() {
      return {
        endpoint: this.$("#sb-endpoint").value.trim(),
        model: this.$("#sb-model").value.trim(),
        apiKey: this.$("#sb-api-key").value
      };
    }
    setSettings(settings) {
      this.$("#sb-endpoint").value = settings.endpoint || "";
      this.$("#sb-model").value = settings.model || "";
      this.$("#sb-api-key").value = settings.apiKey || "";
      this.setLiveState("Always-live mode ready \u2014 pause briefly to speak", true);
      this.$("#sb-mode-badge").textContent = settings.endpoint?.includes("localhost") || settings.endpoint?.includes("127.0.0.1") ? "Gemma 4 local" : "Gemma 4 network";
    }
    setStatus(message, kind = "info") {
      const status = this.$("#sb-status");
      status.textContent = message;
      status.dataset.kind = kind;
    }
    setQuestion(question, source = "manual") {
      this.$("#sb-question").value = question;
      this.$("#sb-caption-state").textContent = source === "caption" ? "Latest Meet caption captured" : "Using manual question";
    }
    showLatestCaption(caption) {
      this.$("#sb-caption-state").textContent = `Caption ready: ${caption.slice(0, 70)}${caption.length > 70 ? "\u2026" : ""}`;
      this.$("#sb-caption-overlay-text").textContent = caption;
      this.$("#sb-caption-overlay").hidden = false;
      this.$("#sb-interviewer-caption").textContent = caption;
    }
    setCameraRunning(running) {
      this.$("#sb-start-camera").disabled = running;
      this.$("#sb-stop-camera").disabled = !running;
    }
    setLiveState(message, active = true) {
      const state = this.$("#sb-live-state");
      state.textContent = message;
      state.dataset.active = String(Boolean(active));
    }
    setDetected(match) {
      const label = this.$("#sb-detected");
      if (match?.unstable) label.textContent = "Hand moving \xB7 hold the sign steady";
      else if (!match?.gloss) label.textContent = match?.handPresent ? "Hand tracked \xB7 unknown sign" : "No hand";
      else label.textContent = `${match.gloss} \xB7 ${Math.round(match.score * 100)}%`;
    }
    setPreview(letter) {
      this.$("#sb-detected").textContent = `Hold / change to accept: ${letter}`;
    }
    showWordSuggestions(candidates, onChoose, current = "") {
      const container = this.$("#sb-word-suggestions");
      container.replaceChildren();
      const choices = (candidates || []).filter((item) => item.gloss && item.gloss !== current).slice(0, 3);
      container.hidden = choices.length === 0;
      for (const { gloss, score } of choices) {
        const button = document.createElement("button");
        button.className = "sb-chip";
        button.textContent = `Use ${gloss} \xB7 ${Math.round(score * 100)}%`;
        button.addEventListener("click", () => onChoose(gloss));
        container.appendChild(button);
      }
    }
    setCalibrationState(message, progress = 0) {
      this.$("#sb-calibration-state").textContent = progress ? `${message} ${Math.round(progress * 100)}%` : message;
    }
    renderSpelling(letters) {
      const container = this.$("#sb-gloss-buffer");
      container.textContent = letters.length ? letters.join("") : "Spelled letters appear here";
    }
    setAnswer(answer, needsClarification = false) {
      this.$("#sb-answer").value = answer;
      this.$("#sb-approved").checked = false;
      this.setApproved(false);
      if (needsClarification) this.setStatus("Gemma needs clarification. Review the literal answer before approving.", "warn");
    }
    setApproved(approved) {
      const enabled = approved && Boolean(this.getAnswer());
      ["#sb-speak", "#sb-copy", "#sb-chat"].forEach((selector) => {
        this.$(selector).disabled = !enabled;
      });
    }
    setMetrics(metrics) {
      if (!metrics?.totalDurationNs) {
        this.$("#sb-metrics").textContent = "";
        return;
      }
      this.$("#sb-metrics").textContent = `Gemma 4: ${(metrics.totalDurationNs / 1e9).toFixed(2)}s \xB7 ${metrics.outputTokens || 0} output tokens`;
    }
  };

  // src/meet-adapter.js
  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }
  function isVisible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  function deepQueryAll(selector, root = document) {
    const found = [...root.querySelectorAll(selector)];
    for (const element of root.querySelectorAll("*")) {
      if (element.shadowRoot) found.push(...deepQueryAll(selector, element.shadowRoot));
    }
    return found;
  }
  function belongsToSignBridge(element) {
    if (element.closest?.("#signbridge-root")) return true;
    const root = element.getRootNode?.();
    return root instanceof ShadowRoot && root.host?.closest?.("#signbridge-root");
  }
  function inputText(input) {
    return normalizeText(input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement ? input.value : input.textContent);
  }
  var MeetAdapter = class {
    constructor({ onCaption }) {
      this.onCaption = onCaption;
      this.lastCaption = "";
      this.pendingCaption = "";
      this.captionTimer = null;
      this.observer = null;
    }
    start() {
      this.observer = new MutationObserver((mutations) => this.handleMutations(mutations));
      this.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    stop() {
      this.observer?.disconnect();
      clearTimeout(this.captionTimer);
    }
    handleMutations(mutations) {
      const candidates = [];
      for (const mutation of mutations) {
        const target = mutation.target.nodeType === Node.TEXT_NODE ? mutation.target.parentElement : mutation.target;
        if (!target || target.closest?.("#signbridge-root")) continue;
        const liveRegion = target.closest?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]');
        if (liveRegion) candidates.push({ target, liveRegion });
        for (const node of mutation.addedNodes || []) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          if (node.matches?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]')) candidates.push({ target: node, liveRegion: node });
          node.querySelectorAll?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]').forEach((item) => candidates.push({ target: item, liveRegion: item }));
        }
      }
      const meetCaptions = document.querySelector('[role="region"][aria-label*="caption" i]');
      if (meetCaptions) candidates.push({ target: meetCaptions, liveRegion: meetCaptions });
      for (const { target, liveRegion } of candidates) {
        const text = this.extractCaptionText(target, liveRegion);
        if (this.looksLikeCaption(text)) this.queueCaption(text);
      }
    }
    extractCaptionText(target, liveRegion) {
      let current = target;
      let best = "";
      while (current && current !== liveRegion.parentElement) {
        const text = normalizeText(current.innerText || current.textContent);
        const wordCount = text.split(" ").filter(Boolean).length;
        if (wordCount >= 2 && text.length <= 320) best = text;
        if (current === liveRegion) break;
        current = current.parentElement;
      }
      const lines = String(best || liveRegion.innerText || liveRegion.textContent || "").split(/[\r\n]+/).map(normalizeText).filter(Boolean);
      if (lines.length > 1 && lines[0].length <= 48 && lines[0].split(" ").length <= 5) lines.shift();
      return normalizeText(lines.join(" "));
    }
    looksLikeCaption(text) {
      if (!text || text === this.lastCaption || text.length < 4 || text.length > 320) return false;
      if (/signbridge|you are presenting|microphone|camera|joined|left the call/i.test(text)) return false;
      const words = text.split(" ");
      return words.length >= 2;
    }
    queueCaption(text) {
      this.pendingCaption = text;
      clearTimeout(this.captionTimer);
      this.captionTimer = setTimeout(() => {
        if (!this.pendingCaption || this.pendingCaption === this.lastCaption) return;
        this.lastCaption = this.pendingCaption;
        this.onCaption?.(this.lastCaption);
      }, 900);
    }
    insertChatDraft(text) {
      const input = this.findChatInput();
      if (!input) {
        throw new Error("Meet chat composer was not found. Open in-call messages and try again.");
      }
      if (inputText(input) && inputText(input) !== text) {
        throw new Error("Meet chat already contains an unsent draft. Clear or send it first.");
      }
      input.focus();
      if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
        const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), "value");
        descriptor?.set?.call(input, text);
      } else {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(input);
        selection.removeAllRanges();
        selection.addRange(range);
        if (!document.execCommand("insertText", false, text)) {
          input.textContent = text;
        }
      }
      input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      if (inputText(input) !== normalizeText(text)) throw new Error("Meet did not accept the chat draft.");
      return true;
    }
    findChatInput() {
      const selectors = [
        'div[contenteditable="true"]',
        "textarea",
        'input[type="text"]',
        '[role="textbox"]'
      ];
      const candidates = [...new Set(selectors.flatMap((selector) => deepQueryAll(selector)))];
      return candidates.filter((element) => isVisible(element) && !belongsToSignBridge(element) && !element.disabled && !element.readOnly).map((element) => {
        const attributes = [
          element.getAttribute("aria-label"),
          element.getAttribute("placeholder"),
          element.getAttribute("data-placeholder"),
          element.getAttribute("title")
        ].join(" ").toLowerCase();
        const parent = element.closest('[role="dialog"], [role="region"], form') || element.parentElement;
        const context = [parent?.getAttribute("aria-label"), parent?.textContent?.slice(0, 250)].join(" ").toLowerCase();
        const score = (/message|chat/.test(attributes) ? 10 : 0) + (/message|chat/.test(context) ? 4 : 0) + (element.getAttribute("contenteditable") === "true" ? 2 : 0);
        return { element, score };
      }).filter(({ score }) => score >= 4).sort((a, b) => b.score - a.score)[0]?.element || null;
    }
    async sendChatMessage(text) {
      if (!this.findChatInput()) {
        const chatButton = deepQueryAll('button, [role="button"]').find((button) => isVisible(button) && !belongsToSignBridge(button) && /chat|in.call messages|messages/i.test([
          button.getAttribute("aria-label"),
          button.getAttribute("data-tooltip"),
          button.getAttribute("title"),
          button.textContent?.slice(0, 60)
        ].join(" ")));
        chatButton?.click();
        const startedAt2 = performance.now();
        while (!this.findChatInput() && performance.now() - startedAt2 < 4500) {
          await new Promise((resolve) => setTimeout(resolve, 100));
        }
      }
      this.insertChatDraft(text);
      const input = this.findChatInput();
      if (!input) throw new Error("Meet chat input is not open.");
      const sendButtons = deepQueryAll('button, [role="button"]').filter((button) => isVisible(button) && !belongsToSignBridge(button) && /send/i.test([
        button.getAttribute("aria-label"),
        button.getAttribute("title"),
        button.getAttribute("data-tooltip"),
        button.textContent?.slice(0, 60)
      ].join(" ")));
      const nearest = sendButtons.map((button) => ({ button, common: input.parentElement?.contains(button) || input.parentElement?.parentElement?.contains(button) || input.parentElement?.parentElement?.parentElement?.contains(button) })).sort((a, b) => Number(b.common) - Number(a.common))[0]?.button;
      if (!nearest || nearest.disabled || nearest.getAttribute("aria-disabled") === "true") {
        throw new Error("Meet chat draft is ready, but its Send button is unavailable.");
      }
      nearest.click();
      const startedAt = performance.now();
      while (inputText(input) && performance.now() - startedAt < 1800) {
        await new Promise((resolve) => setTimeout(resolve, 100));
      }
      if (inputText(input)) throw new Error("Meet did not confirm chat delivery; the draft remains in the composer.");
      return true;
    }
  };

  // src/gemma.js
  function runtimeMessage(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, (response) => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else if (!response?.ok) reject(new Error(response?.error || "Gemma request failed"));
        else resolve(response.data);
      });
    });
  }
  function checkGemma(settings) {
    return runtimeMessage({ type: "GEMMA_HEALTH", settings });
  }
  function renderSpelling(settings, spelling) {
    const schema = {
      type: "object",
      properties: {
        answer: { type: "string" }
      },
      required: ["answer"]
    };
    const system = [
      "You format literal ASL fingerspelling in an accessibility prototype.",
      "Return JSON only and obey the supplied schema.",
      "Preserve every letter and word exactly in order. Add only casing and optional final punctuation.",
      "Never infer, autocomplete, correct, translate, or add words. No interviewer question is available."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify({ spelling }) }
      ]
    });
  }
  function refineMeetCaption(settings, caption) {
    const schema = {
      type: "object",
      properties: {
        caption: { type: "string" },
        is_question: { type: "boolean" }
      },
      required: ["caption", "is_question"]
    };
    const system = [
      "You clean one finalized Google Meet caption for accessibility.",
      "Return JSON only and obey the schema.",
      "Preserve the exact meaning, names, technologies, numbers, and negation.",
      "Fix only obvious spacing, casing, punctuation, and unmistakable speech-recognition errors.",
      "Never add facts or rephrase the sentence. Mark whether it is a question."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify({ caption }) }
      ]
    });
  }

  // src/constants.js
  var DEFAULT_SETTINGS = {
    endpoint: "http://localhost:11434",
    model: "gemma4:e2b-it-q4_K_M",
    apiKey: "",
    detectionThreshold: 0.92,
    detectionHoldMs: 750,
    detectionCooldownMs: 1100,
    inferenceFps: 15,
    speechRate: 0.95,
    livePauseMs: 2e3
  };

  // src/storage.js
  async function getSettings() {
    const result = await chrome.storage.local.get("settings");
    return { ...DEFAULT_SETTINGS, ...result.settings || {} };
  }
  async function saveSettings(settings) {
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    await chrome.storage.local.set({ settings: merged });
    return merged;
  }

  // src/content.js
  if (!document.getElementById("signbridge-root")) boot().catch((error) => console.error("SignBridge failed to start", error));
  async function boot() {
    let settings = await getSettings();
    let letters = [];
    let handsPresent = false;
    let liveTimer = null;
    let liveGenerating = false;
    let captionRevision = 0;
    let lastSpokenText = "";
    let lastSpokenAt = 0;
    let manualEdited = false;
    const hud = new SignBridgeHud({
      startCamera,
      stopCamera,
      addLetter,
      addSpace,
      backspace,
      clearLetters,
      speak,
      copy,
      insertChat,
      saveSettings: handleSaveSettings,
      checkGemma: handleCheckGemma,
      questionChanged: (question) => {
        if (question) hud.showLatestCaption(question);
      }
    }, [..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"]);
    hud.setSettings(settings);
    hud.renderSpelling(letters);
    const vision = new VisionController({
      video: hud.video,
      canvas: hud.canvas,
      fps: Math.max(settings.inferenceFps, 20),
      onVector(vector) {
        if (vector) {
          handsPresent = true;
          cancelLiveTimer();
          if (letters.length) hud.setLiveState("Fingerspelling continues \u2014 lower your hand to speak", true);
          else hud.setDetected({ handPresent: true });
        } else {
          if (handsPresent) {
            handsPresent = false;
            scheduleLiveGeneration();
          }
          hud.setDetected(null);
        }
      },
      onLetter(match) {
        if (!/^[A-Z]$/.test(match.gloss)) return;
        letters.push(match.gloss);
        hud.renderSpelling(letters);
        hud.setDetected(match);
        hud.setStatus(`Accepted ASL letter ${match.gloss} (${Math.round(match.score * 100)}%).`, "success");
        if (!handsPresent) scheduleLiveGeneration();
      },
      onPreview(match) {
        if (match.gloss) hud.setPreview(match.gloss);
      },
      onTranscript(match) {
        const text = String(match.text || "").toUpperCase().trim();
        if (manualEdited || match.score < 0.65 || !/^[A-Z ]{1,80}$/.test(text)) {
          hud.setStatus("Sequence model was uncertain; review the held-letter spelling.", "warn");
          return;
        }
        letters = [...text];
        hud.renderSpelling(letters);
        hud.setStatus(`First-place sequence model: ${text} (${Math.round(match.score * 100)}%). Review or correct before speaking.`, "success");
        scheduleLiveGeneration();
      },
      onModelStatus(ready, message) {
        hud.setStatus(ready ? "First-place ASL sequence model ready. A\u2013Z live preview active." : `Sequence model unavailable (${message}); static-letter fallback active.`, ready ? "success" : "warn");
      },
      onError(error) {
        hud.setStatus(`Vision error: ${error.message}`, "error");
      }
    });
    const meet = new MeetAdapter({
      async onCaption(caption) {
        if (isRecentSpokenCaption(caption)) return;
        const revision = ++captionRevision;
        hud.showLatestCaption(caption);
        if (looksLikeQuestion(caption)) hud.setQuestion(caption, "caption");
        try {
          const refined = await refineMeetCaption(settings, caption);
          if (revision !== captionRevision) return;
          const cleaned = String(refined.result?.caption || "").trim();
          if (!cleaned || cleaned.length > 320) return;
          hud.showLatestCaption(cleaned);
          if (refined.result?.is_question) hud.setQuestion(cleaned, "caption");
        } catch {
        }
      }
    });
    meet.start();
    hud.setLiveState("Always-live mode ready \u2014 start the camera", true);
    hud.setStatus("ASL fingerspelling and Meet captions are ready.", "success");
    async function startCamera() {
      try {
        hud.setStatus("Loading local hand tracker and ASL alphabet\u2026", "info");
        await vision.start();
        hud.setCameraRunning(true);
        hud.setStatus(vision.modelInfo.kaggleReady ? "Camera ready. First-place sequence model and A\u2013Z preview loaded." : "Camera ready. A\u2013Z preview loaded; sequence model is loading.", "success");
      } catch (error) {
        hud.setCameraRunning(false);
        hud.setStatus(`Camera unavailable: ${error.message}`, "error");
      }
    }
    function stopCamera() {
      cancelLiveTimer();
      handsPresent = false;
      vision.stop();
      hud.setCameraRunning(false);
      hud.setDetected(null);
      hud.setStatus("Camera stopped.", "info");
    }
    function addLetter() {
      const letter = hud.getCalibrationGloss();
      if (!/^[A-Z]$/.test(letter)) return;
      letters.push(letter);
      manualEdited = true;
      hud.renderSpelling(letters);
      hud.setStatus(`Added ${letter} manually.`, "success");
      scheduleLiveGeneration();
    }
    function addSpace() {
      if (letters.length && letters.at(-1) !== " ") letters.push(" ");
      manualEdited = true;
      hud.renderSpelling(letters);
      scheduleLiveGeneration();
    }
    function backspace() {
      letters.pop();
      manualEdited = true;
      hud.renderSpelling(letters);
      scheduleLiveGeneration();
    }
    function clearLetters() {
      cancelLiveTimer();
      letters = [];
      manualEdited = false;
      hud.renderSpelling(letters);
      hud.setStatus("Current spelling cleared.", "info");
    }
    function scheduleLiveGeneration() {
      if (!letters.some((character) => character !== " ") || handsPresent || liveGenerating) return;
      cancelLiveTimer();
      hud.setLiveState("Hand lowered \u2014 preparing the spelled text", true);
      liveTimer = setTimeout(flushLivePhrase, Math.max(settings.livePauseMs || 0, 2e3));
    }
    async function flushLivePhrase() {
      liveTimer = null;
      if (handsPresent || liveGenerating) return;
      const snapshot = [...letters];
      const literal = snapshot.join("").trim().replace(/\s+/g, " ");
      if (!literal) return;
      liveGenerating = true;
      let answer = literal;
      hud.setLiveState("Rendering fingerspelled text\u2026", true);
      try {
        const response = await renderSpelling(settings, literal);
        const rendered = String(response.result?.answer || "").trim();
        if (sameLetters(rendered, literal)) answer = rendered;
        hud.setMetrics(response.metrics);
      } catch {
        hud.setStatus("Gemma 4 unavailable; using literal fingerspelling.", "warn");
      }
      hud.setAnswer(answer);
      speakText(answer);
      let delivered = false;
      let deliveryError;
      try {
        await meet.sendChatMessage(`\u{1F91F} Candidate via SignBridge: ${answer}`);
        delivered = true;
      } catch (error) {
        deliveryError = error;
      }
      if (snapshot.every((character, index) => letters[index] === character)) letters.splice(0, snapshot.length);
      manualEdited = false;
      hud.renderSpelling(letters);
      hud.setLiveState("Spoken \u2014 ready for the next spelling", true);
      hud.setStatus(delivered ? "Spoken locally and sent in Meet chat." : `Spoken locally. ${deliveryError?.message || "Meet chat delivery unavailable."}`, delivered ? "success" : "warn");
      liveGenerating = false;
      if (letters.length && !handsPresent) scheduleLiveGeneration();
    }
    function cancelLiveTimer() {
      if (liveTimer) clearTimeout(liveTimer);
      liveTimer = null;
    }
    function speakText(text) {
      lastSpokenText = text;
      lastSpokenAt = Date.now();
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "en-IN";
      utterance.rate = settings.speechRate;
      speechSynthesis.speak(utterance);
    }
    function isRecentSpokenCaption(caption) {
      if (!lastSpokenText || Date.now() - lastSpokenAt > 15e3) return false;
      const observed = normalizePhrase(caption), spoken = normalizePhrase(lastSpokenText);
      return observed.length > 10 && (observed.includes(spoken) || spoken.includes(observed));
    }
    function speak() {
      const answer = hud.getAnswer();
      if (answer) speakText(answer);
    }
    async function copy() {
      const answer = hud.getAnswer();
      if (answer) await navigator.clipboard.writeText(answer);
    }
    function insertChat() {
      const answer = hud.getAnswer();
      if (!answer) return;
      try {
        meet.insertChatDraft(`\u{1F91F} Candidate via SignBridge: ${answer}`);
        hud.setStatus("Draft inserted in Meet chat.", "success");
      } catch (error) {
        hud.setStatus(error.message, "warn");
      }
    }
    async function handleSaveSettings() {
      const form = hud.getSettingsForm();
      if (!form.endpoint || !form.model) {
        hud.setStatus("Endpoint and model are required.", "warn");
        return;
      }
      settings = await saveSettings({ ...settings, ...form });
      hud.setSettings(settings);
      hud.setStatus("Gemma 4 settings saved.", "success");
    }
    async function handleCheckGemma() {
      await handleSaveSettings();
      try {
        const health = await checkGemma(settings);
        hud.setStatus(health.installed ? `Gemma 4 ready: ${settings.model}` : `Model ${settings.model} is not installed.`, health.installed ? "success" : "warn");
      } catch (error) {
        hud.setStatus(`Gemma endpoint unavailable: ${error.message}`, "error");
      }
    }
  }
  function normalizePhrase(value) {
    return String(value || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
  }
  function sameLetters(a, b) {
    return normalizePhrase(a) === normalizePhrase(b);
  }
  function looksLikeQuestion(value) {
    return /\b(what|why|how|when|where|who|which|can|could|would|will|do|does|did|have|has|tell|describe|explain|please|walk)\b/.test(normalizePhrase(value));
  }
})();
