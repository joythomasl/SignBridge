(() => {
  // src/recognizer.js
  var HAND_VECTOR_SIZE = 21 * 3;
  function normalizeHand(landmarks, mirrorX = false) {
    if (!landmarks || landmarks.length !== 21) return new Array(HAND_VECTOR_SIZE).fill(0);
    const wrist = landmarks[0];
    const middleMcp = landmarks[9];
    const rawDx = middleMcp.x - wrist.x;
    const rawDy = middleMcp.y - wrist.y;
    const scale = Math.max(Math.hypot(rawDx, rawDy, middleMcp.z - wrist.z), 1e-5);
    const rotation = Math.atan2(rawDy, rawDx) - Math.PI / 2;
    const cos = Math.cos(-rotation);
    const sin = Math.sin(-rotation);
    const vector = [];
    for (const point of landmarks) {
      let x = (point.x - wrist.x) / scale;
      const y = (point.y - wrist.y) / scale;
      const z = (point.z - wrist.z) / scale;
      if (mirrorX) x *= -1;
      vector.push(x * cos - y * sin, x * sin + y * cos, z);
    }
    return vector;
  }
  function landmarksToVector(result) {
    const slots = {
      Left: new Array(HAND_VECTOR_SIZE).fill(0),
      Right: new Array(HAND_VECTOR_SIZE).fill(0)
    };
    (result?.landmarks || []).forEach((landmarks, index) => {
      const handedness = result?.handedness?.[index]?.[0]?.categoryName || (index === 0 ? "Right" : "Left");
      slots[handedness] = normalizeHand(landmarks, handedness === "Left");
    });
    return [...slots.Left, ...slots.Right];
  }
  function averageVectors(vectors) {
    if (!vectors.length) return [];
    const length = vectors[0].length;
    const average = new Array(length).fill(0);
    for (const vector of vectors) {
      for (let i = 0; i < length; i += 1) average[i] += vector[i] || 0;
    }
    return average.map((value) => value / vectors.length);
  }
  function cosineSimilarity(a, b) {
    if (!a?.length || a.length !== b?.length) return 0;
    let dot = 0;
    let normA = 0;
    let normB = 0;
    for (let i = 0; i < a.length; i += 1) {
      dot += a[i] * b[i];
      normA += a[i] * a[i];
      normB += b[i] * b[i];
    }
    if (!normA || !normB) return 0;
    return dot / Math.sqrt(normA * normB);
  }
  function findBestMatch(vector, templates) {
    let best = { gloss: null, score: 0 };
    for (const [gloss, template] of Object.entries(templates || {})) {
      const score = cosineSimilarity(vector, template.vector);
      if (score > best.score) best = { gloss, score };
    }
    return best;
  }
  var StableGestureDetector = class {
    constructor({ threshold, holdMs, cooldownMs, onCandidate, onAccept }) {
      this.threshold = threshold;
      this.holdMs = holdMs;
      this.cooldownMs = cooldownMs;
      this.onCandidate = onCandidate;
      this.onAccept = onAccept;
      this.reset();
    }
    reset() {
      this.candidate = null;
      this.since = 0;
      this.cooldownUntil = 0;
      this.lockedGloss = null;
    }
    update(match, now = performance.now()) {
      if (!match.gloss || match.score < this.threshold || now < this.cooldownUntil) {
        if (!match.gloss || match.score < this.threshold) this.lockedGloss = null;
        this.candidate = null;
        this.since = 0;
        this.onCandidate?.(match);
        return;
      }
      if (this.lockedGloss === match.gloss) {
        this.onCandidate?.(match);
        return;
      }
      if (this.candidate !== match.gloss) {
        this.candidate = match.gloss;
        this.since = now;
        this.onCandidate?.(match);
        return;
      }
      this.onCandidate?.(match);
      if (now - this.since >= this.holdMs) {
        this.onAccept?.(match);
        this.lockedGloss = match.gloss;
        this.cooldownUntil = now + this.cooldownMs;
        this.candidate = null;
        this.since = 0;
      }
    }
  };

  // src/vision.js
  var CONNECTIONS = [
    [0, 1],
    [1, 2],
    [2, 3],
    [3, 4],
    [0, 5],
    [5, 6],
    [6, 7],
    [7, 8],
    [5, 9],
    [9, 10],
    [10, 11],
    [11, 12],
    [9, 13],
    [13, 14],
    [14, 15],
    [15, 16],
    [13, 17],
    [17, 18],
    [18, 19],
    [19, 20],
    [0, 17]
  ];
  var VisionController = class {
    constructor({ video, canvas, fps = 15, onVector, onError }) {
      this.video = video;
      this.canvas = canvas;
      this.context = canvas.getContext("2d");
      this.fps = fps;
      this.onVector = onVector;
      this.onError = onError;
      this.frame = null;
      this.stream = null;
      this.running = false;
      this.frameRequest = null;
      this.lastInferenceAt = 0;
      this.inFlight = false;
      this.ready = false;
      this.initializePromise = null;
      this.messageHandler = (event) => this.handleMessage(event);
    }
    async initialize() {
      if (this.ready) return;
      if (this.initializePromise) return this.initializePromise;
      this.initializePromise = new Promise((resolve, reject) => {
        const timeout = setTimeout(() => reject(new Error("MediaPipe runtime timed out")), 2e4);
        this.resolveInitialize = () => {
          clearTimeout(timeout);
          this.ready = true;
          resolve();
        };
        this.rejectInitialize = (error) => {
          clearTimeout(timeout);
          reject(error);
        };
      });
      window.addEventListener("message", this.messageHandler);
      this.frame = document.createElement("iframe");
      this.frame.src = chrome.runtime.getURL("vision.html");
      this.frame.title = "SignBridge vision runtime";
      this.frame.hidden = true;
      this.frame.setAttribute("aria-hidden", "true");
      document.documentElement.appendChild(this.frame);
      return this.initializePromise;
    }
    async start() {
      if (this.running) return this.stream;
      await this.initialize();
      this.stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 24, max: 30 },
          facingMode: "user"
        },
        audio: false
      });
      this.video.srcObject = this.stream;
      await this.video.play();
      this.running = true;
      this.loop();
      return this.stream;
    }
    stop() {
      this.running = false;
      this.inFlight = false;
      if (this.frameRequest) cancelAnimationFrame(this.frameRequest);
      this.stream?.getTracks().forEach((track) => track.stop());
      this.stream = null;
      this.video.srcObject = null;
      this.context.clearRect(0, 0, this.canvas.width, this.canvas.height);
    }
    getStream() {
      return this.stream;
    }
    loop = () => {
      if (!this.running) return;
      const now = performance.now();
      const interval = 1e3 / this.fps;
      if (!this.inFlight && this.video.readyState >= HTMLMediaElement.HAVE_CURRENT_DATA && now - this.lastInferenceAt >= interval) {
        this.lastInferenceAt = now;
        this.sendFrame(now);
      }
      this.frameRequest = requestAnimationFrame(this.loop);
    };
    async sendFrame(timestamp) {
      this.inFlight = true;
      try {
        const bitmap = await createImageBitmap(this.video);
        this.frame.contentWindow.postMessage({ type: "SIGNBRIDGE_VISION_FRAME", timestamp, bitmap }, "*", [bitmap]);
      } catch (error) {
        this.inFlight = false;
        this.onError?.(error);
      }
    }
    handleMessage(event) {
      if (event.source !== this.frame?.contentWindow) return;
      const message = event.data || {};
      if (message.type === "SIGNBRIDGE_VISION_READY") {
        this.resolveInitialize?.();
        return;
      }
      if (message.type === "SIGNBRIDGE_VISION_ERROR") {
        this.inFlight = false;
        const error = new Error(message.message || "MediaPipe failed");
        if (!this.ready) this.rejectInitialize?.(error);
        else this.onError?.(error);
        return;
      }
      if (message.type !== "SIGNBRIDGE_VISION_RESULT") return;
      this.inFlight = false;
      const result = { landmarks: Array.isArray(message.landmarks) ? message.landmarks : [] };
      this.draw(result);
      if (result.landmarks.length) this.onVector?.(landmarksToVector(result), result);
      else this.onVector?.(null, result);
    }
    draw(result) {
      const width = this.video.videoWidth || 640;
      const height = this.video.videoHeight || 480;
      if (this.canvas.width !== width) this.canvas.width = width;
      if (this.canvas.height !== height) this.canvas.height = height;
      const context = this.context;
      context.clearRect(0, 0, width, height);
      context.save();
      context.translate(width, 0);
      context.scale(-1, 1);
      context.lineWidth = 3;
      context.strokeStyle = "#33d6c8";
      context.fillStyle = "#ecfeff";
      for (const hand of result.landmarks) {
        for (const [start, end] of CONNECTIONS) {
          context.beginPath();
          context.moveTo(hand[start].x * width, hand[start].y * height);
          context.lineTo(hand[end].x * width, hand[end].y * height);
          context.stroke();
        }
        for (const point of hand) {
          context.beginPath();
          context.arc(point.x * width, point.y * height, 4, 0, Math.PI * 2);
          context.fill();
        }
      }
      context.restore();
    }
  };

  // src/constants.js
  var DEFAULT_SETTINGS = {
    endpoint: "http://localhost:11434",
    model: "gemma4:e2b-it-q4_K_M",
    apiKey: "",
    detectionThreshold: 0.92,
    detectionHoldMs: 500,
    detectionCooldownMs: 900,
    inferenceFps: 15,
    speechRate: 0.95,
    liveSignToAudio: false,
    livePauseMs: 1200
  };
  var DEMO_GLOSSES = [
    "ME",
    "YES",
    "NO",
    "PYTHON",
    "AI",
    "PROJECT",
    "EXPERIENCE",
    "TEAM",
    "SOLVE",
    "THREE",
    "YEAR",
    "THANK-YOU"
  ];
  var INTENTS = [
    { id: "ASK_INTRODUCTION", label: "Please introduce yourself" },
    { id: "ASK_EXPERIENCE", label: "Tell me about your experience" },
    { id: "ASK_PROJECT", label: "Explain a project" },
    { id: "ASK_SKILLS", label: "What technical skills do you have" },
    { id: "ASK_TEAMWORK", label: "How do you work with a team" }
  ];

  // src/hud.js
  var SignBridgeHud = class {
    constructor(handlers, vocabulary = DEMO_GLOSSES) {
      this.handlers = handlers;
      this.vocabulary = vocabulary;
      this.signFrames = [];
      this.signFrameIndex = 0;
      this.signFrameTimer = null;
      this.signFrameRate = 10;
      this.signPlaybackRate = 1;
      this.host = document.createElement("div");
      this.host.id = "signbridge-root";
      this.host.dataset.signbridge = "true";
      this.shadow = this.host.attachShadow({ mode: "open" });
      this.shadow.innerHTML = this.template();
      document.documentElement.appendChild(this.host);
      this.bind();
    }
    template() {
      const glossOptions = this.vocabulary.map((item) => `<option value="${item}">${item}</option>`).join("");
      const intentOptions = INTENTS.map((item) => `<option value="${item.id}">${item.label}</option>`).join("");
      return `
      <link rel="stylesheet" href="${chrome.runtime.getURL("hud.css")}">
      <aside class="sb-shell" aria-label="SignBridge AI">
        <header class="sb-header">
          <div>
            <strong>SignBridge AI</strong>
            <small>Gemma 4 \xB7 ISL prototype</small>
          </div>
          <div class="sb-header-actions">
            <span id="sb-mode-badge" class="sb-badge">Checking\u2026</span>
            <button id="sb-collapse" class="sb-icon" title="Collapse">\u2212</button>
          </div>
        </header>
        <div id="sb-body" class="sb-body">
          <div id="sb-status" class="sb-status" data-kind="info">Ready to configure</div>

          <section class="sb-section">
            <div class="sb-section-title"><span>1</span> Interviewer question</div>
            <textarea id="sb-question" rows="2" placeholder="Meet caption appears here, or type the question\u2026"></textarea>
            <div class="sb-row">
              <button id="sb-translate-sign" class="sb-primary">Show in ISL</button>
              <button id="sb-use-caption">Use latest caption</button>
            </div>
            <small id="sb-caption-state" class="sb-muted">Caption observer is active</small>
          </section>

          <section class="sb-section sb-sign-output">
            <div class="sb-section-title"><span>2</span> Interviewer \u2192 ISL</div>
            <div class="sb-sign-stage">
              <video id="sb-sign-video" playsinline controls hidden></video>
              <img id="sb-sign-image" alt="ISL dataset animation" hidden>
              <div id="sb-sign-placeholder" class="sb-sign-placeholder">Translate a supported question to play its verified ISL clip.</div>
            </div>
            <div id="sb-sign-caption" class="sb-sign-caption"></div>
            <div id="sb-sign-glosses" class="sb-chips"></div>
            <div class="sb-row">
              <button id="sb-replay-sign">Replay</button>
              <button id="sb-slower-sign">Slower</button>
              <span id="sb-sign-quality" class="sb-quality"></span>
            </div>
            <details class="sb-details">
              <summary>ISL phrase clip studio</summary>
              <p class="sb-muted">Bundled dataset clips require ISL review. A knowledgeable signer can record verified replacements here.</p>
              <select id="sb-clip-intent">${intentOptions}</select>
              <div class="sb-row">
                <button id="sb-record-clip">Record phrase</button>
                <button id="sb-stop-record" disabled>Stop & save</button>
                <button id="sb-delete-clip" class="sb-danger-text">Delete</button>
              </div>
              <div id="sb-clip-status" class="sb-muted">No recording in progress</div>
            </details>
          </section>

          <section class="sb-section">
            <div class="sb-section-title"><span>3</span> Candidate signs</div>
            <div class="sb-camera-stage">
              <video id="sb-camera" muted playsinline></video>
              <canvas id="sb-canvas"></canvas>
              <div id="sb-detected" class="sb-detected">No gesture</div>
            </div>
            <div class="sb-row">
              <button id="sb-start-camera" class="sb-primary">Start camera</button>
              <button id="sb-stop-camera" disabled>Stop</button>
            </div>
            <div class="sb-calibration">
              <select id="sb-calibration-gloss">${glossOptions}</select>
              <button id="sb-calibrate">Calibrate sign</button>
            </div>
            <button id="sb-add-gloss" class="sb-full-button">Add selected gloss manually</button>
            <div id="sb-calibration-state" class="sb-muted">Calibrate the signs used in your demo.</div>
            <label class="sb-check sb-live-toggle">
              <input id="sb-live-audio" type="checkbox">
              <span><strong>Live sign \u2192 audio</strong><small> Speaks automatically after a short signing pause</small></span>
            </label>
            <div id="sb-live-state" class="sb-muted">Live audio is off</div>
            <div id="sb-gloss-buffer" class="sb-chips sb-buffer"></div>
            <div class="sb-row">
              <button id="sb-clear-glosses">Clear</button>
              <button id="sb-generate-answer" class="sb-primary">Finish & generate</button>
            </div>
          </section>

          <section class="sb-section">
            <div class="sb-section-title"><span>4</span> Candidate review</div>
            <textarea id="sb-answer" rows="3" placeholder="Gemma 4 answer appears here for review\u2026"></textarea>
            <label class="sb-check"><input id="sb-approved" type="checkbox"> I reviewed and approve this wording</label>
            <div class="sb-row sb-wrap">
              <button id="sb-speak" disabled>Speak</button>
              <button id="sb-copy" disabled>Copy</button>
              <button id="sb-chat" disabled>Insert in Meet chat</button>
            </div>
            <div id="sb-metrics" class="sb-muted"></div>
          </section>

          <details class="sb-section sb-details" open>
            <summary>Gemma 4 settings</summary>
            <label>Endpoint<input id="sb-endpoint" type="url" placeholder="http://localhost:11434"></label>
            <label>Model<input id="sb-model" type="text" placeholder="gemma4:e2b-it-q4_K_M"></label>
            <label>API key (optional)<input id="sb-api-key" type="password" autocomplete="off"></label>
            <div class="sb-row">
              <button id="sb-save-settings">Save</button>
              <button id="sb-check-gemma" class="sb-primary">Check Gemma</button>
            </div>
          </details>
        </div>
      </aside>`;
    }
    $(selector) {
      return this.shadow.querySelector(selector);
    }
    bind() {
      const actions = {
        "#sb-start-camera": "startCamera",
        "#sb-stop-camera": "stopCamera",
        "#sb-calibrate": "calibrate",
        "#sb-add-gloss": "addGloss",
        "#sb-clear-glosses": "clearGlosses",
        "#sb-generate-answer": "generateAnswer",
        "#sb-translate-sign": "translateToSign",
        "#sb-use-caption": "useLatestCaption",
        "#sb-speak": "speak",
        "#sb-copy": "copy",
        "#sb-chat": "insertChat",
        "#sb-save-settings": "saveSettings",
        "#sb-check-gemma": "checkGemma",
        "#sb-replay-sign": "replaySign",
        "#sb-slower-sign": "slowerSign",
        "#sb-record-clip": "recordClip",
        "#sb-stop-record": "stopRecording",
        "#sb-delete-clip": "deleteClip"
      };
      for (const [selector, handler] of Object.entries(actions)) {
        this.$(selector).addEventListener("click", () => this.handlers[handler]?.());
      }
      this.$("#sb-approved").addEventListener("change", (event) => this.setApproved(event.target.checked));
      this.$("#sb-live-audio").addEventListener("change", (event) => this.handlers.toggleLiveMode?.(event.target.checked));
      this.$("#sb-answer").addEventListener("input", () => {
        this.$("#sb-approved").checked = false;
        this.setApproved(false);
      });
      this.$("#sb-collapse").addEventListener("click", () => {
        const body = this.$("#sb-body");
        body.hidden = !body.hidden;
        this.$("#sb-collapse").textContent = body.hidden ? "+" : "\u2212";
      });
    }
    get video() {
      return this.$("#sb-camera");
    }
    get canvas() {
      return this.$("#sb-canvas");
    }
    getQuestion() {
      return this.$("#sb-question").value.trim();
    }
    getAnswer() {
      return this.$("#sb-answer").value.trim();
    }
    getCalibrationGloss() {
      return this.$("#sb-calibration-gloss").value;
    }
    getClipIntent() {
      return this.$("#sb-clip-intent").value;
    }
    isLiveMode() {
      return this.$("#sb-live-audio").checked;
    }
    getSettingsForm() {
      return {
        endpoint: this.$("#sb-endpoint").value.trim(),
        model: this.$("#sb-model").value.trim(),
        apiKey: this.$("#sb-api-key").value
      };
    }
    setSettings(settings) {
      this.$("#sb-endpoint").value = settings.endpoint || "";
      this.$("#sb-model").value = settings.model || "";
      this.$("#sb-api-key").value = settings.apiKey || "";
      this.$("#sb-live-audio").checked = Boolean(settings.liveSignToAudio);
      this.setLiveState(settings.liveSignToAudio ? "Live audio ready \u2014 pause briefly to speak" : "Live audio is off", settings.liveSignToAudio);
      this.$("#sb-mode-badge").textContent = settings.endpoint?.includes("localhost") || settings.endpoint?.includes("127.0.0.1") ? "Gemma 4 local" : "Gemma 4 network";
    }
    setStatus(message, kind = "info") {
      const status = this.$("#sb-status");
      status.textContent = message;
      status.dataset.kind = kind;
    }
    setQuestion(question, source = "manual") {
      this.$("#sb-question").value = question;
      this.$("#sb-caption-state").textContent = source === "caption" ? "Latest Meet caption captured" : "Using manual question";
    }
    showLatestCaption(caption) {
      this.$("#sb-caption-state").textContent = `Caption ready: ${caption.slice(0, 70)}${caption.length > 70 ? "\u2026" : ""}`;
    }
    setCameraRunning(running) {
      this.$("#sb-start-camera").disabled = running;
      this.$("#sb-stop-camera").disabled = !running;
    }
    setLiveState(message, active = this.isLiveMode()) {
      const state = this.$("#sb-live-state");
      state.textContent = message;
      state.dataset.active = String(Boolean(active));
    }
    setDetected(match) {
      const label = this.$("#sb-detected");
      if (!match?.gloss) label.textContent = "No gesture";
      else label.textContent = `${match.gloss} \xB7 ${Math.round(match.score * 100)}%`;
    }
    setCalibrationState(message, progress = 0) {
      this.$("#sb-calibration-state").textContent = progress ? `${message} ${Math.round(progress * 100)}%` : message;
    }
    renderGlosses(glosses, removeHandler) {
      const container = this.$("#sb-gloss-buffer");
      container.replaceChildren();
      if (!glosses.length) {
        const empty = document.createElement("span");
        empty.className = "sb-muted";
        empty.textContent = "Detected signs will appear here";
        container.appendChild(empty);
        return;
      }
      glosses.forEach((gloss, index) => {
        const chip = document.createElement("button");
        chip.className = "sb-chip";
        chip.textContent = `${gloss} \xD7`;
        chip.title = "Remove sign";
        chip.addEventListener("click", () => removeHandler(index));
        container.appendChild(chip);
      });
    }
    setAnswer(answer, needsClarification = false) {
      this.$("#sb-answer").value = answer;
      this.$("#sb-approved").checked = false;
      this.setApproved(false);
      if (needsClarification) this.setStatus("Gemma needs clarification. Review the literal answer before approving.", "warn");
    }
    setApproved(approved) {
      const enabled = approved && Boolean(this.getAnswer());
      ["#sb-speak", "#sb-copy", "#sb-chat"].forEach((selector) => {
        this.$(selector).disabled = !enabled;
      });
    }
    setMetrics(metrics) {
      if (!metrics?.totalDurationNs) {
        this.$("#sb-metrics").textContent = "";
        return;
      }
      this.$("#sb-metrics").textContent = `Gemma 4: ${(metrics.totalDurationNs / 1e9).toFixed(2)}s \xB7 ${metrics.outputTokens || 0} output tokens`;
    }
    showSignResult({ question, glosses, clipUrl, frameSequences = [], exact, quality, message }) {
      const video = this.$("#sb-sign-video");
      const image = this.$("#sb-sign-image");
      const placeholder = this.$("#sb-sign-placeholder");
      this.stopFrameAnimation();
      this.signFrames = [];
      this.$("#sb-sign-caption").textContent = question;
      const chips = this.$("#sb-sign-glosses");
      chips.replaceChildren(...glosses.map((gloss) => {
        const span = document.createElement("span");
        span.className = "sb-chip sb-chip-static";
        span.textContent = gloss;
        return span;
      }));
      this.$("#sb-sign-quality").textContent = quality || (exact ? "Verified phrase clip" : "Approximate / unsupported");
      this.$("#sb-sign-quality").dataset.exact = String(Boolean(exact));
      if (clipUrl) {
        video.src = clipUrl;
        video.hidden = false;
        image.hidden = true;
        placeholder.hidden = true;
        video.playbackRate = 1;
        video.play().catch(() => {
        });
      } else if (frameSequences.length) {
        video.removeAttribute("src");
        video.load();
        video.hidden = true;
        image.hidden = false;
        placeholder.hidden = true;
        this.signFrames = frameSequences.flatMap((sequence) => [
          ...sequence.frames,
          ...Array(4).fill(sequence.frames.at(-1))
        ]).filter(Boolean);
        this.signFrameRate = frameSequences[0]?.fps || 10;
        this.playFrameAnimation(true);
      } else {
        video.removeAttribute("src");
        video.load();
        video.hidden = true;
        image.hidden = true;
        placeholder.hidden = false;
        placeholder.textContent = message || "No verified ISL clip is recorded for this question.";
      }
    }
    replaySign() {
      const video = this.$("#sb-sign-video");
      if (!video.hidden && video.src) {
        video.currentTime = 0;
        video.play().catch(() => {
        });
      } else if (this.signFrames.length) {
        this.playFrameAnimation(true);
      }
    }
    slowerSign() {
      const video = this.$("#sb-sign-video");
      if (!video.hidden && video.src) {
        video.playbackRate = video.playbackRate === 0.65 ? 1 : 0.65;
        this.signPlaybackRate = video.playbackRate;
      } else if (this.signFrames.length) {
        this.signPlaybackRate = this.signPlaybackRate === 0.65 ? 1 : 0.65;
        this.playFrameAnimation(true);
      }
      this.$("#sb-slower-sign").textContent = this.signPlaybackRate === 0.65 ? "Normal speed" : "Slower";
    }
    playFrameAnimation(reset = false) {
      this.stopFrameAnimation();
      if (!this.signFrames.length) return;
      if (reset) this.signFrameIndex = 0;
      const image = this.$("#sb-sign-image");
      const interval = Math.round(1e3 / (this.signFrameRate * this.signPlaybackRate));
      const step = () => {
        if (this.signFrameIndex >= this.signFrames.length) {
          this.stopFrameAnimation();
          return;
        }
        image.src = this.signFrames[this.signFrameIndex];
        this.signFrameIndex += 1;
        this.signFrameTimer = setTimeout(step, interval);
      };
      step();
    }
    stopFrameAnimation() {
      if (this.signFrameTimer) clearTimeout(this.signFrameTimer);
      this.signFrameTimer = null;
    }
    setRecording(recording, message) {
      this.$("#sb-record-clip").disabled = recording;
      this.$("#sb-stop-record").disabled = !recording;
      this.$("#sb-clip-status").textContent = message;
    }
  };

  // src/meet-adapter.js
  function normalizeText(value) {
    return String(value || "").replace(/\s+/g, " ").trim();
  }
  function isVisible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }
  var MeetAdapter = class {
    constructor({ onCaption }) {
      this.onCaption = onCaption;
      this.lastCaption = "";
      this.pendingCaption = "";
      this.captionTimer = null;
      this.observer = null;
    }
    start() {
      this.observer = new MutationObserver((mutations) => this.handleMutations(mutations));
      this.observer.observe(document.body, { childList: true, subtree: true, characterData: true });
    }
    stop() {
      this.observer?.disconnect();
      clearTimeout(this.captionTimer);
    }
    handleMutations(mutations) {
      const candidates = /* @__PURE__ */ new Set();
      for (const mutation of mutations) {
        const target = mutation.target.nodeType === Node.TEXT_NODE ? mutation.target.parentElement : mutation.target;
        if (!target || target.closest?.("#signbridge-root")) continue;
        const liveRegion = target.closest?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]');
        if (liveRegion) candidates.add(liveRegion);
        for (const node of mutation.addedNodes || []) {
          if (node.nodeType !== Node.ELEMENT_NODE) continue;
          if (node.matches?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]')) candidates.add(node);
          node.querySelectorAll?.('[aria-live="polite"], [aria-live="assertive"], [role="log"]').forEach((item) => candidates.add(item));
        }
      }
      for (const element of candidates) {
        const text = normalizeText(element.innerText || element.textContent);
        if (this.looksLikeCaption(text)) this.queueCaption(text);
      }
    }
    looksLikeCaption(text) {
      if (!text || text === this.lastCaption || text.length < 4 || text.length > 320) return false;
      if (/signbridge|you are presenting|microphone|camera|joined|left the call/i.test(text)) return false;
      const words = text.split(" ");
      return words.length >= 2;
    }
    queueCaption(text) {
      this.pendingCaption = text;
      clearTimeout(this.captionTimer);
      this.captionTimer = setTimeout(() => {
        if (!this.pendingCaption || this.pendingCaption === this.lastCaption) return;
        this.lastCaption = this.pendingCaption;
        this.onCaption?.(this.lastCaption);
      }, 900);
    }
    insertChatDraft(text) {
      const selectors = [
        'div[contenteditable="true"][role="textbox"]',
        'textarea[aria-label*="message" i]',
        'textarea[placeholder*="message" i]'
      ];
      const candidates = selectors.flatMap((selector) => [...document.querySelectorAll(selector)]);
      const input = candidates.find((element) => isVisible(element) && !element.closest("#signbridge-root"));
      if (!input) {
        throw new Error("Open the Meet chat panel, then try Insert again.");
      }
      input.focus();
      if (input instanceof HTMLTextAreaElement || input instanceof HTMLInputElement) {
        const descriptor = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(input), "value");
        descriptor?.set?.call(input, text);
      } else {
        const selection = window.getSelection();
        const range = document.createRange();
        range.selectNodeContents(input);
        selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand("insertText", false, text);
      }
      input.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: text }));
      input.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
  };

  // src/gemma.js
  function runtimeMessage(payload) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage(payload, (response) => {
        const error = chrome.runtime.lastError;
        if (error) reject(new Error(error.message));
        else if (!response?.ok) reject(new Error(response?.error || "Gemma request failed"));
        else resolve(response.data);
      });
    });
  }
  function checkGemma(settings) {
    return runtimeMessage({ type: "GEMMA_HEALTH", settings });
  }
  function generateAnswer(settings, question, glosses) {
    const schema = {
      type: "object",
      properties: {
        answer: { type: "string" },
        used_glosses: { type: "array", items: { type: "string" } },
        needs_clarification: { type: "boolean" }
      },
      required: ["answer", "used_glosses", "needs_clarification"]
    };
    const system = [
      "You are the constrained language renderer in an accessibility prototype.",
      "Return JSON only and obey the supplied schema.",
      "Write one first-person English sentence of at most 20 words.",
      "Use only facts explicitly represented by the glosses. The question supplies context, not facts about the candidate.",
      "Never add companies, technologies, achievements, metrics, methods, durations, or examples absent from the glosses.",
      "Preserve numbers and negation exactly.",
      "If meaning is insufficient, set needs_clarification true and keep the answer literal."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        { role: "user", content: JSON.stringify({ question, glosses }) }
      ]
    });
  }
  function mapQuestionToSign(settings, question, intents, availableClips) {
    const intentIds = intents.map((intent) => intent.id);
    const clipIds = availableClips.map((clip) => clip.id);
    const schema = {
      type: "object",
      properties: {
        intent: { type: "string", enum: [...intentIds, "UNSUPPORTED"] },
        exact_clip: { type: "string", enum: ["NONE", ...clipIds] },
        clips: { type: "array", items: { type: "string", enum: clipIds }, maxItems: 8 },
        confidence: { type: "number", minimum: 0, maximum: 1 }
      },
      required: ["intent", "exact_clip", "clips", "confidence"]
    };
    const system = [
      "Map an interview question to a constrained library of Indian Sign Language dataset clips.",
      "Return JSON only and obey the schema.",
      "Select exact_clip only when one available phrase label expresses the complete question; otherwise use NONE.",
      "For clips, select the smallest useful ordered sequence from the available labels and never invent a label.",
      "Use UNSUPPORTED when no interview intent is a clear match, but clips may still provide an approximate rendering.",
      "Do not treat ASL and ISL as interchangeable."
    ].join(" ");
    return runtimeMessage({
      type: "GEMMA_CHAT",
      settings,
      schema,
      messages: [
        { role: "system", content: system },
        {
          role: "user",
          content: JSON.stringify({
            question,
            supported_intents: intents,
            available_clips: availableClips
          })
        }
      ]
    });
  }

  // src/storage.js
  async function getSettings() {
    const result = await chrome.storage.local.get("settings");
    return { ...DEFAULT_SETTINGS, ...result.settings || {} };
  }
  async function saveSettings(settings) {
    const merged = { ...DEFAULT_SETTINGS, ...settings };
    await chrome.storage.local.set({ settings: merged });
    return merged;
  }
  async function getTemplates() {
    const result = await chrome.storage.local.get("gestureTemplates");
    return result.gestureTemplates || {};
  }
  async function saveTemplate(gloss, vector) {
    const templates = await getTemplates();
    templates[gloss] = {
      vector,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    await chrome.storage.local.set({ gestureTemplates: templates });
    return templates;
  }

  // src/clip-store.js
  var DB_NAME = "signbridge-media";
  var DB_VERSION = 1;
  var STORE_NAME = "isl-clips";
  function openDatabase() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const database = request.result;
        if (!database.objectStoreNames.contains(STORE_NAME)) {
          database.createObjectStore(STORE_NAME, { keyPath: "intent" });
        }
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }
  async function transact(mode, operation) {
    const database = await openDatabase();
    try {
      return await new Promise((resolve, reject) => {
        const transaction = database.transaction(STORE_NAME, mode);
        const store = transaction.objectStore(STORE_NAME);
        const request = operation(store);
        request.onsuccess = () => resolve(request.result);
        request.onerror = () => reject(request.error);
      });
    } finally {
      database.close();
    }
  }
  function saveClip(intent, blob) {
    return transact("readwrite", (store) => store.put({
      intent,
      blob,
      mimeType: blob.type,
      updatedAt: (/* @__PURE__ */ new Date()).toISOString()
    }));
  }
  function getClip(intent) {
    return transact("readonly", (store) => store.get(intent));
  }
  function deleteClip(intent) {
    return transact("readwrite", (store) => store.delete(intent));
  }
  async function listClips() {
    const records = await transact("readonly", (store) => store.getAll());
    return records || [];
  }

  // src/content.js
  if (!document.getElementById("signbridge-root")) {
    boot().catch((error) => console.error("SignBridge failed to start", error));
  }
  async function boot() {
    let settings = await getSettings();
    let templates = await getTemplates();
    const signLibrary = await loadBundledSignLibrary();
    const signClipsById = new Map(signLibrary.clips.map((clip) => [clip.id, clip]));
    const candidateVocabulary = [.../* @__PURE__ */ new Set([
      ...DEMO_GLOSSES,
      ...signLibrary.clips.map((clip) => clip.label.toUpperCase())
    ])].sort();
    let glossBuffer = [];
    let latestCaption = "";
    let calibration = null;
    let mediaRecorder = null;
    let recordingChunks = [];
    let recordingIntent = null;
    let signClipUrl = null;
    let liveTimer = null;
    let liveGenerating = false;
    const hud = new SignBridgeHud({
      startCamera,
      stopCamera,
      calibrate,
      addGloss,
      clearGlosses,
      generateAnswer: handleGenerateAnswer,
      translateToSign,
      useLatestCaption,
      speak,
      copy,
      insertChat,
      saveSettings: handleSaveSettings,
      checkGemma: handleCheckGemma,
      replaySign: () => hud.replaySign(),
      slowerSign: () => hud.slowerSign(),
      recordClip,
      stopRecording,
      deleteClip: handleDeleteClip,
      toggleLiveMode: handleToggleLiveMode
    }, candidateVocabulary);
    hud.setSettings(settings);
    hud.renderGlosses(glossBuffer, removeGloss);
    const detector = new StableGestureDetector({
      threshold: settings.detectionThreshold,
      holdMs: settings.detectionHoldMs,
      cooldownMs: settings.detectionCooldownMs,
      onCandidate: (match) => {
        hud.setDetected(match);
        if (match?.gloss) scheduleLiveGeneration();
      },
      onAccept: ({ gloss }) => {
        if (!gloss) return;
        glossBuffer.push(gloss);
        hud.renderGlosses(glossBuffer, removeGloss);
        hud.setStatus(`Sign accepted: ${gloss}`, "success");
        scheduleLiveGeneration();
      }
    });
    const vision = new VisionController({
      video: hud.video,
      canvas: hud.canvas,
      fps: settings.inferenceFps,
      onVector(vector) {
        if (!vector) {
          hud.setDetected(null);
          detector.update({ gloss: null, score: 0 });
          return;
        }
        if (calibration) {
          calibration.samples.push(vector);
          const progress = Math.min((performance.now() - calibration.startedAt) / calibration.durationMs, 1);
          hud.setCalibrationState(`Hold ${calibration.gloss} steady\u2026`, progress);
          return;
        }
        if (mediaRecorder?.state === "recording") return;
        detector.update(findBestMatch(vector, templates));
      },
      onError(error) {
        hud.setStatus(`Vision error: ${error.message}`, "error");
      }
    });
    const meet = new MeetAdapter({
      onCaption(caption) {
        latestCaption = caption;
        hud.showLatestCaption(caption);
      }
    });
    meet.start();
    await updateClipInventory();
    hud.setStatus("Ready. Check Gemma, record ISL clips, then start the camera.", "info");
    async function startCamera() {
      try {
        hud.setStatus("Starting camera and MediaPipe\u2026", "info");
        await vision.start();
        hud.setCameraRunning(true);
        hud.setStatus("Camera ready. Calibrate or begin signing.", "success");
      } catch (error) {
        hud.setCameraRunning(false);
        hud.setStatus(`Camera unavailable: ${error.message}`, "error");
      }
    }
    function stopCamera() {
      cancelLiveTimer();
      if (mediaRecorder?.state === "recording") mediaRecorder.stop();
      vision.stop();
      hud.setCameraRunning(false);
      hud.setDetected(null);
      hud.setStatus("Camera stopped.", "info");
    }
    async function calibrate() {
      if (!vision.getStream()) {
        await startCamera();
        if (!vision.getStream()) return;
      }
      if (calibration) return;
      const gloss = hud.getCalibrationGloss();
      hud.setCalibrationState(`Get ready to hold ${gloss}\u2026`);
      await delay(650);
      calibration = {
        gloss,
        samples: [],
        startedAt: performance.now(),
        durationMs: 1700
      };
      await delay(calibration.durationMs);
      const completed = calibration;
      calibration = null;
      if (completed.samples.length < 8) {
        hud.setCalibrationState(`Calibration failed: only ${completed.samples.length} usable frames. Try again.`);
        return;
      }
      const vector = averageVectors(completed.samples);
      templates = await saveTemplate(gloss, vector);
      detector.reset();
      hud.setCalibrationState(`${gloss} calibrated from ${completed.samples.length} frames.`);
      hud.setStatus(`${gloss} calibration saved locally.`, "success");
    }
    function removeGloss(index) {
      glossBuffer.splice(index, 1);
      hud.renderGlosses(glossBuffer, removeGloss);
      scheduleLiveGeneration();
    }
    function addGloss() {
      const gloss = hud.getCalibrationGloss();
      glossBuffer.push(gloss);
      hud.renderGlosses(glossBuffer, removeGloss);
      hud.setStatus(`Added ${gloss} manually.`, "success");
      scheduleLiveGeneration();
    }
    function clearGlosses() {
      cancelLiveTimer();
      glossBuffer = [];
      detector.reset();
      hud.renderGlosses(glossBuffer, removeGloss);
      hud.setStatus("Gloss buffer cleared.", "info");
    }
    async function handleGenerateAnswer() {
      const question = hud.getQuestion();
      if (!question) {
        hud.setStatus("Add the interviewer\u2019s question first.", "warn");
        return;
      }
      if (!glossBuffer.length) {
        hud.setStatus("Sign or add at least one calibrated gloss first.", "warn");
        return;
      }
      await generateFromGlosses(question, [...glossBuffer], false);
    }
    async function generateFromGlosses(question, glosses, live) {
      hud.setStatus(live ? "Live mode: translating the signed phrase\u2026" : "Gemma 4 is rendering the signed meaning\u2026", "info");
      try {
        const response = await generateAnswer(settings, question, glosses);
        const result = response.result || {};
        const answer = String(result.answer || "").trim();
        if (!answer) throw new Error("Gemma returned an empty answer");
        hud.setAnswer(answer, Boolean(result.needs_clarification));
        hud.setMetrics(response.metrics);
        if (live && !result.needs_clarification) {
          speakText(answer);
          removeProcessedGlosses(glosses);
          hud.setLiveState("Spoken \u2014 listening for the next phrase", true);
          hud.setStatus("Live sign-to-audio response spoken. Listening continues.", "success");
        } else if (live) {
          hud.setLiveState("Clarification needed \u2014 nothing was spoken", true);
        } else if (!result.needs_clarification) {
          hud.setStatus("Answer ready. Review and approve it before delivery.", "success");
        }
      } catch (error) {
        const literal = `My response is: ${glosses.join(" ").toLowerCase()}.`;
        hud.setAnswer(literal, true);
        hud.setMetrics(null);
        if (live) {
          hud.setLiveState("Live translation failed \u2014 nothing was spoken", true);
          hud.setStatus(`Live Gemma unavailable (${error.message}). Nothing was spoken automatically.`, "warn");
        } else {
          hud.setStatus(`Gemma unavailable (${error.message}). Showing a literal fallback.`, "warn");
        }
      }
    }
    function scheduleLiveGeneration() {
      if (!hud.isLiveMode() || !glossBuffer.length) return;
      cancelLiveTimer();
      hud.setLiveState("Signing detected \u2014 pause briefly to speak", true);
      liveTimer = setTimeout(flushLivePhrase, settings.livePauseMs || 1200);
    }
    async function flushLivePhrase() {
      liveTimer = null;
      if (!hud.isLiveMode() || !glossBuffer.length) return;
      if (liveGenerating) {
        scheduleLiveGeneration();
        return;
      }
      const question = hud.getQuestion();
      if (!question) {
        hud.setLiveState("Add or capture the interviewer question first", true);
        hud.setStatus("Live audio needs the interviewer\u2019s question for context.", "warn");
        return;
      }
      const phrase = [...glossBuffer];
      liveGenerating = true;
      try {
        await generateFromGlosses(question, phrase, true);
      } finally {
        liveGenerating = false;
        if (glossBuffer.length) scheduleLiveGeneration();
      }
    }
    function removeProcessedGlosses(processed) {
      const samePrefix = processed.every((gloss, index) => glossBuffer[index] === gloss);
      if (samePrefix) glossBuffer.splice(0, processed.length);
      hud.renderGlosses(glossBuffer, removeGloss);
    }
    function cancelLiveTimer() {
      if (liveTimer) clearTimeout(liveTimer);
      liveTimer = null;
    }
    async function handleToggleLiveMode(enabled) {
      settings = await saveSettings({ ...settings, liveSignToAudio: enabled });
      if (enabled) {
        hud.setLiveState("Live audio ready \u2014 pause briefly to speak", true);
        hud.setStatus("Live sign-to-audio enabled. Recognized phrases will be spoken automatically.", "success");
        scheduleLiveGeneration();
      } else {
        cancelLiveTimer();
        speechSynthesis.cancel();
        hud.setLiveState("Live audio is off", false);
        hud.setStatus("Live sign-to-audio disabled.", "info");
      }
    }
    async function translateToSign() {
      const question = hud.getQuestion();
      if (!question) {
        hud.setStatus("Add the interviewer\u2019s question first.", "warn");
        return;
      }
      hud.setStatus("Gemma 4 is mapping the question to verified ISL\u2026", "info");
      try {
        const availableClips = signLibrary.clips.map(({ id, label, kind }) => ({ id, label, kind }));
        const response = await mapQuestionToSign(settings, question, INTENTS, availableClips);
        const result = response.result || {};
        const validIntent = INTENTS.some((item) => item.id === result.intent) ? result.intent : "UNSUPPORTED";
        const exactBuiltIn = result.exact_clip !== "NONE" ? signClipsById.get(result.exact_clip) : null;
        const selectedIds = exactBuiltIn ? [exactBuiltIn.id] : Array.isArray(result.clips) ? result.clips.filter((id) => signClipsById.has(id)).slice(0, 8) : [];
        const selectedClips = selectedIds.map((id) => signClipsById.get(id));
        const glosses = selectedClips.map((item) => item.label.toUpperCase());
        const clip = validIntent === "UNSUPPORTED" ? null : await getClip(validIntent);
        if (signClipUrl) URL.revokeObjectURL(signClipUrl);
        signClipUrl = clip?.blob ? URL.createObjectURL(clip.blob) : null;
        const frameSequences = signClipUrl ? [] : selectedClips.map((item) => ({
          fps: item.fps,
          frames: item.frames.map((frame) => chrome.runtime.getURL(frame))
        }));
        const quality = signClipUrl ? "Verified signer recording" : exactBuiltIn ? "Dataset phrase clip \xB7 review" : frameSequences.length ? "Approximate dataset sequence" : "Unsupported";
        hud.showSignResult({
          question,
          glosses,
          clipUrl: signClipUrl,
          frameSequences,
          exact: Boolean(signClipUrl || exactBuiltIn),
          quality,
          message: validIntent === "UNSUPPORTED" ? "This question is outside the supported interview intents. Read the caption; only available dataset concepts are shown." : `No custom recording or useful dataset sequence is available for ${validIntent}.`
        });
        hud.setMetrics(response.metrics);
        if (signClipUrl) hud.setStatus("Verified ISL signer recording is playing.", "success");
        else if (exactBuiltIn) hud.setStatus("Exact dataset phrase is playing. Review its ISL accuracy before the demo.", "warn");
        else if (frameSequences.length) hud.setStatus("Approximate dataset sequence is playing with the original caption retained.", "warn");
        else hud.setStatus("No matching dataset clip is available. Caption retained; no false signing shown.", "warn");
      } catch (error) {
        hud.showSignResult({ question, glosses: [], clipUrl: null, exact: false, message: `Could not map this question: ${error.message}` });
        hud.setStatus(`Question-to-ISL failed: ${error.message}`, "error");
      }
    }
    function useLatestCaption() {
      if (!latestCaption) {
        hud.setStatus("No Meet caption detected. Turn captions on or type the question.", "warn");
        return;
      }
      hud.setQuestion(latestCaption, "caption");
      hud.setStatus("Latest Meet caption selected.", "success");
    }
    function speak() {
      const answer = hud.getAnswer();
      if (!answer) return;
      speakText(answer);
      hud.setStatus("Speaking approved answer locally.", "success");
    }
    function speakText(text) {
      speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      utterance.lang = "en-IN";
      utterance.rate = settings.speechRate;
      speechSynthesis.speak(utterance);
    }
    async function copy() {
      const answer = hud.getAnswer();
      if (!answer) return;
      await navigator.clipboard.writeText(answer);
      hud.setStatus("Approved answer copied.", "success");
    }
    function insertChat() {
      const answer = hud.getAnswer();
      if (!answer) return;
      try {
        meet.insertChatDraft(`\u{1F91F} Candidate via SignBridge: ${answer}`);
        hud.setStatus("Draft inserted. Review it in Meet and press Send yourself.", "success");
      } catch (error) {
        navigator.clipboard.writeText(answer).catch(() => {
        });
        hud.setStatus(`${error.message} The answer was copied instead.`, "warn");
      }
    }
    async function handleSaveSettings() {
      const form = hud.getSettingsForm();
      if (!form.endpoint || !form.model) {
        hud.setStatus("Endpoint and model are required.", "warn");
        return;
      }
      settings = await saveSettings({ ...settings, ...form });
      hud.setSettings(settings);
      hud.setStatus("Gemma settings saved locally.", "success");
    }
    async function handleCheckGemma() {
      await handleSaveSettings();
      hud.setStatus("Checking Gemma 4 endpoint\u2026", "info");
      try {
        const health = await checkGemma(settings);
        if (health.installed) hud.setStatus(`Gemma 4 ready: ${settings.model}`, "success");
        else hud.setStatus(`Endpoint is online, but ${settings.model} is not installed.`, "warn");
      } catch (error) {
        hud.setStatus(`Gemma endpoint unavailable: ${error.message}`, "error");
      }
    }
    async function recordClip() {
      if (!vision.getStream()) {
        await startCamera();
        if (!vision.getStream()) return;
      }
      if (mediaRecorder?.state === "recording") return;
      recordingIntent = hud.getClipIntent();
      recordingChunks = [];
      const mimeCandidates = ["video/webm;codecs=vp9", "video/webm;codecs=vp8", "video/webm"];
      const mimeType = mimeCandidates.find((candidate) => MediaRecorder.isTypeSupported(candidate)) || "";
      mediaRecorder = new MediaRecorder(vision.getStream(), mimeType ? { mimeType } : void 0);
      mediaRecorder.ondataavailable = (event) => {
        if (event.data?.size) recordingChunks.push(event.data);
      };
      mediaRecorder.onerror = (event) => {
        hud.setRecording(false, `Recording error: ${event.error?.message || "unknown error"}`);
      };
      mediaRecorder.onstop = async () => {
        const blob = new Blob(recordingChunks, { type: mediaRecorder.mimeType || "video/webm" });
        if (blob.size < 1e3) {
          hud.setRecording(false, "Recording was empty. Try again.");
          return;
        }
        await saveClip(recordingIntent, blob);
        hud.setRecording(false, `${recordingIntent} saved locally (${(blob.size / 1024).toFixed(0)} KB).`);
        hud.setStatus("Verified ISL phrase clip saved. Review it before the demo.", "success");
        await updateClipInventory();
      };
      mediaRecorder.start(250);
      hud.setRecording(true, `Recording ${recordingIntent}\u2026 perform the complete verified ISL phrase.`);
      hud.setStatus("Recording ISL phrase. Press Stop & save when complete.", "warn");
    }
    function stopRecording() {
      if (mediaRecorder?.state === "recording") mediaRecorder.stop();
    }
    async function handleDeleteClip() {
      const intent = hud.getClipIntent();
      await deleteClip(intent);
      hud.setRecording(false, `${intent} recording deleted.`);
      hud.setStatus("ISL phrase clip deleted.", "info");
      await updateClipInventory();
    }
    async function updateClipInventory() {
      const clips = await listClips();
      const recorded = new Set(clips.map((clip) => clip.intent));
      const count = INTENTS.filter((intent) => recorded.has(intent.id)).length;
      hud.setRecording(false, `${signLibrary.clips.length} bundled dataset clips \xB7 ${count}/${INTENTS.length} verified custom phrases.`);
    }
  }
  function delay(milliseconds) {
    return new Promise((resolve) => setTimeout(resolve, milliseconds));
  }
  async function loadBundledSignLibrary() {
    try {
      const response = await fetch(chrome.runtime.getURL("assets/signs/library.json"));
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const manifest = await response.json();
      return { ...manifest, clips: Array.isArray(manifest.clips) ? manifest.clips : [] };
    } catch (error) {
      console.warn("SignBridge bundled sign library unavailable", error);
      return { version: 1, clips: [] };
    }
  }
})();
//# sourceMappingURL=content.js.map
